#!/usr/bin/env python3
"""
CRISP-CAV Experiment 3 — Cramér–Rao Bound Verification
for Asynchronous Multi-Agent Timing Estimation (FQ3)

Scientific question:
    What is the fundamental lower bound on joint timing uncertainty
    achievable by a mobile multi-agent V2X network with no shared
    reference clock, and which side-channel combinations achieve it?

Experiments
-----------
1. CRB verification sweep  — WLS achieves CRB across N × channel combinations.
2. Multipath / NLOS        — CRB degrades as UWB SNR drops toward σ_rstd.
3. Spoofing detection      — Empirically calibrated threshold via H₀ ROC.
4. EKF dynamic tracking    — KF tracks clock offset + drift; converges in 2 steps.
5. Joint pose-timing FIM   — 3N-dim FIM couples position and timing unknowns.
6. Hardware validation     — Simulated DWM3000 / RG501Q parameters; χ² test.

Requirements:
    pip install numpy scipy tabulate matplotlib
"""

from __future__ import annotations

import os
from datetime import datetime
from dataclasses import dataclass
from itertools import combinations
from typing import Optional

import numpy as np

try:
    from tabulate import tabulate
    HAS_TABULATE = True
except ImportError:
    HAS_TABULATE = False

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.ticker as mticker
    HAS_MPL = True
except ImportError:
    HAS_MPL = False

# ── Physical constants ─────────────────────────────────────────────────────

C_LIGHT = 2.998e8   # m/s
NS      = 1e-9
US      = 1e-6
MS      = 1e-3

PLOT_DIR = os.environ.get("CRISP_CAV_OUT", os.path.join(os.path.dirname(os.path.abspath(__file__)), "out"))
os.makedirs(PLOT_DIR, exist_ok=True)


# ── Configurations ─────────────────────────────────────────────────────────

@dataclass
class SimConfig:
    """All tunable parameters for one static experimental condition."""

    # Scenario
    n_agents:           int   = 4
    n_trials:           int   = 500

    # Clock model — offsets drawn i.i.d. N(0, clock_offset_std²) at t=0
    clock_offset_std_s: float = 1 * MS

    # UWB — IEEE 802.15.4z, 500 MHz signal bandwidth
    uwb_enabled:        bool  = True
    uwb_bandwidth_hz:   float = 500e6
    uwb_snr_db:         float = 20.0
    uwb_max_range_m:    float = 50.0

    # 5G time anchor — σ_rstd ≈ 3–10 ns (3GPP TR 38.857)
    rstd_enabled:       bool  = True
    rstd_std_s:         float = 5 * NS

    # GNSS — 100 ns absolute accuracy; spoofing injects a silent bias
    gnss_enabled:       bool  = True
    gnss_std_s:         float = 100 * NS
    gnss_spoofed:       bool  = False
    gnss_spoof_bias_s:  float = 50 * US

    # IMU dead-reckoning
    # Position uncertainty from double-integrating accelerometer noise:
    #   σ_pos = σ_accel · Δt² / 2
    # Timing equivalent via c:  σ_τ = σ_pos / c = σ_accel · Δt² / (2c)
    imu_enabled:        bool  = False
    imu_accel_std:      float = 0.1    # m/s², MEMS IMU 1-σ noise density
    imu_dt:             float = 0.1    # s, dead-reckoning interval

    # CP safety requirement
    target_rmse_s:      float = 5 * MS


@dataclass
class EKFConfig:
    """Parameters for the dynamic (Kalman filter) clock-tracking experiment."""
    n_agents:                int   = 4
    n_steps:                 int   = 100     # time steps to simulate
    dt_s:                    float = 0.1     # step size [s]
    drift_walk_std:          float = 1e-8    # oscillator freq. random-walk [s/s per √s]
    clock_offset_std_s:      float = 1 * MS
    clock_drift_std_s_per_s: float = 1e-7   # initial drift spread [s/s]
    uwb_bandwidth_hz:        float = 500e6
    uwb_snr_db:              float = 20.0
    uwb_max_range_m:         float = 50.0
    rstd_std_s:              float = 5 * NS
    gnss_enabled:            bool  = False
    gnss_std_s:              float = 100 * NS
    spacing_m:               float = 25.0


# ── Noise model ────────────────────────────────────────────────────────────

def uwb_noise_std(bw_hz: float, snr_db: float) -> float:
    """RMS timing noise for one UWB TOF measurement [seconds].
    σ_τ = 1 / (2π·β·√SNR)  [Van Trees, 2001, §2.4]
    """
    return 1.0 / (2.0 * np.pi * bw_hz * np.sqrt(10.0 ** (snr_db / 10.0)))


# ── FIM construction ───────────────────────────────────────────────────────

def build_fim(cfg: SimConfig, agent_positions: np.ndarray) -> np.ndarray:
    """
    N×N Fisher Information Matrix for clock-offset estimation.

    J_total = J_uwb + J_rstd + J_gnss + J_imu

    UWB contributes a graph-Laplacian term (rank N-1, no absolute reference).
    5G-TA / GNSS / IMU each add a diagonal term, making J full-rank.
    """
    N = cfg.n_agents
    J = np.zeros((N, N))

    # UWB: z_ij = τ_i − τ_j + n,  n ~ N(0, σ²_uwb)
    # J_uwb = (1/σ²_uwb) · graph Laplacian  (rank N-1)
    if cfg.uwb_enabled:
        prec_uwb = 1.0 / uwb_noise_std(cfg.uwb_bandwidth_hz, cfg.uwb_snr_db) ** 2
        for i, j in combinations(range(N), 2):
            if np.linalg.norm(agent_positions[i] - agent_positions[j]) <= cfg.uwb_max_range_m:
                d = np.zeros(N)
                d[i], d[j] = +1.0, -1.0
                J += prec_uwb * np.outer(d, d)

    # 5G network time anchor: z_i = τ_i + n,  n ~ N(0, σ²_rstd)  → diagonal term.
    # This is an absolute network-time observation (e.g. 5G NR time
    # distribution / SIB9 + propagation-delay compensation, or PTP), NOT an
    # RSTD/TDOA positioning measurement: RSTD is differential across gNBs and
    # the UE clock offset cancels, so it carries no information on τ_i.
    if cfg.rstd_enabled:
        J += (1.0 / cfg.rstd_std_s ** 2) * np.eye(N)

    # GNSS: same structure as 5G-TA; zeroed under spoofing (FIM cannot model bias)
    if cfg.gnss_enabled and not cfg.gnss_spoofed:
        J += (1.0 / cfg.gnss_std_s ** 2) * np.eye(N)

    # IMU: kinematic dead-reckoning constrains timing through position consistency.
    # σ_τ = σ_accel · Δt² / (2c)  → diagonal precision term per agent.
    if cfg.imu_enabled:
        sigma_tau_imu = cfg.imu_accel_std * cfg.imu_dt ** 2 / (2.0 * C_LIGHT)
        J += (1.0 / sigma_tau_imu ** 2) * np.eye(N)

    return J


def crb_from_fim(J: np.ndarray) -> tuple[np.ndarray, float]:
    """
    Invert J to get the CRB covariance matrix.
    Returns (cov_crb, sigma_crb); sigma_crb = inf when J is rank-deficient
    (no absolute timing reference — UWB-only case).
    """
    if np.linalg.matrix_rank(J) < J.shape[0]:
        return np.linalg.pinv(J), float("inf")
    cov_crb = np.linalg.inv(J)
    return cov_crb, float(np.sqrt(np.mean(np.diag(cov_crb))))


# ── Measurement generation ─────────────────────────────────────────────────

def generate_measurements(
    tau_true: np.ndarray,
    cfg: SimConfig,
    agent_positions: np.ndarray,
    rng: np.random.Generator,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return (H, z, W) for all enabled side-channels."""
    N = cfg.n_agents
    H_rows, z_rows, W_rows = [], [], []

    if cfg.uwb_enabled:
        sig  = uwb_noise_std(cfg.uwb_bandwidth_hz, cfg.uwb_snr_db)
        prec = 1.0 / sig ** 2
        for i, j in combinations(range(N), 2):
            if np.linalg.norm(agent_positions[i] - agent_positions[j]) <= cfg.uwb_max_range_m:
                h = np.zeros(N); h[i], h[j] = +1.0, -1.0
                H_rows.append(h)
                z_rows.append(tau_true[i] - tau_true[j] + rng.normal(0.0, sig))
                W_rows.append(prec)

    if cfg.rstd_enabled:
        prec = 1.0 / cfg.rstd_std_s ** 2
        for i in range(N):
            h = np.zeros(N); h[i] = 1.0
            H_rows.append(h)
            z_rows.append(tau_true[i] + rng.normal(0.0, cfg.rstd_std_s))
            W_rows.append(prec)

    if cfg.gnss_enabled:
        prec = 1.0 / cfg.gnss_std_s ** 2
        for i in range(N):
            h    = np.zeros(N); h[i] = 1.0
            bias = cfg.gnss_spoof_bias_s if cfg.gnss_spoofed else 0.0
            H_rows.append(h)
            # WLS uses nominal σ_gnss even under spoofing — this is why RMSE >> CRB
            z_rows.append(tau_true[i] + bias + rng.normal(0.0, cfg.gnss_std_s))
            W_rows.append(prec)

    if not H_rows:
        raise ValueError("No side-channels enabled.")

    return np.array(H_rows), np.array(z_rows), np.array(W_rows)


# ── WLS estimator ──────────────────────────────────────────────────────────

def wls_estimate(H, z, W):
    """τ̂_wls = (HᵀWH)⁻¹ Hᵀ W z  — MVUE for linear-Gaussian models."""
    Wm  = np.diag(W)
    cov = np.linalg.pinv(H.T @ Wm @ H)
    return cov @ (H.T @ Wm @ z), cov


# ── Monte Carlo sweep ─────────────────────────────────────────────────────

def run_trial(cfg, agent_positions, rng):
    tau_true   = rng.normal(0.0, cfg.clock_offset_std_s, size=cfg.n_agents)
    H, z, W    = generate_measurements(tau_true, cfg, agent_positions, rng)
    tau_est, _ = wls_estimate(H, z, W)
    return float(np.mean((tau_est - tau_true) ** 2))


def run_condition(cfg: SimConfig) -> dict:
    rng     = np.random.default_rng(seed=42)
    spacing = cfg.uwb_max_range_m / 2.0
    pos     = np.column_stack([np.arange(cfg.n_agents) * spacing, np.zeros(cfg.n_agents)])

    _, sigma_crb = crb_from_fim(build_fim(cfg, pos))
    # RMSE over all trials and agents: sqrt of the mean squared error, which is
    # the quantity bounded by sqrt(mean(diag(J^-1))). Averaging per-trial RMS
    # values instead (as in v1) is biased low by Jensen's inequality.
    sq_errs      = np.array([run_trial(cfg, pos, rng) for _ in range(cfg.n_trials)])
    sigma_emp    = float(np.sqrt(np.mean(sq_errs)))

    return {
        "crb_s":     sigma_crb,
        "rmse_s":    sigma_emp,
        "eff":       sigma_emp / sigma_crb if np.isfinite(sigma_crb) else float("inf"),
        "meets_5ms": sigma_emp < cfg.target_rmse_s,
    }


# ── Spoofing detection ─────────────────────────────────────────────────────

HAUSMAN_EIG_RTOL = 1e-3


def spoof_detection_statistic(cfg_all, cfg_no_gnss, pos, rng):
    """
    Hausman-type GNSS consistency test on a single shared measurement set.

    One set of measurements (UWB + timing anchor + GNSS) is drawn.  τ is
    estimated twice from that same set: with all rows (τ̂_all) and with the
    GNSS rows removed (τ̂_no_gnss).  Under H₀ (no spoofing) τ̂_all is efficient,
    so Cov(τ̂_no_gnss − τ̂_all) = Σ_no_gnss − Σ_all and

        T = dᵀ (Σ_no_gnss − Σ_all)⁺ d  ~  χ²(N),   d = τ̂_all − τ̂_no_gnss.

    A GNSS bias shifts d and inflates T.  cfg_no_gnss is kept for API
    compatibility; the reduced estimator is formed by dropping GNSS rows.
    """
    N        = cfg_all.n_agents
    tau_true = rng.normal(0.0, cfg_all.clock_offset_std_s, size=N)

    H, z, W = generate_measurements(tau_true, cfg_all, pos, rng)
    n_gnss  = N if cfg_all.gnss_enabled else 0
    keep    = slice(0, H.shape[0] - n_gnss)

    tau_a, cov_a = wls_estimate(H, z, W)
    tau_n, cov_n = wls_estimate(H[keep], z[keep], W[keep])

    d     = tau_a - tau_n
    cov_d = cov_n - cov_a
    cov_d = 0.5 * (cov_d + cov_d.T)
    # UWB pins the inter-agent offsets far more tightly than GNSS does, so
    # Σ_noGNSS − Σ_all is numerically rank-deficient: GNSS mainly informs the
    # common-mode offset.  Test only in its well-conditioned eigen-subspace.
    w, V = np.linalg.eigh(cov_d)
    keep_ev = w > HAUSMAN_EIG_RTOL * w.max()
    proj = V[:, keep_ev].T @ d
    return float(np.sum(proj ** 2 / w[keep_ev]))


def hausman_dof(cfg_all, pos):
    """Degrees of freedom of the Hausman statistic (rank of Σ_noGNSS − Σ_all)."""
    N = cfg_all.n_agents
    cov_a = np.linalg.inv(build_fim(cfg_all, pos))
    cfg_n = SimConfig(**{**cfg_all.__dict__, "gnss_enabled": False})
    cov_n = np.linalg.inv(build_fim(cfg_n, pos))
    w = np.linalg.eigvalsh(0.5 * ((cov_n - cov_a) + (cov_n - cov_a).T))
    return int(np.sum(w > HAUSMAN_EIG_RTOL * w.max()))


def calibrate_spoof_threshold(
    cfg_nom: SimConfig,
    cfg_no_gnss: SimConfig,
    pos: np.ndarray,
    target_far: float = 0.003,
    n_cal: int = 2000,
) -> float:
    """Empirical detection threshold at target FAR from the H₀ (no-spoofing) distribution."""
    rng = np.random.default_rng(seed=99)
    Ts  = np.array([spoof_detection_statistic(cfg_nom, cfg_no_gnss, pos, rng)
                    for _ in range(n_cal)])
    return float(np.quantile(Ts, 1.0 - target_far))


# ── Joint pose-timing FIM ─────────────────────────────────────────────────

def build_joint_fim(
    cfg: SimConfig,
    agent_positions: np.ndarray,
    gps_pos_std_m: Optional[float] = None,
) -> np.ndarray:
    """
    3N × 3N Fisher Information Matrix for joint position + clock estimation.

    State order per agent: [x_i, y_i, τ_i]  →  full state is 3N-dimensional.

    UWB one-way TOA measurement model (couples position and timing):
        z_ij = ||p_i − p_j|| / c + (τ_i − τ_j) + n,   n ~ N(0, σ²_uwb)

    Jacobian (3N vector):
        ∂z/∂x_i  =  Δx / (dist · c)
        ∂z/∂y_i  =  Δy / (dist · c)
        ∂z/∂τ_i  = +1
        ∂z/∂x_j  = −Δx / (dist · c)
        ∂z/∂y_j  = −Δy / (dist · c)
        ∂z/∂τ_j  = −1

    5G-TA and GNSS contribute only to the τ sub-block (no position information).

    gps_pos_std_m : if given, adds independent GPS position constraints to make
                    the position sub-block full-rank, enabling a full-matrix
                    inversion for the timing marginal CRB.
    """
    N  = cfg.n_agents
    J3 = np.zeros((3 * N, 3 * N))

    if cfg.uwb_enabled:
        prec_uwb = 1.0 / uwb_noise_std(cfg.uwb_bandwidth_hz, cfg.uwb_snr_db) ** 2
        for i, j in combinations(range(N), 2):
            dp   = agent_positions[i] - agent_positions[j]
            dist = np.linalg.norm(dp)
            if dist < 1e-9 or dist > cfg.uwb_max_range_m:
                continue
            h = np.zeros(3 * N)
            h[3*i],   h[3*i+1] =  dp[0] / (dist * C_LIGHT),  dp[1] / (dist * C_LIGHT)
            h[3*i+2]            = +1.0
            h[3*j],   h[3*j+1] = -dp[0] / (dist * C_LIGHT), -dp[1] / (dist * C_LIGHT)
            h[3*j+2]            = -1.0
            J3 += prec_uwb * np.outer(h, h)

    if cfg.rstd_enabled:
        prec_rstd = 1.0 / cfg.rstd_std_s ** 2
        for i in range(N):
            h = np.zeros(3 * N); h[3*i+2] = 1.0
            J3 += prec_rstd * np.outer(h, h)

    if cfg.gnss_enabled and not cfg.gnss_spoofed:
        prec_gnss = 1.0 / cfg.gnss_std_s ** 2
        for i in range(N):
            h = np.zeros(3 * N); h[3*i+2] = 1.0
            J3 += prec_gnss * np.outer(h, h)

    if gps_pos_std_m is not None:
        prec_pos = 1.0 / gps_pos_std_m ** 2
        for i in range(N):
            for k in range(2):      # x and y independently
                h = np.zeros(3 * N); h[3*i + k] = 1.0
                J3 += prec_pos * np.outer(h, h)

    return J3


def _joint_timing_crb(J3: np.ndarray, N: int) -> float:
    """
    Timing marginal CRB from the 3N×3N joint FIM.

    Extracted from the diagonal of J3⁻¹ at the τ indices — equivalent to
    the Schur complement of the position sub-block. slogdet is used rather
    than matrix_rank: the extreme condition number (~10²¹ when UWB timing
    precision dominates GPS position precision) causes matrix_rank to
    falsely declare full-rank matrices as rank-deficient.
    """
    tau_idx = np.arange(2, 3 * N, 3)          # indices 2, 5, 8, …
    pos_idx = np.setdiff1d(np.arange(3 * N), tau_idx)
    # Schur complement: timing information after marginalising positions.
    # pinv on the position block handles its translation/rotation gauge
    # (positions unobservable from ranges alone) without discarding the
    # timing information that remains.
    J_tt = J3[np.ix_(tau_idx, tau_idx)]
    J_tp = J3[np.ix_(tau_idx, pos_idx)]
    J_pp = J3[np.ix_(pos_idx, pos_idx)]
    J_eff = J_tt - J_tp @ np.linalg.pinv(J_pp, rcond=1e-12, hermitian=True) @ J_tp.T
    J_eff = 0.5 * (J_eff + J_eff.T)
    w = np.linalg.eigvalsh(J_eff)
    if w.min() <= 1e-9 * w.max():
        return float("inf")
    tau_vars = np.diag(np.linalg.inv(J_eff))
    return float(np.sqrt(np.mean(tau_vars)))


# ── EKF for dynamic clock drift ───────────────────────────────────────────

def _build_ekf_matrices(cfg: EKFConfig):
    """
    Constant KF matrices for the 2N-dimensional clock state.

    State:  x = [τ₁, d₁, τ₂, d₂, …, τN, dN]
    where τ_i is clock offset and d_i is fractional frequency drift (s/s).

    Per-agent transition block (step size dt):
        F_i = [[1, dt],   Q_i = σ_w² · [[dt², dt],
               [0,  1]]                   [dt,   1]]

    σ_w = drift_walk_std · √dt  is the per-step drift noise standard deviation,
    consistent with a white frequency noise (random-walk drift) oscillator model.
    """
    N  = cfg.n_agents
    dt = cfg.dt_s
    sw = cfg.drift_walk_std * np.sqrt(dt)

    F_blk = np.array([[1.0, dt], [0.0, 1.0]])
    G     = np.array([dt, 1.0])
    Q_blk = sw ** 2 * np.outer(G, G)

    F  = np.zeros((2*N, 2*N))
    Q  = np.zeros((2*N, 2*N))
    P0 = np.zeros((2*N, 2*N))
    for i in range(N):
        s = slice(2*i, 2*i+2)
        F[s, s]  = F_blk
        Q[s, s]  = Q_blk
        P0[2*i,   2*i]   = cfg.clock_offset_std_s ** 2
        P0[2*i+1, 2*i+1] = cfg.clock_drift_std_s_per_s ** 2

    return F, Q, P0


def _ekf_meas(x_true, cfg: EKFConfig, pos, rng):
    """Build (H, z, R) measurement triplet for the 2N EKF state at one step."""
    N        = cfg.n_agents
    tau_true = x_true[::2]     # even indices hold τ
    H_rows, z_rows, R_diag = [], [], []

    sig_uwb = uwb_noise_std(cfg.uwb_bandwidth_hz, cfg.uwb_snr_db)
    for i, j in combinations(range(N), 2):
        if np.linalg.norm(pos[i] - pos[j]) <= cfg.uwb_max_range_m:
            h = np.zeros(2*N); h[2*i], h[2*j] = +1.0, -1.0
            H_rows.append(h)
            z_rows.append(tau_true[i] - tau_true[j] + rng.normal(0.0, sig_uwb))
            R_diag.append(sig_uwb ** 2)

    for i in range(N):
        h = np.zeros(2*N); h[2*i] = 1.0
        H_rows.append(h)
        z_rows.append(tau_true[i] + rng.normal(0.0, cfg.rstd_std_s))
        R_diag.append(cfg.rstd_std_s ** 2)

    if cfg.gnss_enabled:
        for i in range(N):
            h = np.zeros(2*N); h[2*i] = 1.0
            H_rows.append(h)
            z_rows.append(tau_true[i] + rng.normal(0.0, cfg.gnss_std_s))
            R_diag.append(cfg.gnss_std_s ** 2)

    return np.array(H_rows), np.array(z_rows), np.diag(R_diag)


def run_ekf_trial(cfg: EKFConfig, rng: np.random.Generator) -> np.ndarray:
    """One KF trial; returns per-step timing RMSE [seconds] over n_steps."""
    N  = cfg.n_agents
    sw = cfg.drift_walk_std * np.sqrt(cfg.dt_s)

    pos      = np.column_stack([np.arange(N) * cfg.spacing_m, np.zeros(N)])
    F, Q, P0 = _build_ekf_matrices(cfg)
    I2N      = np.eye(2 * N)

    x_true       = np.zeros(2 * N)
    x_true[::2]  = rng.normal(0.0, cfg.clock_offset_std_s, N)
    x_true[1::2] = rng.normal(0.0, cfg.clock_drift_std_s_per_s, N)

    x_est, P = np.zeros(2 * N), P0.copy()
    rmses    = np.zeros(cfg.n_steps)

    for k in range(cfg.n_steps):
        w        = np.zeros(2 * N)
        w[1::2]  = rng.normal(0.0, sw, N)
        x_true   = F @ x_true + w

        x_pred = F @ x_est
        P_pred = F @ P @ F.T + Q

        H, z, R = _ekf_meas(x_true, cfg, pos, rng)
        S       = H @ P_pred @ H.T + R
        K       = P_pred @ H.T @ np.linalg.inv(S)
        x_est   = x_pred + K @ (z - H @ x_pred)
        P       = (I2N - K @ H) @ P_pred

        rmses[k] = np.sqrt(np.mean((x_est[::2] - x_true[::2]) ** 2))

    return rmses


# ── Formatting helpers ─────────────────────────────────────────────────────

def _fmt_time(val_s: float) -> str:
    """Auto-scale a time value to ns / µs / ms."""
    if not np.isfinite(val_s):
        return "∞"
    if val_s < 1e-6:
        return f"{val_s*1e9:.2f} ns"
    if val_s < 1e-3:
        return f"{val_s*1e6:.2f} µs"
    return f"{val_s*1e3:.2f} ms"


def _print_table(rows, headers):
    if HAS_TABULATE:
        print(tabulate(rows, headers=headers, tablefmt="github"))
    else:
        print("\t".join(headers))
        for r in rows:
            print("\t".join(str(x) for x in r))


def _md_table(headers: list, rows: list) -> str:
    """Render a plain Markdown pipe table."""
    def _cell(v):
        return str(v).replace("|", "\\|")
    header = "| " + " | ".join(_cell(h) for h in headers) + " |"
    sep    = "|" + "|".join(":---:" for _ in headers) + "|"
    body   = ["| " + " | ".join(_cell(c) for c in row) + " |" for row in rows]
    return "\n".join([header, sep] + body)


def _save_fig(fig, filename: str) -> str:
    """Save figure to PLOT_DIR and return the full path."""
    path = os.path.join(PLOT_DIR, filename)
    fig.savefig(path, dpi=200, bbox_inches="tight")
    plt.close(fig)
    print(f"  Plot saved → {path}")
    return path


# ── Experiment 1: CRB verification sweep ──────────────────────────────────

def run_experiment() -> dict:
    """Sweep N ∈ {2, 4, 8} × channel combination; verify WLS achieves CRB."""
    conditions = []
    for n in [2, 4, 8]:
        base = dict(n_agents=n, n_trials=500)
        conditions += [
            ("UWB only",        n, SimConfig(**base, uwb_enabled=True,
                                             rstd_enabled=False, gnss_enabled=False)),
            ("UWB + 5G time anchor",   n, SimConfig(**base, uwb_enabled=True,
                                             rstd_enabled=True,  gnss_enabled=False)),
            ("UWB + 5G + GNSS", n, SimConfig(**base, uwb_enabled=True,
                                             rstd_enabled=True,  gnss_enabled=True)),
            ("UWB+5G+GNSS*",    n, SimConfig(**base, uwb_enabled=True,
                                             rstd_enabled=True,  gnss_enabled=True,
                                             gnss_spoofed=True)),
        ]

    headers = ["N", "Side-channels", "CRB σ", "RMSE σ", "RMSE/CRB", "≤5 ms?"]
    rows = []
    for label, n, cfg in conditions:
        try:
            r = run_condition(cfg)
            rows.append([
                n, label,
                _fmt_time(r["crb_s"]) if np.isfinite(r["crb_s"]) else "∞ (rank-def.)",
                _fmt_time(r["rmse_s"]),
                f"{r['eff']:.2f}"     if np.isfinite(r["crb_s"]) else "—",
                ("✓" if r["meets_5ms"] else "✗") if np.isfinite(r["crb_s"]) else "n/a (unobservable)",
            ])
        except Exception as e:
            rows.append([n, label, "error", str(e), "—", "✗"])

    print("\nCRISP-CAV Experiment 3: Cramér–Rao Bound Verification (FQ3)")
    print("=" * 72)
    _print_table(rows, headers)
    print("\n* GNSS spoofed: 50 µs bias. CRB = model without GNSS; WLS still trusts GNSS, so RMSE is bias-dominated.")
    print("  Target: σ < 5 ms for CP accuracy budget at 100 km/h.")

    # ── Plot: CRB scaling with N ──
    images = []
    if HAS_MPL:
        n_vals   = np.arange(2, 13)
        spacing  = 25.0

        channel_cfgs = [
            ("UWB + 5G-TA",        dict(uwb_enabled=True, rstd_enabled=True,  gnss_enabled=False)),
            ("UWB + 5G-TA + GNSS", dict(uwb_enabled=True, rstd_enabled=True,  gnss_enabled=True)),
        ]
        colors = ["steelblue", "darkorange"]

        fig, ax = plt.subplots(figsize=(7, 4))
        for (label, kw), color in zip(channel_cfgs, colors):
            crbs = []
            for n in n_vals:
                pos = np.column_stack([np.arange(n) * spacing, np.zeros(n)])
                cfg = SimConfig(n_agents=n, **kw)
                _, s = crb_from_fim(build_fim(cfg, pos))
                crbs.append(s * 1e9 if np.isfinite(s) else np.nan)
            ax.plot(n_vals, crbs, "o-", color=color, label=label, markersize=5)

        ax.axhline(5e6, color="red", ls="--", lw=1.2, label="5 ms CP target")
        ax.set_xlabel("Number of agents N")
        ax.set_ylabel("CRB σ (ns)")
        ax.set_title("CRB Scaling with Agent Count\n(25 m spacing, UWB 500 MHz / 20 dB SNR)")
        ax.legend()
        ax.set_yscale("log")
        ax.yaxis.set_major_formatter(mticker.FuncFormatter(
            lambda x, _: f"{x:.0f}" if x >= 1 else f"{x:.2f}"))
        ax.grid(True, which="both", alpha=0.3)
        fig.tight_layout()
        images.append(_save_fig(fig, "crb_vs_n.png"))

        # ── Plot: CRB vs N with WLS RMSE overlay (bar chart) ──
        n_sweep = [2, 4, 8]
        bar_labels = ["UWB+5G-TA", "UWB+5G-TA\n+GNSS", "UWB+5G-TA\n+GNSS*"]
        bar_cfgs = [
            SimConfig(uwb_enabled=True, rstd_enabled=True,  gnss_enabled=False),
            SimConfig(uwb_enabled=True, rstd_enabled=True,  gnss_enabled=True),
            SimConfig(uwb_enabled=True, rstd_enabled=True,  gnss_enabled=True,
                      gnss_spoofed=True),
        ]
        fig, axes = plt.subplots(1, 3, figsize=(11, 4), sharey=False)
        for ax, n in zip(axes, n_sweep):
            pos = np.column_stack([np.arange(n) * spacing, np.zeros(n)])
            crb_vals, rmse_vals = [], []
            for cfg in bar_cfgs:
                cfg.n_agents  = n
                cfg.n_trials  = 500
                _, sc = crb_from_fim(build_fim(cfg, pos))
                crb_vals.append(sc * 1e9 if np.isfinite(sc) else np.nan)
                rng2 = np.random.default_rng(42)
                rmses2 = [run_trial(cfg, pos, rng2) for _ in range(500)]
                rmse_vals.append(float(np.sqrt(np.mean(rmses2))) * 1e9)

            x = np.arange(len(bar_labels))
            w = 0.35
            ax.bar(x - w/2, crb_vals,  w, label="CRB",  color="steelblue", alpha=0.8)
            ax.bar(x + w/2, rmse_vals, w, label="RMSE", color="darkorange", alpha=0.8)
            ax.set_xticks(x)
            ax.set_xticklabels(bar_labels, fontsize=8)
            ax.set_title(f"N = {n}")
            ax.set_ylabel("σ (ns)")
            ax.set_yscale("log")
            ax.grid(True, axis="y", alpha=0.3)
            if ax == axes[0]:
                ax.legend(fontsize=8)

        fig.suptitle("CRB vs. WLS RMSE by Channel Combination\n(* = GNSS spoofed)")
        fig.tight_layout()
        images.append(_save_fig(fig, "crb_vs_rmse_bars.png"))

        # ── Plot: Agent network topology with per-agent CRB coloring ──
        sq_pos = np.array([[0.0, 0.0], [25.0, 0.0], [25.0, 25.0], [0.0, 25.0]])
        sq_N   = 4
        topo_cfgs = [
            ("UWB + 5G-TA",
             SimConfig(n_agents=sq_N, uwb_enabled=True, rstd_enabled=True,
                       gnss_enabled=False)),
            ("UWB + 5G-TA + GNSS",
             SimConfig(n_agents=sq_N, uwb_enabled=True, rstd_enabled=True,
                       gnss_enabled=True)),
            ("UWB+5G-TA+GNSS\n(spoofed)",
             SimConfig(n_agents=sq_N, uwb_enabled=True, rstd_enabled=True,
                       gnss_enabled=True, gnss_spoofed=True)),
        ]
        fig, axes = plt.subplots(1, 3, figsize=(13, 4.5))
        for ax, (label, cfg) in zip(axes, topo_cfgs):
            J      = build_fim(cfg, sq_pos)
            cov, _ = crb_from_fim(J)
            per_ns = np.sqrt(np.diag(cov)) * 1e9

            for i, j in combinations(range(sq_N), 2):
                if np.linalg.norm(sq_pos[i] - sq_pos[j]) <= cfg.uwb_max_range_m:
                    ax.plot([sq_pos[i, 0], sq_pos[j, 0]],
                            [sq_pos[i, 1], sq_pos[j, 1]],
                            "k-", lw=1.5, alpha=0.25, zorder=1)

            sc = ax.scatter(sq_pos[:, 0], sq_pos[:, 1], c=per_ns,
                            cmap="plasma_r", s=320, zorder=3,
                            edgecolors="k", lw=0.8)
            cb = fig.colorbar(sc, ax=ax, shrink=0.72, pad=0.02)
            cb.set_label("Per-agent CRB σ (ns)", fontsize=7)
            for i in range(sq_N):
                ax.annotate(f"A{i}\n{per_ns[i]:.2f} ns", sq_pos[i],
                            xytext=(0, 14), textcoords="offset points",
                            ha="center", fontsize=7)
            ax.set_title(label, fontsize=9)
            ax.set_xlabel("x (m)")
            ax.set_ylabel("y (m)")
            ax.set_xlim(-12, 37)
            ax.set_ylim(-12, 37)
            ax.set_aspect("equal")
            ax.grid(True, alpha=0.3)
        fig.suptitle("Agent Network Topology: Per-Agent Timing CRB\n"
                     "(N=4, 25 m square layout, UWB max range 50 m)")
        fig.tight_layout()
        images.append(_save_fig(fig, "agent_topology.png"))

        # ── Plot: CRB heatmap (optimal 4th-agent placement) ──
        fixed3   = np.array([[0.0, 0.0], [25.0, 0.0], [50.0, 0.0]])
        gx       = np.linspace(-30, 80, 55)
        gy       = np.linspace(-40, 40, 55)
        GX, GY   = np.meshgrid(gx, gy)
        CRB_MAP  = np.full_like(GX, np.nan)
        cfg_hmap = SimConfig(n_agents=4, uwb_enabled=True, rstd_enabled=True,
                             gnss_enabled=False)
        for ri in range(GX.shape[0]):
            for ci in range(GX.shape[1]):
                p4 = np.vstack([fixed3, [[GX[ri, ci], GY[ri, ci]]]])
                _, s = crb_from_fim(build_fim(cfg_hmap, p4))
                CRB_MAP[ri, ci] = s * 1e9 if np.isfinite(s) else np.nan

        fig, ax = plt.subplots(figsize=(8, 5))
        hm = ax.contourf(GX, GY, CRB_MAP, levels=25, cmap="viridis_r")
        ax.contour(GX, GY, CRB_MAP, levels=10,
                   colors="white", alpha=0.25, linewidths=0.5)
        fig.colorbar(hm, ax=ax, label="Joint CRB σ (ns)")
        ax.scatter(fixed3[:, 0], fixed3[:, 1], c="red", s=140, zorder=5,
                   edgecolors="white", lw=1.5, label="Fixed agents (A0–A2)")
        ax.set_xlabel("4th agent x (m)")
        ax.set_ylabel("4th agent y (m)")
        ax.set_title("CRB Heatmap: Optimal Placement of 4th Agent\n"
                     "(A0=(0,0), A1=(25,0), A2=(50,0) fixed — UWB+5G-TA, 500 MHz / 20 dB)")
        ax.set_aspect("equal")
        ax.legend(fontsize=8)
        ax.grid(True, alpha=0.2)
        fig.tight_layout()
        images.append(_save_fig(fig, "crb_heatmap.png"))

    return {
        "title": "1. CRB Verification Sweep",
        "intro": (
            "WLS achieves the Cramér–Rao Bound across N ∈ {2, 4, 8} agents and all "
            "side-channel combinations. UWB-only FIM is rank-deficient (no absolute "
            "reference); adding a 5G network time anchor resolves it. RMSE is pooled "
            "over all trials and agents (√mean e²), so RMSE/CRB → 1 for an efficient "
            "estimator. The 5 ms column is met by every observable configuration and "
            "is not a discriminating test."
        ),
        "tables": [{"caption": None, "headers": headers, "rows": rows}],
        "notes": [
            "\\* GNSS spoofed: 50 µs injected bias. CRB shown is for the model without GNSS; the WLS estimator still trusts GNSS, so RMSE is bias-dominated (model misspecification, not a CRB violation).",
            "Target: σ < 5 ms for CP accuracy budget at 100 km/h.",
        ],
        "images": images,
    }


# ── Experiment 2: Multipath / NLOS degradation ───────────────────────────

def run_multipath_experiment() -> dict:
    """
    Show how the timing CRB degrades as UWB SNR drops in multipath environments.

    The interesting regime is when σ_uwb approaches σ_rstd (5 ns), which for
    500 MHz bandwidth requires SNR around −25 dB (severe NLOS).  The metric is
    the UWB improvement factor: CRB(5G-TA only) / CRB(UWB + 5G-TA).
    """
    print("\n── Multipath / NLOS Degradation ──")
    print("  UWB + 5G time anchor, N = 4 agents, spacing 25 m")
    print("  Improvement = CRB(5G-TA only) / CRB(UWB + 5G-TA)\n")

    ENVS = [
        ("Open road",        500e6,  20.0),
        ("Urban canyon",     500e6, -10.0),
        ("Moderate NLOS",    500e6, -20.0),
        ("Severe NLOS",      100e6, -25.0),
    ]

    N, spacing = 4, 25.0
    pos = np.column_stack([np.arange(N) * spacing, np.zeros(N)])

    cfg_rstd_only = SimConfig(n_agents=N, uwb_enabled=False,
                               rstd_enabled=True, gnss_enabled=False)
    _, sigma_rstd = crb_from_fim(build_fim(cfg_rstd_only, pos))

    headers = ["Environment", "UWB BW", "UWB SNR", "σ_uwb", "Joint CRB", "Improvement"]
    rows = []
    for env, bw, snr in ENVS:
        sig_uwb = uwb_noise_std(bw, snr)
        cfg     = SimConfig(n_agents=N, uwb_enabled=True, uwb_bandwidth_hz=bw,
                            uwb_snr_db=snr, rstd_enabled=True, gnss_enabled=False)
        _, sigma_joint = crb_from_fim(build_fim(cfg, pos))
        improvement    = sigma_rstd / sigma_joint if np.isfinite(sigma_joint) else float("inf")
        rows.append([
            env, f"{bw/1e6:.0f} MHz", f"{snr:.0f} dB",
            _fmt_time(sig_uwb), _fmt_time(sigma_joint), f"{improvement:.2f}×",
        ])

    _print_table(rows, headers)
    print(f"\n  5G-TA-only baseline CRB: {_fmt_time(sigma_rstd)}")
    print("  Improvement → 1.0× when σ_uwb >> σ_rstd (UWB contributes nothing).")

    # ── Plot: CRB vs SNR (continuous sweep) for two bandwidths ──
    images = []
    if HAS_MPL:
        snr_db_vals = np.linspace(-30, 25, 200)
        bw_configs  = [
            ("500 MHz (std.)",  500e6, "steelblue"),
            ("100 MHz (NLOS)",  100e6, "darkorange"),
        ]

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4))

        for label, bw, color in bw_configs:
            crbs, improvements = [], []
            for snr in snr_db_vals:
                cfg = SimConfig(n_agents=N, uwb_enabled=True, uwb_bandwidth_hz=bw,
                                uwb_snr_db=snr, rstd_enabled=True, gnss_enabled=False)
                _, s = crb_from_fim(build_fim(cfg, pos))
                crbs.append(s * 1e9)
                improvements.append(sigma_rstd / s if np.isfinite(s) and s > 0 else 1.0)
            ax1.plot(snr_db_vals, crbs,        color=color, label=label)
            ax2.plot(snr_db_vals, improvements, color=color, label=label)

        ax1.axhline(sigma_rstd * 1e9, color="grey", ls="--", lw=1.2,
                    label=f"5G-TA only ({sigma_rstd*1e9:.1f} ns)")
        ax1.set_xlabel("UWB SNR (dB)")
        ax1.set_ylabel("Joint CRB σ (ns)")
        ax1.set_title("CRB vs. UWB SNR\n(UWB + 5G time anchor, N=4)")
        ax1.legend(fontsize=9)
        ax1.grid(True, alpha=0.3)

        ax2.axhline(1.0, color="grey", ls="--", lw=1.2, label="No improvement")
        ax2.set_xlabel("UWB SNR (dB)")
        ax2.set_ylabel("Improvement factor")
        ax2.set_title("UWB Gain over 5G-TA-Only\n(CRB ratio)")
        ax2.legend(fontsize=9)
        ax2.grid(True, alpha=0.3)

        # Annotate the four environments on the CRB plot
        env_pts = [
            ("Open road",        500e6,  20.0, "steelblue"),
            ("Urban canyon",     500e6, -10.0, "steelblue"),
            ("Moderate NLOS",    500e6, -20.0, "steelblue"),
            ("Severe NLOS",      100e6, -25.0, "darkorange"),
        ]
        for ename, bw, snr, ec in env_pts:
            cfg = SimConfig(n_agents=N, uwb_enabled=True, uwb_bandwidth_hz=bw,
                            uwb_snr_db=snr, rstd_enabled=True, gnss_enabled=False)
            _, s = crb_from_fim(build_fim(cfg, pos))
            ax1.plot(snr, s * 1e9, "o", color=ec, ms=7, zorder=5)

        fig.tight_layout()
        images.append(_save_fig(fig, "multipath_snr_sweep.png"))

    return {
        "title": "2. Multipath / NLOS Degradation",
        "intro": (
            f"UWB + 5G time anchor, N = {N} agents, {spacing:.0f} m spacing. "
            f"Improvement = CRB(5G-TA only) / CRB(UWB + 5G-TA). "
            f"5G-TA-only baseline CRB: {_fmt_time(sigma_rstd)}."
        ),
        "tables": [{"caption": None, "headers": headers, "rows": rows}],
        "notes": [
            "Improvement → 1.0× when σ\\_uwb >> σ\\_rstd (UWB contributes nothing).",
            "At severe NLOS (100 MHz / −25 dB) UWB barely improves over 5G-TA alone.",
        ],
        "images": images,
    }


# ── Experiment 3: Spoofing detection with ROC calibration ─────────────────

def run_spoof_detection_experiment() -> dict:
    """
    Calibrate the detection threshold empirically (H₀ quantile at target FAR),
    then evaluate FAR and detection rate on a held-out set.

    Hausman statistic on shared measurements; under H₀, T ~ χ²(N). The
    empirical H₀ quantile is checked against the χ²(N) quantile.
    """
    print("\n── Spoofing Detection with ROC Calibration ──")

    n, spacing = 4, 25.0
    pos = np.column_stack([np.arange(n) * spacing, np.zeros(n)])

    cfg_nom   = SimConfig(n_agents=n, gnss_enabled=True,  gnss_spoofed=False)
    cfg_spoof = SimConfig(n_agents=n, gnss_enabled=True,  gnss_spoofed=True)
    cfg_no_gn = SimConfig(n_agents=n, gnss_enabled=False, rstd_enabled=True)

    from scipy.stats import chi2 as sp_chi2

    target_far = 0.003
    print(f"  Calibrating threshold at {target_far:.1%} FAR (2 000 H₀ trials)…")
    threshold = calibrate_spoof_threshold(cfg_nom, cfg_no_gn, pos,
                                          target_far=target_far, n_cal=2000)
    dof        = hausman_dof(cfg_nom, pos)
    thr_theory = float(sp_chi2.ppf(1.0 - target_far, dof))
    print(f"  Calibrated threshold: {threshold:.2f}   (χ²({dof}) quantile: {thr_theory:.2f})")

    rng_eval = np.random.default_rng(seed=1)
    n_eval   = 2000
    T_noms   = np.array([spoof_detection_statistic(cfg_nom, cfg_no_gn, pos, rng_eval)
                          for _ in range(n_eval)])
    far = float(np.mean(T_noms > threshold))
    print(f"  Nominal — mean T: {T_noms.mean():.2f} (χ²({dof}) mean {dof})   FAR: {far:.2%}")

    biases = [10 * NS, 30 * NS, 100 * NS, 300 * NS, 50 * US]
    stat_headers = ["Condition", "Mean T", "FAR / Detection rate"]
    stat_rows = [["Nominal (H₀)", f"{T_noms.mean():.2f}", f"FAR {far:.2%} (target {target_far:.1%})"]]
    T_by_bias = {}
    for bias in biases:
        cfg_b = SimConfig(n_agents=n, gnss_enabled=True, gnss_spoofed=True,
                          gnss_spoof_bias_s=bias)
        Tb = np.array([spoof_detection_statistic(cfg_b, cfg_no_gn, pos, rng_eval)
                       for _ in range(n_eval)])
        T_by_bias[bias] = Tb
        dr = float(np.mean(Tb > threshold))
        print(f"  Bias {_fmt_time(bias):>10}: mean T {Tb.mean():.3g}   DR {dr:.1%}")
        stat_rows.append([f"Spoofed, common bias {_fmt_time(bias)}", f"{Tb.mean():.3g}", f"DR {dr:.1%}"])

    images = []
    if HAS_MPL:
        fig, axes = plt.subplots(1, 2, figsize=(11, 4))
        ax = axes[0]
        bins = np.linspace(0, max(30, np.percentile(T_noms, 99.9)), 80)
        ax.hist(T_noms, bins=bins, density=True, alpha=0.6, color="steelblue",
                label="H₀ (nominal)")
        xs = np.linspace(0.01, bins[-1], 300)
        ax.plot(xs, sp_chi2.pdf(xs, dof), "k-", lw=1.2, label=f"χ²({dof}) pdf")
        for bias, c in zip(biases[:3], ["orange", "tomato", "darkred"]):
            ax.hist(np.clip(T_by_bias[bias], 0, bins[-1]), bins=bins, density=True,
                    alpha=0.4, color=c, label=f"H₁ bias {_fmt_time(bias)}")
        ax.axvline(threshold, color="black", ls="--", lw=1.5,
                   label=f"Threshold {threshold:.1f} ({target_far:.1%} FAR)")
        ax.set_xlabel("Hausman statistic T"); ax.set_ylabel("Density")
        ax.set_title("T under H₀ and H₁ (shared measurements)")
        ax.legend(fontsize=7); ax.grid(True, alpha=0.3)

        ax = axes[1]
        thresholds = np.linspace(0, np.percentile(T_noms, 99.95), 400)
        fars = np.array([np.mean(T_noms > t) for t in thresholds])
        for bias, c in zip(biases[:4], ["orange", "tomato", "darkred", "purple"]):
            drs = np.array([np.mean(T_by_bias[bias] > t) for t in thresholds])
            ax.plot(fars, drs, color=c, lw=2, label=f"bias {_fmt_time(bias)}")
        ax.plot([0, 1], [0, 1], "k--", lw=0.8, alpha=0.4)
        ax.set_xlabel("False alarm rate"); ax.set_ylabel("Detection rate")
        ax.set_title("ROC vs. GNSS spoof bias")
        ax.set_xscale("log"); ax.set_xlim(1e-3, 1)
        ax.legend(fontsize=8); ax.grid(True, alpha=0.3)
        fig.tight_layout()
        images.append(_save_fig(fig, "spoofing_roc.png"))

    return {
        "title": "3. GNSS Spoofing Detection (Hausman Consistency Test)",
        "intro": (
            "One shared measurement set per trial; τ is estimated with and without the "
            "GNSS rows. T = dᵀ(Σ\\_noGNSS − Σ\\_all)⁺d with d = τ̂\\_all − τ̂\\_noGNSS, "
            f"which is χ²({dof}) under H₀ (rank of the covariance difference; GNSS mainly informs the common-mode offset). Empirical {1-target_far:.1%} threshold "
            f"**{threshold:.2f}** vs. χ²({dof}) quantile {thr_theory:.2f}. "
            "Spoofing removes no information from the FIM: the CRB with GNSS dropped is "
            "the bound for a receiver that rejects GNSS after detection."
        ),
        "tables": [{"caption": f"Evaluation over {n_eval} trials per condition",
                    "headers": stat_headers, "rows": stat_rows}],
        "notes": [
            "A 50 µs bias is trivially detectable; the informative regime is tens to "
            "hundreds of ns, comparable to σ\\_gnss = 100 ns.",
        ],
        "images": images,
    }


# ── Experiment 4: EKF dynamic clock tracking ─────────────────────────────

def run_ekf_experiment() -> dict:
    """
    Kalman filter tracking clock offset τ and drift d per agent.
    State: x = [τ₁, d₁, …, τN, dN].  Linear measurement model → KF is optimal.
    Shows cold-start RMSE converging to CRB-level steady state.
    """
    print("\n── Kalman-Filter Dynamic Clock Tracking ──")
    print("  N=4 agents, 100 steps × 0.1 s, 200 MC trials each\n")

    n_mc = 200
    configs = [
        ("UWB + 5G-TA",        EKFConfig(gnss_enabled=False), "steelblue"),
        ("UWB + 5G-TA + GNSS", EKFConfig(gnss_enabled=True),  "darkorange"),
    ]

    headers = ["Channels", "RMSE @ step 1", "Steady-state RMSE", "Steps to <5 ns"]
    rows = []
    all_rmse_arrays = []
    for label, cfg, color in configs:
        rng          = np.random.default_rng(seed=7)
        rmses        = np.array([run_ekf_trial(cfg, rng) for _ in range(n_mc)])
        all_rmse_arrays.append((label, cfg, color, rmses))
        mean_rmse    = rmses.mean(axis=0)
        rmse_init    = mean_rmse[0]
        rmse_steady  = mean_rmse[-20:].mean()
        steps_to_5ns = next((k for k, r in enumerate(mean_rmse) if r < 5e-9), None)
        rows.append([
            label,
            _fmt_time(rmse_init),
            _fmt_time(rmse_steady),
            f"{steps_to_5ns}" if steps_to_5ns is not None else ">100",
        ])

    _print_table(rows, headers)
    print("\n  Drift walk: 1e-8 s/s/√s (TCXO class oscillator).")

    # ── Plot: convergence curves (mean ± 1σ band) ──
    images = []
    if HAS_MPL:
        cfg_ref  = all_rmse_arrays[0][1]
        steps    = np.arange(cfg_ref.n_steps) * cfg_ref.dt_s

        fig, ax = plt.subplots(figsize=(8, 4))
        for label, cfg, color, rmses in all_rmse_arrays:
            mean_r = rmses.mean(axis=0) * 1e9
            std_r  = rmses.std(axis=0)  * 1e9
            ax.plot(steps, mean_r, color=color, lw=2, label=label)
            ax.fill_between(steps, mean_r - std_r, mean_r + std_r,
                            color=color, alpha=0.15)

        ax.axhline(5.0, color="red", ls="--", lw=1.2, label="5 ns target")
        ax.set_xlabel("Time (s)")
        ax.set_ylabel("Clock offset RMSE (ns)")
        ax.set_title("EKF Convergence: Clock Offset RMSE over Time\n"
                     f"N=4 agents, {n_mc} MC trials — shaded band = ±1σ")
        ax.set_yscale("log")
        ax.set_xlim(0, steps[-1])
        ax.yaxis.set_major_formatter(mticker.FuncFormatter(
            lambda x, _: f"{x:.1f}" if x >= 1 else f"{x:.2f}"))
        ax.legend()
        ax.grid(True, which="both", alpha=0.3)
        fig.tight_layout()
        images.append(_save_fig(fig, "ekf_convergence.png"))

        # ── Plot: per-step RMSE box plot (early steps zoom) ──
        fig, ax = plt.subplots(figsize=(9, 4))
        zoom_steps = [0, 1, 2, 3, 4, 9, 19, 49, 99]
        for label, cfg, color, rmses in all_rmse_arrays:
            data = [rmses[:, k] * 1e9 for k in zoom_steps]
            positions = np.array(zoom_steps) + (0.3 if "GNSS" in label else -0.3)
            ax.boxplot(data, positions=positions, widths=0.4,
                       patch_artist=True,
                       boxprops=dict(facecolor=color, alpha=0.5),
                       medianprops=dict(color="black", lw=1.5),
                       whiskerprops=dict(color=color),
                       capprops=dict(color=color),
                       flierprops=dict(marker=".", color=color, alpha=0.3, ms=3),
                       showfliers=True)

        from matplotlib.patches import Patch as _Patch
        proxy_handles = [_Patch(facecolor=c, alpha=0.5, label=lbl)
                         for lbl, _, c, _ in all_rmse_arrays]
        ax.axhline(5.0, color="red", ls="--", lw=1.2, label="5 ns target")
        ax.set_xticks(zoom_steps)
        ax.set_xticklabels([f"k={k}" for k in zoom_steps])
        ax.set_xlabel("Step index")
        ax.set_ylabel("Clock offset RMSE (ns)")
        ax.set_title("EKF RMSE Distribution at Selected Steps\n"
                     f"N=4 agents, {n_mc} MC trials")
        ax.set_yscale("log")
        proxy_handles.append(
            plt.Line2D([0], [0], color="red", ls="--", lw=1.2, label="5 ns target"))
        ax.legend(handles=proxy_handles)
        ax.grid(True, axis="y", alpha=0.3)
        fig.tight_layout()
        images.append(_save_fig(fig, "ekf_rmse_boxplot.png"))

    return {
        "title": "4. Kalman-Filter Dynamic Clock Tracking",
        "intro": (
            "Kalman filter state: x = [τ₁, d₁, …, τN, dN] (2N-dimensional). "
            "Linear measurement model → KF is the optimal (MVUE) estimator. "
            "N = 4 agents, 100 steps × 0.1 s, 200 MC trials each."
        ),
        "tables": [{"caption": None, "headers": headers, "rows": rows}],
        "notes": [
            "Drift walk: 1×10⁻⁸ s/s/√s — TCXO class oscillator.",
            "KF converges to sub-5 ns RMSE within 2 steps regardless of GNSS availability.",
            "Shaded band in convergence plot = ±1σ across Monte Carlo trials.",
        ],
        "images": images,
    }


# ── Experiment 5: Joint pose-timing FIM ──────────────────────────────────

def run_joint_fim_experiment() -> dict:
    """
    3N-dimensional FIM coupling position [x_i, y_i] and clock offset τ_i.

    UWB TOA:  z_ij = ||p_i − p_j|| / c + (τ_i − τ_j) + n
    The Jacobian couples spatial and timing unknowns.

    Three cases compared:
      1. Timing-only FIM  (N×N):   positions assumed perfectly known.
      2. Joint FIM + GPS  (3N×3N): positions constrained to 1 m accuracy.
      3. Joint FIM, no GPS (3N×3N): positions free; timing CRB from the Schur
         complement with a pseudo-inverse over the position gauge.

    The ratio joint / timing-only quantifies the cost of position uncertainty
    on timing accuracy, motivating GPS or map-matching position aiding.
    """
    print("\n── Joint Pose-Timing FIM ──")
    print("  N=4 agents, 25 m spacing, UWB + 5G-TA")
    print("  Timing CRB from full 3N×3N inverse (Schur complement)\n")

    N, spacing = 4, 25.0
    pos = np.column_stack([np.arange(N) * spacing, np.zeros(N)])

    ENVS = [
        ("Open road",    500e6,  20.0),
        ("Urban NLOS",   500e6, -20.0),
        ("Severe NLOS",  100e6, -25.0),
    ]

    headers = [
        "Environment", "Timing-only CRB", "Joint+GPS CRB", "Ratio (GPS)",
        "Joint (no GPS)", "Ratio (free)",
    ]
    rows = []
    for env, bw, snr in ENVS:
        cfg = SimConfig(n_agents=N, uwb_bandwidth_hz=bw, uwb_snr_db=snr,
                        rstd_enabled=True, gnss_enabled=False)

        _, sig_t   = crb_from_fim(build_fim(cfg, pos))
        sig_j_gps  = _joint_timing_crb(build_joint_fim(cfg, pos, gps_pos_std_m=1.0), N)
        sig_j_free = _joint_timing_crb(build_joint_fim(cfg, pos), N)

        ratio_gps  = sig_j_gps  / sig_t if np.isfinite(sig_j_gps)  else float("inf")
        ratio_free = sig_j_free / sig_t if np.isfinite(sig_j_free) else float("inf")

        rows.append([
            env,
            _fmt_time(sig_t),
            _fmt_time(sig_j_gps),
            f"{ratio_gps:.3f}",
            "∞" if not np.isfinite(sig_j_free) else _fmt_time(sig_j_free),
            "∞" if not np.isfinite(ratio_free) else f"{ratio_free:.3f}",
        ])

    _print_table(rows, headers)
    print("\n  Ratio > 1.0 → position uncertainty inflates timing CRB.")
    print("  GPS aiding (1 m) nearly recovers the timing-only bound.")
    print("  Without GPS, UWB ranges must also resolve geometry, so UWB adds\n"
          "  little timing information: the bound falls back towards the anchor-only value.")

    # ── Plot: timing CRB vs GPS position accuracy (sensitivity) ──
    images = []
    if HAS_MPL:
        gps_stds = np.logspace(-1, 2, 120)    # 0.1 m … 100 m
        env_colors = ["steelblue", "darkorange", "firebrick"]

        fig, ax = plt.subplots(figsize=(8, 4))
        for (env, bw, snr), color in zip(ENVS, env_colors):
            cfg   = SimConfig(n_agents=N, uwb_bandwidth_hz=bw, uwb_snr_db=snr,
                              rstd_enabled=True, gnss_enabled=False)
            _, s0 = crb_from_fim(build_fim(cfg, pos))
            crbs  = []
            for gs in gps_stds:
                s = _joint_timing_crb(build_joint_fim(cfg, pos, gps_pos_std_m=gs), N)
                crbs.append(s * 1e9 if np.isfinite(s) else np.nan)

            ax.plot(gps_stds, crbs, color=color, lw=2, label=env)
            ax.axhline(s0 * 1e9, color=color, ls=":", lw=1.2, alpha=0.6)

        ax.set_xscale("log")
        ax.set_xlabel("GPS position accuracy σ (m)")
        ax.set_ylabel("Timing CRB σ (ns)")
        ax.set_title("Joint Pose-Timing CRB vs. GPS Position Accuracy\n"
                     "Dotted = timing-only bound (positions perfectly known)")
        ax.legend()
        ax.grid(True, which="both", alpha=0.3)
        fig.tight_layout()
        images.append(_save_fig(fig, "joint_fim_gps_sensitivity.png"))

        # ── Plot: Position + timing uncertainty ellipses per agent ──
        from matplotlib.patches import Ellipse, Circle, Patch
        from matplotlib.lines  import Line2D

        fig, axes = plt.subplots(1, 3, figsize=(14, 5))
        for ax, (env, bw, snr), ec in zip(axes, ENVS, env_colors):
            cfg_e = SimConfig(n_agents=N, uwb_bandwidth_hz=bw, uwb_snr_db=snr,
                              rstd_enabled=True, gnss_enabled=False)
            J3    = build_joint_fim(cfg_e, pos, gps_pos_std_m=1.0)
            sign, logdet = np.linalg.slogdet(J3)
            if sign != 1 or not np.isfinite(logdet):
                ax.set_title(f"{env}\n(rank-deficient)")
                continue
            J3_inv = np.linalg.inv(J3)

            for i, j in combinations(range(N), 2):
                if np.linalg.norm(pos[i] - pos[j]) <= cfg_e.uwb_max_range_m:
                    ax.plot([pos[i, 0], pos[j, 0]], [pos[i, 1], pos[j, 1]],
                            "k-", lw=1, alpha=0.2, zorder=1)

            for i in range(N):
                # Position uncertainty ellipse (3-sigma, from GPS+UWB position sub-block)
                pos_cov = J3_inv[np.ix_([3*i, 3*i+1], [3*i, 3*i+1])]
                eigvals, eigvecs = np.linalg.eigh(pos_cov)
                eigvals = np.maximum(eigvals, 0.0)
                angle   = np.degrees(np.arctan2(eigvecs[1, -1], eigvecs[0, -1]))
                w, h    = 2.0 * 3.0 * np.sqrt(eigvals[::-1])
                ell = Ellipse(pos[i], w, h, angle=angle,
                              facecolor="steelblue", alpha=0.25,
                              edgecolor="steelblue", lw=1.2, zorder=2)
                ax.add_patch(ell)

                # Timing uncertainty as circle radius σ_τ × c (3-sigma, in metres)
                tau_var = max(J3_inv[3*i+2, 3*i+2], 0.0)
                r_m     = np.sqrt(tau_var) * C_LIGHT * 3.0
                circ    = Circle(pos[i], r_m, fill=False,
                                 color="darkorange", ls="--", lw=1.5,
                                 alpha=0.8, zorder=2)
                ax.add_patch(circ)

                ax.plot(*pos[i], "ko", ms=5, zorder=5)
                ax.annotate(f"A{i}", pos[i], xytext=(0, 10),
                            textcoords="offset points", ha="center", fontsize=8)

            ax.set_title(f"{env}\n(BW={bw/1e6:.0f} MHz, SNR={snr:.0f} dB)",
                         fontsize=9)
            ax.set_xlabel("x (m)")
            ax.set_ylabel("y (m)")
            ax.set_aspect("equal")
            pad = 25
            ax.set_xlim(pos[:, 0].min() - pad, pos[:, 0].max() + pad)
            ax.set_ylim(-pad, pad)
            ax.grid(True, alpha=0.3)

        legend_els = [
            Patch(facecolor="steelblue", alpha=0.4,
                  label="Position uncertainty (3σ ellipse, GPS 1 m aiding)"),
            Line2D([0], [0], color="darkorange", ls="--", lw=1.5,
                   label="Timing uncertainty (3σ × c, in metres)"),
        ]
        axes[0].legend(handles=legend_els, fontsize=7, loc="upper left")
        fig.suptitle(f"Joint Position & Timing Uncertainty (3σ, GPS-Aided 1 m)\n"
                     f"N={N} agents, UWB + 5G-TA")
        fig.tight_layout()
        images.append(_save_fig(fig, "joint_uncertainty_ellipses.png"))

    return {
        "title": "5. Joint Pose-Timing FIM",
        "intro": (
            f"3N × 3N FIM, state [x_i, y_i, τ_i] per agent. N = {N}, {spacing:.0f} m spacing, "
            "UWB + 5G-TA. Timing CRB extracted via Schur complement of the position sub-block. "
            "Three cases: positions known (N×N), GPS-aided (1 m), positions free (position gauge handled by pseudo-inverse Schur complement)."
        ),
        "tables": [{"caption": None, "headers": headers, "rows": rows}],
        "notes": [
            "Ratio > 1.0: position uncertainty inflates timing CRB.",
            "GPS aiding at 1 m accuracy nearly recovers the timing-only bound.",
            "Without position aiding the timing CRB is finite but UWB timing gain is lost (bound → anchor-only value).",
            "Dotted lines in the plot show the asymptotic timing-only CRB (perfect positions).",
        ],
        "images": images,
    }


# ── Experiment 6: Hardware parameter validation ───────────────────────────

# Qorvo DWM3000 (IEEE 802.15.4z, channel 5): 499.2 MHz bandwidth.
# At typical indoor 5–10 m LOS ranges, effective SNR ≈ 10 dB → σ_uwb ≈ 101 ps.
DWM3000_BW_HZ  = 499.2e6
DWM3000_SNR_DB = 10.0

# Quectel RG501Q 5G module: 5G-TA accuracy 5–10 ns (3GPP TR 38.857).
RG501Q_RSTD_S  = 7.0 * NS


def run_hardware_validation_experiment() -> dict:
    """
    Validate the CRB model against manufacturer-specified hardware noise levels.

    Substitutes Qorvo DWM3000 / Quectel RG501Q parameters in place of real
    hardware logs and verifies:
      1. WLS achieves the CRB (efficiency ≈ 1) under hardware parameters.
      2. The per-trial error quadratic form Q_k = eₖᵀ J eₖ ~ χ²(N), confirmed
         via a KS test.  This is the correct test for correlated per-agent errors
         (pooling raw errors and running a univariate KS test violates i.i.d.).
    A histogram of per-agent errors vs. the CRB-predicted Gaussian is saved.

    Hardware specs
    --------------
    Qorvo DWM3000   : 499.2 MHz BW, SNR 10 dB  → σ_uwb ≈ 101 ps
    Quectel RG501Q  : 5G time anchor σ = 7 ns  (3GPP TR 38.857, conservative)
    """
    from scipy.stats import kstest, chi2 as sp_chi2

    sig_uwb_hw = uwb_noise_std(DWM3000_BW_HZ, DWM3000_SNR_DB)

    print("\n── Datasheet-Parameter Simulation (no hardware data) ──")
    print(f"  Qorvo DWM3000  : {DWM3000_BW_HZ/1e6:.1f} MHz BW, "
          f"{DWM3000_SNR_DB:.0f} dB SNR → σ_uwb = {sig_uwb_hw*1e12:.1f} ps")
    print(f"  Quectel RG501Q : σ_rstd = {RG501Q_RSTD_S*1e9:.0f} ns "
          f"(3GPP TR 38.857, conservative)")
    print(f"  N = 4 agents, 25 m spacing, 2 000 Monte Carlo trials\n")

    N, spacing, n_trials = 4, 25.0, 2000
    pos = np.column_stack([np.arange(N) * spacing, np.zeros(N)])

    configs = [
        ("UWB only (DWM3000)",
         SimConfig(n_agents=N, n_trials=n_trials,
                   uwb_enabled=True, uwb_bandwidth_hz=DWM3000_BW_HZ,
                   uwb_snr_db=DWM3000_SNR_DB,
                   rstd_enabled=False, gnss_enabled=False)),
        ("UWB + 5G-TA (DWM3000 + RG501Q)",
         SimConfig(n_agents=N, n_trials=n_trials,
                   uwb_enabled=True, uwb_bandwidth_hz=DWM3000_BW_HZ,
                   uwb_snr_db=DWM3000_SNR_DB,
                   rstd_enabled=True, rstd_std_s=RG501Q_RSTD_S,
                   gnss_enabled=False)),
        ("UWB + 5G-TA + GNSS",
         SimConfig(n_agents=N, n_trials=n_trials,
                   uwb_enabled=True, uwb_bandwidth_hz=DWM3000_BW_HZ,
                   uwb_snr_db=DWM3000_SNR_DB,
                   rstd_enabled=True, rstd_std_s=RG501Q_RSTD_S,
                   gnss_enabled=True)),
    ]

    result_headers = ["Configuration", "CRB σ", "RMSE σ", "RMSE/CRB", "≤5 ms?"]
    rows        = []
    hist_errors = None
    hist_J      = None
    hist_cov    = None
    ks_stat     = None
    ks_p        = None
    all_results = []  # (label, cov_crb, sigma_crb, trial_errors)

    for label, cfg in configs:
        rng            = np.random.default_rng(seed=42)
        J              = build_fim(cfg, pos)
        cov_crb, sigma_crb = crb_from_fim(J)

        trial_errors, rmses = [], []
        for _ in range(n_trials):
            tau_true   = rng.normal(0.0, cfg.clock_offset_std_s, N)
            H, z, W    = generate_measurements(tau_true, cfg, pos, rng)
            tau_est, _ = wls_estimate(H, z, W)
            err        = tau_est - tau_true
            trial_errors.append(err)
            rmses.append(float(np.mean(err ** 2)))

        sigma_emp = float(np.sqrt(np.mean(rmses)))
        trial_errors = np.array(trial_errors)
        all_results.append((label, cov_crb, sigma_crb, trial_errors))

        if "5G-TA" in label and "GNSS" not in label:
            hist_errors = trial_errors
            hist_J      = J
            hist_cov    = cov_crb

        rows.append([
            label,
            _fmt_time(sigma_crb) if np.isfinite(sigma_crb) else "∞ (rank-def.)",
            _fmt_time(sigma_emp),
            f"{sigma_emp / sigma_crb:.3f}" if np.isfinite(sigma_crb) else "—",
            ("✓" if sigma_emp < 5e-3 else "✗") if np.isfinite(sigma_crb) else "n/a",
        ])

    _print_table(rows, result_headers)

    images = []
    if hist_errors is not None and hist_J is not None:
        # Per-agent errors within a trial are correlated (off-diagonal J⁻¹ terms).
        # The quadratic form Q_k = eₖᵀ J eₖ ~ χ²(N) is independent across trials
        # and absorbs the full covariance structure — the correct test statistic.
        Q_vals       = np.array([e @ hist_J @ e for e in hist_errors])
        ks_stat, ks_p = kstest(Q_vals, "chi2", args=(N,))
        print(f"\n  χ²({N}) goodness-of-fit on Qₖ = eₖᵀ J eₖ:  "
              f"D = {ks_stat:.4f},  p = {ks_p:.4f}")
        if ks_p > 0.05:
            print("  → p > 0.05: WLS errors consistent with CRB-predicted χ²(N) ✓")
        else:
            print("  → p ≤ 0.05: distribution deviates — check for model mismatch")

        if HAS_MPL:
            from scipy.stats import norm as sp_norm

            # ── Plot 1: per-agent error histogram vs. CRB Gaussian ──
            sigma_pool  = float(np.sqrt(np.mean(np.diag(hist_cov))))
            flat_errors = hist_errors.ravel()
            fig, ax     = plt.subplots(figsize=(7, 4))

            ax.hist(flat_errors * 1e9, bins=80, density=True,
                    alpha=0.55, color="steelblue", label="WLS per-agent errors")

            x_ns = np.linspace(-4 * sigma_pool, 4 * sigma_pool, 400) * 1e9
            ax.plot(x_ns,
                    sp_norm.pdf(x_ns / 1e9, scale=sigma_pool) / 1e9,
                    "r-", lw=2,
                    label=f"CRB prediction  N(0, σ²),  σ = {sigma_pool*1e9:.2f} ns")

            ax.set_xlabel("Timing error (ns)")
            ax.set_ylabel("Probability density (ns⁻¹)")
            ax.set_title(
                f"WLS Errors vs. CRB-Predicted Gaussian\n"
                f"DWM3000 ({DWM3000_BW_HZ/1e6:.1f} MHz, {DWM3000_SNR_DB:.0f} dB) "
                f"+ RG501Q ({RG501Q_RSTD_S*1e9:.0f} ns 5G-TA),  "
                f"N={N} agents,  {n_trials} trials"
            )
            ax.legend()
            fig.tight_layout()
            images.append(_save_fig(fig, "hardware_validation.png"))

            # ── Plot 2: χ²(N) Q-statistic histogram + theoretical PDF ──
            fig, ax = plt.subplots(figsize=(7, 4))
            ax.hist(Q_vals, bins=60, density=True, alpha=0.6,
                    color="steelblue", label=f"Empirical Q_k = eₖᵀ J eₖ")
            q_range = np.linspace(0, np.percentile(Q_vals, 99.5), 300)
            ax.plot(q_range, sp_chi2.pdf(q_range, df=N),
                    "r-", lw=2, label=f"χ²({N}) PDF (theoretical)")
            ax.set_xlabel("Q statistic")
            ax.set_ylabel("Density")
            ax.set_title(f"χ²({N}) Goodness-of-Fit Test\n"
                         f"KS D = {ks_stat:.4f},  p = {ks_p:.4f}  "
                         + ("✓" if ks_p > 0.05 else "✗"))
            ax.legend()
            ax.grid(True, alpha=0.3)
            fig.tight_layout()
            images.append(_save_fig(fig, "hardware_chi2_fit.png"))

            # ── Plot 3: per-agent RMSE violin per configuration ──
            valid = [(lbl, errs) for lbl, cov, sc, errs in all_results
                     if np.isfinite(sc)]
            if valid:
                fig, ax = plt.subplots(figsize=(8, 4))
                rmse_per_agent = [np.sqrt(np.mean(errs ** 2, axis=0)) * 1e9
                                  for _, errs in valid]
                vp = ax.violinplot(rmse_per_agent,
                                   positions=range(len(valid)),
                                   showmedians=True, showextrema=True)
                for body in vp["bodies"]:
                    body.set_facecolor("steelblue")
                    body.set_alpha(0.6)
                ax.set_xticks(range(len(valid)))
                ax.set_xticklabels([lbl for lbl, _ in valid], fontsize=8)
                ax.set_ylabel("Per-agent RMSE (ns)")
                ax.set_title("Per-Agent RMSE Distribution by Configuration\n"
                             f"(DWM3000 + RG501Q, {n_trials} trials)")
                ax.grid(True, axis="y", alpha=0.3)
                fig.tight_layout()
                images.append(_save_fig(fig, "hardware_rmse_violin.png"))

    hw_headers = ["Device", "Parameter", "Value", "Source"]
    hw_rows = [
        ["Qorvo DWM3000",   "Bandwidth",  f"{DWM3000_BW_HZ/1e6:.1f} MHz", "IEEE 802.15.4z ch.5"],
        ["Qorvo DWM3000",   "SNR (LOS)",  f"{DWM3000_SNR_DB:.0f} dB",      "Typical 5–10 m"],
        ["Qorvo DWM3000",   "σ\\_uwb",    f"{sig_uwb_hw*1e12:.1f} ps",      "Derived from formula"],
        ["Quectel RG501Q",  "σ\\_rstd",   f"{RG501Q_RSTD_S*1e9:.0f} ns",   "3GPP TR 38.857"],
    ]

    notes = [
        (f"χ²({N}) KS test on Q\\_k = eₖᵀ J eₖ: D = {ks_stat:.4f}, p = {ks_p:.4f} — "
         + ("passes ✓" if ks_p and ks_p > 0.05 else "fails ✗"))
        if ks_stat is not None else "KS test not run.",
        "Quadratic form test used rather than per-agent KS — off-diagonal J⁻¹ "
        "terms make raw per-agent errors correlated within a trial.",
    ]

    return {
        "title": "6. Datasheet-Parameter Simulation (no hardware data)",
        "intro": (
            f"Qorvo DWM3000 / Quectel RG501Q parameters substituted for real hardware logs. "
            f"N = {N} agents, {spacing:.0f} m spacing, {n_trials} Monte Carlo trials."
        ),
        "tables": [
            {"caption": "Hardware specifications", "headers": hw_headers, "rows": hw_rows},
            {"caption": "WLS efficiency vs. CRB", "headers": result_headers, "rows": rows},
        ],
        "notes": notes,
        "images": images,
    }


# ── Report generation ──────────────────────────────────────────────────────

def write_report(sections: list, path: str) -> None:
    """Write a full Markdown report from collected experiment result dicts."""
    report_dir = os.path.dirname(path)

    lines = [
        "# CRISP-CAV Experiment 3 — CRB Timing Report",
        "",
        f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  ",
        "",
        "> **Scientific question:** What is the fundamental lower bound on joint timing "
        "uncertainty achievable by a mobile multi-agent V2X network with no shared reference "
        "clock, and which side-channel combinations achieve it?",
        "",
        "---",
        "",
        "## Contents",
        "",
    ]
    for s in sections:
        anchor = (s["title"].lower()
                  .replace(" ", "-").replace(".", "")
                  .replace("(", "").replace(")", ""))
        lines.append(f"- [{s['title']}](#{anchor})")
    lines += ["", "---", ""]

    for s in sections:
        lines += [f"## {s['title']}", ""]
        if s.get("intro"):
            lines += [s["intro"], ""]
        for tbl in s.get("tables", []):
            if tbl.get("caption"):
                lines += [f"**{tbl['caption']}**", ""]
            lines += [_md_table(tbl["headers"], tbl["rows"]), ""]
        for note in s.get("notes", []):
            lines.append(f"- {note}")
        if s.get("notes"):
            lines.append("")
        for img_path in s.get("images", []):
            if img_path and os.path.isfile(img_path):
                rel  = os.path.relpath(img_path, report_dir)
                name = os.path.splitext(os.path.basename(img_path))[0].replace("_", " ").title()
                lines += [f"![{name}]({rel})", ""]
        lines += ["---", ""]

    lines += ["*End of report.*", ""]

    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    print(f"\nReport saved → {path}")


# ── Entry point ────────────────────────────────────────────────────────────

if __name__ == "__main__":
    sections = [
        run_experiment(),
        run_multipath_experiment(),
        run_spoof_detection_experiment(),
        run_ekf_experiment(),
        run_joint_fim_experiment(),
        run_hardware_validation_experiment(),
    ]
    write_report(sections, os.path.join(PLOT_DIR, "report.md"))
