"""Sensitivity of clock CRB and Hausman spoof detection to the 5G time-anchor accuracy.

Also tests a common-mode attack in which the 5G anchor is itself disciplined by the
spoofed GNSS (anchor and GNSS share the same bias).
"""
import numpy as np
from scipy.stats import chi2
from crisp_cav_exp3_crb_timing import (
    SimConfig, NS, US, build_fim, crb_from_fim, run_condition, generate_measurements,
    wls_estimate, hausman_dof, calibrate_spoof_threshold, spoof_detection_statistic,
    HAUSMAN_EIG_RTOL,
)

N, SPACING = 4, 25.0
POS = np.column_stack([np.arange(N) * SPACING, np.zeros(N)])
SIGMAS = [5 * NS, 50 * NS, 100 * NS, 300 * NS, 1 * US]
BIASES = [100 * NS, 300 * NS, 1 * US, 3 * US]
FAR, N_CAL, N_EVAL = 0.003, 2000, 1000


def common_mode_stat(cfg, pos, rng, bias):
    tau = rng.normal(0.0, cfg.clock_offset_std_s, size=N)
    H, z, W = generate_measurements(tau, cfg, pos, rng)
    n_uwb = H.shape[0] - 2 * N
    z = z.copy()
    z[n_uwb:n_uwb + N] += bias  # anchor rows share the GNSS bias
    keep = slice(0, H.shape[0] - N)
    ta, ca = wls_estimate(H, z, W)
    tn, cn = wls_estimate(H[keep], z[keep], W[keep])
    d, cd = ta - tn, cn - ca
    cd = 0.5 * (cd + cd.T)
    w, V = np.linalg.eigh(cd)
    k = w > HAUSMAN_EIG_RTOL * w.max()
    p = V[:, k].T @ d
    return float(np.sum(p ** 2 / w[k]))


rows = []
for s in SIGMAS:
    cfg_nom = SimConfig(n_agents=N, rstd_std_s=s, gnss_enabled=True)
    cfg_ng = SimConfig(n_agents=N, rstd_std_s=s, gnss_enabled=False)
    crb_nog = run_condition(SimConfig(n_agents=N, rstd_std_s=s, gnss_enabled=False, n_trials=300))
    crb_all = run_condition(SimConfig(n_agents=N, rstd_std_s=s, gnss_enabled=True, n_trials=300))
    thr = calibrate_spoof_threshold(cfg_nom, cfg_ng, POS, target_far=FAR, n_cal=N_CAL)
    dof = hausman_dof(cfg_nom, POS)
    rng = np.random.default_rng(7)
    far = np.mean([spoof_detection_statistic(cfg_nom, cfg_ng, POS, rng) > thr for _ in range(N_EVAL)])
    drs = []
    for b in BIASES:
        cfg_b = SimConfig(n_agents=N, rstd_std_s=s, gnss_enabled=True, gnss_spoofed=True, gnss_spoof_bias_s=b)
        drs.append(np.mean([spoof_detection_statistic(cfg_b, cfg_ng, POS, rng) > thr for _ in range(N_EVAL)]))
    cm = np.mean([common_mode_stat(SimConfig(n_agents=N, rstd_std_s=s, gnss_enabled=True, gnss_spoofed=True,
                                             gnss_spoof_bias_s=1 * US), POS, rng, 1 * US) > thr
                  for _ in range(N_EVAL)])
    rows.append((s, crb_nog["crb_s"], crb_nog["eff"], crb_all["crb_s"], thr, chi2.ppf(1 - FAR, dof), far, drs, cm))

hdr = "| 5G anchor σ | clock CRB, no GNSS | RMSE/CRB | clock CRB, +GNSS | threshold (χ² ref) | FAR | DR 100 ns | DR 300 ns | DR 1 µs | DR 3 µs | DR 1 µs common-mode |"
out = ["# 5G time-anchor sensitivity (N=4, 25 m spacing, σ_GNSS=100 ns, target FAR 0.3%)", "", hdr,
       "|" + "---|" * 11]
for s, cn, eff, ca, thr, ref, far, drs, cm in rows:
    out.append(f"| {s/NS:.0f} ns | {cn/NS:.2f} ns | {eff:.2f} | {ca/NS:.2f} ns | {thr:.2f} ({ref:.2f}) | {far:.1%} | "
               + " | ".join(f"{d:.1%}" for d in drs) + f" | {cm:.1%} |")
txt = "\n".join(out)
print(txt)
open("out/anchor_sensitivity.md", "w").write(txt + "\n")
