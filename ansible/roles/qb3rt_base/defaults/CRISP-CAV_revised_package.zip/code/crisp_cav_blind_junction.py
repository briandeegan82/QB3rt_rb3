#!/usr/bin/env python3
"""
CRISP-CAV — Blind Junction Pedestrian Localisation CRB

Scientific question:
    At a blind intersection where one agent (A1) can see a pedestrian and
    shares that information via V2X, what is the fundamental lower bound on
    the pedestrian's position uncertainty as perceived by the second agent (A2)?

Scenario
--------
    A1 at (0, −15) heading north  — observes pedestrian with lidar/radar/camera
    A2 at (−15, 0) heading east   — blocked by corner building, no direct view
    Pedestrian at (1, 8)          — crossing the north road past the junction

State vector (8-D):
    θ = [x_A1, y_A1, ψ_A1, x_A2, y_A2, ψ_A2, x_p, y_p]

The pedestrian CRB at A2 is the (x_p, y_p) block of J⁻¹.
A second CRB variant (relative to A2's own frame) shows how A2's GNSS
accuracy also enters the bound when A2 needs to act on the location.

Outputs
-------
    blind_junction_geometry.png   — junction map + 3σ CRB ellipses
    blind_junction_sensor_bars.png — σ_x / σ_y / geom-σ by sensor combo
    blind_junction_sweeps.png     — CRB vs V2X quality and GNSS quality
    blind_junction_ped_heatmap.png — CRB as a function of pedestrian position
    blind_junction_report.md      — Markdown report

Requirements:
    pip install numpy tabulate matplotlib
"""

from __future__ import annotations

import os
from datetime import datetime
from dataclasses import dataclass

import numpy as np

try:
    from tabulate import tabulate
    HAS_TABULATE = True
except ImportError:
    HAS_TABULATE = False

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    HAS_MPL = True
except ImportError:
    HAS_MPL = False

# ── Constants ──────────────────────────────────────────────────────────────

PLOT_DIR = os.environ.get("CRISP_CAV_OUT", os.path.join(os.path.dirname(os.path.abspath(__file__)), "out"))
os.makedirs(PLOT_DIR, exist_ok=True)


# ── Sensor noise configuration ─────────────────────────────────────────────

@dataclass
class BlindJunctionConfig:
    """
    Sensor noise parameters for the two-agent blind-junction scenario.

    State: θ = [x_A1, y_A1, ψ_A1, x_A2, y_A2, ψ_A2, x_p, y_p]  (8-D)
    """
    # GNSS (isotropic 2-D, 1-σ)
    gnss_std_m:             float = 1.5

    # IMU-derived heading (gyro integration over one update interval)
    imu_heading_std_rad:    float = float(np.radians(0.5))   # 0.5° MEMS gyro

    # Lidar — A1 → pedestrian  (905 nm solid-state ToF)
    lidar_enabled:          bool  = True
    lidar_range_std_m:      float = 0.03                     # 3 cm RMS
    lidar_bearing_std_rad:  float = float(np.radians(0.1))  # 0.1° angular step

    # Radar — A1 → pedestrian  (77 GHz FMCW)
    radar_enabled:          bool  = True
    radar_range_std_m:      float = 0.20                     # 20 cm RMS
    radar_bearing_std_rad:  float = float(np.radians(3.0))  # 3° azimuth resolution

    # Camera — A1 → pedestrian  (monocular: bearing + crude depth)
    camera_enabled:         bool  = True
    camera_bearing_std_rad: float = float(np.radians(1.0))  # 1° centroid bearing
    camera_range_std_m:     float = 5.0                      # monocular depth estimate

    # V2X UWB ranging between A1 and A2
    v2x_enabled:            bool  = True
    v2x_uwb_range_std_m:    float = 0.10                     # 10 cm UWB TOF

    # Optional GNSS degradation at A2 (urban-canyon shadow)
    a2_gnss_std_m:          float = 1.5                      # overridden in sweeps


# ── FIM construction ───────────────────────────────────────────────────────

def build_blind_junction_fim(
    pos_A1:  np.ndarray,   # (2,) global [x, y]
    psi_A1:  float,        # heading, radians
    pos_A2:  np.ndarray,
    psi_A2:  float,
    pos_ped: np.ndarray,   # (2,)
    cfg:     BlindJunctionConfig,
) -> np.ndarray:
    """
    8 × 8 FIM for joint state [x_A1, y_A1, ψ_A1, x_A2, y_A2, ψ_A2, x_p, y_p].

    Sensor contributions
    --------------------
    GNSS      : diagonal constraints on (x_A1,y_A1) and (x_A2,y_A2)
    IMU       : diagonal constraint on ψ_A1 and ψ_A2
    Lidar     : A1 → ped range + bearing (couples A1 pose and ped position)
    Radar     : same model, larger noise
    Camera    : A1 → ped bearing (1°) + monocular depth (5 m)
    V2X UWB   : A1 ↔ A2 range (couples A1 and A2 positions)

    A2 has NO direct measurements to the pedestrian; its knowledge comes
    entirely from A1's sensors mediated through the shared global (GNSS)
    frame and the V2X range constraint.
    """
    J = np.zeros((8, 8))

    def _add(h: np.ndarray, sigma: float) -> None:
        J[:] += (1.0 / sigma ** 2) * np.outer(h, h)

    # ── GNSS ──────────────────────────────────────────────────────────
    for idx, std in [(0, cfg.gnss_std_m),       # x_A1
                     (1, cfg.gnss_std_m),        # y_A1
                     (3, cfg.a2_gnss_std_m),     # x_A2
                     (4, cfg.a2_gnss_std_m)]:    # y_A2
        e = np.zeros(8); e[idx] = 1.0; _add(e, std)

    # ── IMU heading ───────────────────────────────────────────────────
    for idx in (2, 5):   # ψ_A1, ψ_A2
        e = np.zeros(8); e[idx] = 1.0; _add(e, cfg.imu_heading_std_rad)

    # ── A1 sensor Jacobians to pedestrian ─────────────────────────────
    dp = pos_ped - pos_A1
    r  = float(np.linalg.norm(dp))
    if r < 1e-6:
        return J

    # Range  ∂‖ped−A1‖ / ∂θ
    h_r = np.zeros(8)
    h_r[0], h_r[1] = -dp[0]/r, -dp[1]/r   # −∂/∂pos_A1
    h_r[6], h_r[7] =  dp[0]/r,  dp[1]/r   # +∂/∂pos_p

    # Bearing  ∂[atan2(Δy,Δx) − ψ_A1] / ∂θ
    h_b = np.zeros(8)
    h_b[0] =  dp[1] / r**2   # ∂β/∂x_A1
    h_b[1] = -dp[0] / r**2   # ∂β/∂y_A1
    h_b[2] = -1.0             # ∂β/∂ψ_A1
    h_b[6] = -dp[1] / r**2   # ∂β/∂x_p
    h_b[7] =  dp[0] / r**2   # ∂β/∂y_p

    if cfg.lidar_enabled:
        _add(h_r, cfg.lidar_range_std_m)
        _add(h_b, cfg.lidar_bearing_std_rad)
    if cfg.radar_enabled:
        _add(h_r, cfg.radar_range_std_m)
        _add(h_b, cfg.radar_bearing_std_rad)
    if cfg.camera_enabled:
        _add(h_b, cfg.camera_bearing_std_rad)
        _add(h_r, cfg.camera_range_std_m)

    # ── V2X UWB range between A1 and A2 ──────────────────────────────
    if cfg.v2x_enabled:
        dv = pos_A2 - pos_A1
        rv = float(np.linalg.norm(dv))
        if rv > 1e-6:
            h_v = np.zeros(8)
            h_v[0], h_v[1] = -dv[0]/rv, -dv[1]/rv
            h_v[3], h_v[4] =  dv[0]/rv,  dv[1]/rv
            _add(h_v, cfg.v2x_uwb_range_std_m)

    return J


# ── CRB helpers ────────────────────────────────────────────────────────────

def _ped_crb(J: np.ndarray) -> tuple[np.ndarray, float]:
    """
    Marginal CRB for the pedestrian (x_p, y_p) in the global frame.
    Returns (2×2 covariance, geometric-mean σ in metres).
    Geometric-mean σ = (det Σ_p)^{1/4} = sqrt(σ_major · σ_minor).
    """
    sign, logdet = np.linalg.slogdet(J)
    if sign != 1 or not np.isfinite(logdet):
        return np.full((2, 2), np.inf), float("inf")
    J_inv   = np.linalg.inv(J)
    ped_cov = J_inv[np.ix_([6, 7], [6, 7])]
    evs     = np.linalg.eigvalsh(ped_cov)
    if np.any(evs < 0) or not np.all(np.isfinite(evs)):
        return np.full((2, 2), np.inf), float("inf")
    return ped_cov, float(np.power(evs[0] * evs[1], 0.25))


# T projects the 8-D global state onto [x_p − x_A2, y_p − y_A2]
_T_REL_A2 = np.array([[0, 0, 0, -1, 0, 0, 1, 0],
                       [0, 0, 0,  0,-1, 0, 0, 1]], dtype=float)


def _ped_crb_wrt_a2(J: np.ndarray) -> tuple[np.ndarray, float]:
    """
    CRB for the pedestrian position expressed relative to A2.

    When A2 acts on the shared pedestrian location (collision avoidance,
    path planning) it needs the position in its own frame:
        δ = [x_p − x_A2, y_p − y_A2]

    This couples A2's self-localisation error into the bound:
        Σ_δ = T J⁻¹ Tᵀ,   T = [[0,0,0,−1,0,0,1,0],
                                   [0,0,0, 0,−1,0,0,1]]

    Degraded A2 GNSS raises the J⁻¹ diagonal for (x_A2, y_A2) and
    therefore inflates Σ_δ even though the global-frame pedestrian
    CRB (_ped_crb) is unchanged.
    """
    sign, logdet = np.linalg.slogdet(J)
    if sign != 1 or not np.isfinite(logdet):
        return np.full((2, 2), np.inf), float("inf")
    cov_rel = _T_REL_A2 @ np.linalg.inv(J) @ _T_REL_A2.T
    evs     = np.linalg.eigvalsh(cov_rel)
    if np.any(evs < 0) or not np.all(np.isfinite(evs)):
        return np.full((2, 2), np.inf), float("inf")
    return cov_rel, float(np.power(evs[0] * evs[1], 0.25))


# ── Formatting helpers ─────────────────────────────────────────────────────

def _print_table(rows, headers):
    if HAS_TABULATE:
        print(tabulate(rows, headers=headers, tablefmt="github"))
    else:
        print("\t".join(headers))
        for r in rows:
            print("\t".join(str(x) for x in r))


def _md_table(headers: list, rows: list) -> str:
    def _cell(v):
        return str(v).replace("|", "\\|")
    header = "| " + " | ".join(_cell(h) for h in headers) + " |"
    sep    = "|" + "|".join(":---:" for _ in headers) + "|"
    body   = ["| " + " | ".join(_cell(c) for c in row) + " |" for row in rows]
    return "\n".join([header, sep] + body)


def _save_fig(fig, filename: str, dpi: int = 200) -> str:
    path = os.path.join(PLOT_DIR, filename)
    fig.savefig(path, dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    print(f"  Plot saved → {path}")
    return path


# ── Experiment ─────────────────────────────────────────────────────────────

def run_blind_junction_experiment() -> dict:
    """
    CRB analysis: what is the fundamental lower bound on pedestrian localisation
    accuracy from Agent 2's perspective when A1 shares its sensor data via V2X?

    Geometry
    --------
      A1 = (0, −15)  heading north  — sees the pedestrian
      A2 = (−15, 0)  heading east   — blocked by corner building
      Ped = (1, 8)   crossing the north road past the junction

    Plots
    -----
    1. Junction geometry + 3σ CRB ellipses per sensor combination
    2. Per-sensor-combo bar chart (σ_x, σ_y, geometric σ)
    3. Sensitivity sweeps: CRB vs V2X quality and GNSS quality
    4. Pedestrian CRB heatmap (geometric σ vs. ped position)
    """
    print("\n── Blind Junction: Pedestrian CRB via V2X Sensor Fusion ──")
    print("  A1=(0,−15) north · A2=(−15,0) east · Pedestrian=(1,8)")

    pos_A1  = np.array([ 0.0, -15.0])
    psi_A1  = np.pi / 2          # north
    pos_A2  = np.array([-15.0,  0.0])
    psi_A2  = 0.0                 # east
    pos_ped = np.array([ 1.0,   8.0])   # on the north road, clear of the building

    r_A1_ped = float(np.linalg.norm(pos_ped - pos_A1))
    r_A1_A2  = float(np.linalg.norm(pos_A2 - pos_A1))
    print(f"  A1→ped: {r_A1_ped:.1f} m   A1↔A2: {r_A1_A2:.1f} m\n")

    # ── Sensor combination sweep ───────────────────────────────────────
    COMBOS = [
        ("GNSS + IMU only\n(no ped. sensors, no V2X)",
         BlindJunctionConfig(lidar_enabled=False, radar_enabled=False,
                             camera_enabled=False, v2x_enabled=False)),
        ("+ UWB V2X\n(still no ped. sensors)",
         BlindJunctionConfig(lidar_enabled=False, radar_enabled=False,
                             camera_enabled=False, v2x_enabled=True)),
        ("+ Camera\n+ UWB V2X",
         BlindJunctionConfig(lidar_enabled=False, radar_enabled=False,
                             camera_enabled=True, v2x_enabled=True)),
        ("+ Radar\n+ UWB V2X",
         BlindJunctionConfig(lidar_enabled=False, radar_enabled=True,
                             camera_enabled=False, v2x_enabled=True)),
        ("+ Lidar\n+ UWB V2X",
         BlindJunctionConfig(lidar_enabled=True, radar_enabled=False,
                             camera_enabled=False, v2x_enabled=True)),
        ("All sensors\n+ UWB V2X",
         BlindJunctionConfig(lidar_enabled=True, radar_enabled=True,
                             camera_enabled=True, v2x_enabled=True)),
    ]

    results = []
    for label, cfg in COMBOS:
        J = build_blind_junction_fim(pos_A1, psi_A1, pos_A2, psi_A2, pos_ped, cfg)
        cov, sig = _ped_crb(J)
        results.append((label, cfg, cov, sig))
        tag = f"{sig:.3f} m" if np.isfinite(sig) else "∞ (ped. unobserved)"
        print(f"  {label.replace(chr(10),' '):<42}: geom-σ = {tag}")

    # ── Uncertainty budget table ───────────────────────────────────────
    tbl_headers = ["Sensor combination", "σ_x (m)", "σ_y (m)", "Geom. σ (m)"]
    tbl_rows = []
    for label, _, cov, sig in results:
        lbl = label.replace("\n", " ")
        if np.isfinite(sig):
            sx = float(np.sqrt(max(cov[0, 0], 0)))
            sy = float(np.sqrt(max(cov[1, 1], 0)))
            tbl_rows.append([lbl, f"{sx:.3f}", f"{sy:.3f}", f"{sig:.3f}"])
        else:
            tbl_rows.append([lbl, "∞", "∞", "∞"])

    _print_table(tbl_rows, tbl_headers)

    # ── Sensitivity sweeps ────────────────────────────────────────────
    print("\n  V2X quality sweep (all sensors, σ_uwb varied):")
    v2x_stds  = np.logspace(-2, 1, 60)
    cfg_base  = BlindJunctionConfig()
    sweep_sig = []
    for sv in v2x_stds:
        cfg_s = BlindJunctionConfig(v2x_uwb_range_std_m=float(sv))
        J_s   = build_blind_junction_fim(pos_A1, psi_A1, pos_A2, psi_A2, pos_ped, cfg_s)
        _, s  = _ped_crb(J_s)
        sweep_sig.append(s)

    gnss_stds  = np.logspace(-1, 1, 60)
    sweep_gnss = []
    for sg in gnss_stds:
        cfg_g = BlindJunctionConfig(gnss_std_m=float(sg), a2_gnss_std_m=float(sg))
        J_g   = build_blind_junction_fim(pos_A1, psi_A1, pos_A2, psi_A2, pos_ped, cfg_g)
        _, s  = _ped_crb(J_g)
        sweep_gnss.append(s)

    images = []
    if HAS_MPL:
        from matplotlib.patches import Ellipse, Polygon

        # ── Plot 1: Junction geometry + CRB ellipses ──────────────────
        fig, ax = plt.subplots(figsize=(10, 10), dpi=300)

        ax.fill_between([-24, 24], [-3, -3], [3,  3],
                        color="lightgoldenrodyellow", zorder=0, alpha=0.9)
        ax.fill_betweenx([-24, 24], [-3, -3], [3, 3],
                         color="lightgoldenrodyellow", zorder=0, alpha=0.9)
        ax.axhline(0, color="white", lw=1.2, ls="--", alpha=0.7, zorder=1)
        ax.axvline(0, color="white", lw=1.2, ls="--", alpha=0.7, zorder=1)

        bldg = Polygon([[-3, 3], [-3, 20], [-20, 20], [-20, 3]],
                       closed=True, facecolor="slategray", edgecolor="black",
                       lw=1.5, zorder=2, alpha=0.6)
        ax.add_patch(bldg)
        ax.text(-11.5, 11.5, "Building\n(blind corner)", ha="center", va="center",
                fontsize=8, color="white", zorder=3)

        ax.plot([pos_A1[0], pos_A2[0]], [pos_A1[1], pos_A2[1]],
                color="mediumpurple", lw=1.5, ls="--", alpha=0.6, zorder=3,
                label="UWB V2X link")

        ax.annotate("", xy=pos_ped, xytext=pos_A1,
                    arrowprops=dict(arrowstyle="-|>", color="steelblue",
                                   lw=1.2, ls="dotted", alpha=0.7),
                    zorder=4)

        arrow_len = 4.0
        for pos, psi, color, name, lbl_xy in [
            (pos_A1, psi_A1, "steelblue",  "A1 (sees ped.)", ( 6,  8)),
            (pos_A2, psi_A2, "darkorange", "A2 (blind)",     ( 6, -16)),
        ]:
            ax.plot(*pos, "s", ms=14, color=color, zorder=5)
            dx = arrow_len * np.cos(psi)
            dy = arrow_len * np.sin(psi)
            ax.annotate("", xy=(pos[0]+dx, pos[1]+dy), xytext=pos,
                        arrowprops=dict(arrowstyle="-|>", color=color, lw=2),
                        zorder=5)
            ax.annotate(name, pos, xytext=lbl_xy, textcoords="offset points",
                        fontsize=9, color=color, fontweight="bold")

        ax.plot(*pos_ped, "r*", ms=18, zorder=6)
        ax.annotate("Pedestrian", pos_ped, xytext=(6, 6),
                    textcoords="offset points", fontsize=9,
                    color="darkred", fontweight="bold")

        # Global-frame ellipses (filled)
        for (label, cfg, cov, sig), ec, elabel in [
            (results[2], "mediumseagreen", "Camera + V2X"),
            (results[3], "gold",           "Radar + V2X"),
            (results[4], "tomato",         "Lidar + V2X"),
            (results[5], "black",          "All sensors + V2X"),
        ]:
            if not np.isfinite(sig):
                continue
            evs, evecs = np.linalg.eigh(cov)
            evs   = np.maximum(evs, 0)
            angle = np.degrees(np.arctan2(evecs[1, -1], evecs[0, -1]))
            w, h  = 2.0 * 3.0 * np.sqrt(evs[::-1])
            ax.add_patch(Ellipse(pos_ped, w, h, angle=angle,
                                 facecolor=ec, alpha=0.18, edgecolor=ec,
                                 lw=1.8, zorder=4,
                                 label=f"{elabel} — global (3σ, σ={sig:.2f} m)"))

        # Relative-to-A2 ellipses (dashed) — includes A2 GNSS error
        for a2_std, ec, ls, rel_label in [
            (cfg_base.a2_gnss_std_m, "royalblue", "--",
             f"All sensors + V2X — rel. A2 (σ_A2={cfg_base.a2_gnss_std_m} m)"),
            (5.0, "crimson", ":",
             "All sensors + V2X — rel. A2, degraded (σ_A2=5 m)"),
        ]:
            cfg_r = BlindJunctionConfig(a2_gnss_std_m=float(a2_std))
            J_r   = build_blind_junction_fim(pos_A1, psi_A1, pos_A2, psi_A2,
                                             pos_ped, cfg_r)
            cov_r, sig_r = _ped_crb_wrt_a2(J_r)
            if not np.isfinite(sig_r):
                continue
            evs, evecs = np.linalg.eigh(cov_r)
            evs   = np.maximum(evs, 0)
            angle = np.degrees(np.arctan2(evecs[1, -1], evecs[0, -1]))
            w, h  = 2.0 * 3.0 * np.sqrt(evs[::-1])
            ax.add_patch(Ellipse(pos_ped, w, h, angle=angle,
                                 facecolor="none", edgecolor=ec, lw=2.2,
                                 ls=ls, zorder=5,
                                 label=f"{rel_label} (3σ, σ={sig_r:.2f} m)"))

        ax.set_xlim(-24, 15)
        ax.set_ylim(-24, 20)
        ax.set_aspect("equal")
        ax.set_xlabel("x (m)")
        ax.set_ylabel("y (m)")
        ax.set_title("Blind Junction: Pedestrian CRB Ellipses at Agent 2\n"
                     "Filled = global frame  ·  Dashed = relative to A2 (includes A2 GNSS error)")
        ax.legend(fontsize=7.5, loc="lower right")
        ax.grid(True, alpha=0.2)
        fig.tight_layout()
        images.append(_save_fig(fig, "blind_junction_geometry.png", dpi=300))

        # ── Plot 2: Sensor combo bar chart ─────────────────────────────
        finite = [(lbl, cov, sig) for lbl, _, cov, sig in results if np.isfinite(sig)]
        fig, ax = plt.subplots(figsize=(10, 5))
        x = np.arange(len(finite))
        w = 0.28
        ax.bar(x - w, [float(np.sqrt(max(c[0,0],0))) for _,c,_ in finite],
               w, label="σ_x", color="steelblue", alpha=0.85)
        ax.bar(x,     [float(np.sqrt(max(c[1,1],0))) for _,c,_ in finite],
               w, label="σ_y", color="darkorange", alpha=0.85)
        ax.bar(x + w, [s for _,_,s in finite],
               w, label="Geom. σ", color="firebrick", alpha=0.85)
        ax.set_xticks(x)
        ax.set_xticklabels([lbl for lbl,_,_ in finite], fontsize=8)
        ax.set_ylabel("Pedestrian position uncertainty (m)")
        ax.set_title("Pedestrian Localisation CRB at A2 by Sensor Combination\n"
                     f"(blind junction; GNSS ± 1.5 m, A1–ped range ≈ {r_A1_ped:.0f} m)")
        ax.legend(fontsize=9)
        ax.grid(True, axis="y", alpha=0.3)
        ax.set_yscale("log")
        fig.tight_layout()
        images.append(_save_fig(fig, "blind_junction_sensor_bars.png"))

        # ── Plot 3: Sensitivity sweeps ─────────────────────────────────
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4))

        ax1.semilogx(v2x_stds * 100, [s * 100 for s in sweep_sig],
                     color="mediumpurple", lw=2)
        ax1.axvline(cfg_base.v2x_uwb_range_std_m * 100, color="k", ls="--", lw=1,
                    label=f"Default UWB ({cfg_base.v2x_uwb_range_std_m*100:.0f} cm)")
        ax1.set_xlabel("V2X UWB range error σ (cm)")
        ax1.set_ylabel("Pedestrian geom. σ (cm)")
        ax1.set_title("Pedestrian CRB vs. V2X Ranging Quality\n(all sensors, GNSS 1.5 m)")
        ax1.legend(fontsize=8)
        ax1.grid(True, which="both", alpha=0.3)

        ax2.loglog(gnss_stds, sweep_gnss, color="steelblue", lw=2)
        ax2.loglog(gnss_stds, gnss_stds, "k--", lw=1, alpha=0.5, label="σ = GNSS std (ref.)")
        ax2.axvline(cfg_base.gnss_std_m, color="k", ls="--", lw=1,
                    label=f"Default GNSS ({cfg_base.gnss_std_m} m)")
        ax2.set_xlabel("GNSS accuracy σ (m)")
        ax2.set_ylabel("Pedestrian geom. σ (m)")
        ax2.set_title("Pedestrian CRB vs. GNSS Accuracy\n(all sensors, V2X 10 cm)")
        ax2.legend(fontsize=8)
        ax2.grid(True, which="both", alpha=0.3)

        fig.suptitle("Sensitivity: What Limits Pedestrian Localisation Accuracy?",
                     fontsize=11)
        fig.tight_layout()
        images.append(_save_fig(fig, "blind_junction_sweeps.png"))

        # ── Plot 4: Per-combo heatmaps — one figure each ───────────────
        from matplotlib.lines import Line2D

        hx = np.linspace(-18, 12, 55)
        hy = np.linspace(-12, 18, 55)
        HX, HY = np.meshgrid(hx, hy)

        # Compute CRB grid for every combo
        sig_maps = []
        for _, cfg_h in COMBOS:
            SIG_MAP = np.full_like(HX, np.nan)
            for ri in range(HX.shape[0]):
                for ci in range(HX.shape[1]):
                    pp  = np.array([HX[ri, ci], HY[ri, ci]])
                    J_h = build_blind_junction_fim(pos_A1, psi_A1, pos_A2,
                                                   psi_A2, pp, cfg_h)
                    _, s = _ped_crb(J_h)
                    SIG_MAP[ri, ci] = s if np.isfinite(s) else np.nan
            sig_maps.append(SIG_MAP)

        # Shared colour scale: 2nd–98th percentile across all observable combos
        all_finite = np.concatenate([m[np.isfinite(m)] for m in sig_maps])
        vmin = float(np.percentile(all_finite, 2))  if len(all_finite) else 0.5
        vmax = float(np.percentile(all_finite, 98)) if len(all_finite) else 5.0

        HMAP_FILES = [
            "blind_junction_heatmap_gnss_imu.png",
            "blind_junction_heatmap_v2x.png",
            "blind_junction_heatmap_camera.png",
            "blind_junction_heatmap_radar.png",
            "blind_junction_heatmap_lidar.png",
            "blind_junction_heatmap_all.png",
        ]

        for (label, _), SIG_MAP, (_, _, cov, sig), fname in zip(
                COMBOS, sig_maps, results, HMAP_FILES):

            fig, ax = plt.subplots(figsize=(9, 9))

            finite_vals = SIG_MAP[np.isfinite(SIG_MAP)]
            if len(finite_vals) == 0:
                ax.set_facecolor("#d4d4d4")
            else:
                ax.contourf(HX, HY, SIG_MAP, levels=25, cmap="viridis_r",
                            vmin=vmin, vmax=vmax, zorder=1)
                ax.contour(HX, HY, SIG_MAP, levels=10,
                           colors="white", alpha=0.18, linewidths=0.5, zorder=2)

            # Road overlay (semi-transparent so heatmap shows through)
            ax.fill_between([-24, 24], [-3, -3], [3,  3],
                            color="lightgoldenrodyellow", alpha=0.30, zorder=3)
            ax.fill_betweenx([-24, 24], [-3, -3], [3, 3],
                             color="lightgoldenrodyellow", alpha=0.30, zorder=3)
            ax.axhline(0, color="white", lw=1.0, ls="--", alpha=0.5, zorder=4)
            ax.axvline(0, color="white", lw=1.0, ls="--", alpha=0.5, zorder=4)

            # Building (opaque — heatmap inside the building is meaningless)
            ax.add_patch(Polygon([[-3, 3], [-3, 20], [-20, 20], [-20, 3]],
                                 closed=True, facecolor="slategray",
                                 edgecolor="black", lw=1.5, alpha=0.75, zorder=5))
            ax.text(-11.5, 11.5, "Building\n(blind corner)",
                    ha="center", va="center", fontsize=8,
                    color="white", zorder=6)

            # "Unobservable" banner for rank-deficient combos
            if len(finite_vals) == 0:
                ax.text((hx[0]+hx[-1])/2, -3,
                        "Pedestrian unobservable\n(J rank-deficient for ped. position)",
                        ha="center", va="center", fontsize=11,
                        color="#333333", style="italic", zorder=6)

            # 3σ CRB ellipse at canonical pedestrian position
            if np.isfinite(sig):
                evs, evecs = np.linalg.eigh(cov)
                evs = np.maximum(evs, 0)
                angle = np.degrees(np.arctan2(evecs[1, -1], evecs[0, -1]))
                ew, eh = 2.0 * 3.0 * np.sqrt(evs[::-1])
                ax.add_patch(Ellipse(pos_ped, ew, eh, angle=angle,
                                     facecolor="white", alpha=0.25,
                                     edgecolor="white", lw=2.2, zorder=7))

            # V2X UWB link
            ax.plot([pos_A1[0], pos_A2[0]], [pos_A1[1], pos_A2[1]],
                    color="mediumpurple", lw=1.5, ls="--", alpha=0.6, zorder=7)

            # Agent arrows
            arrow_len = 4.0
            for pos, psi, color, name, lbl_xy in [
                (pos_A1, psi_A1, "steelblue",  "A1 (sees ped.)", ( 6,  8)),
                (pos_A2, psi_A2, "darkorange", "A2 (blind)",     ( 6, -16)),
            ]:
                ax.plot(*pos, "s", ms=14, color=color, zorder=8)
                dx = arrow_len * np.cos(psi)
                dy = arrow_len * np.sin(psi)
                ax.annotate("", xy=(pos[0]+dx, pos[1]+dy), xytext=pos,
                            arrowprops=dict(arrowstyle="-|>", color=color, lw=2),
                            zorder=8)
                ax.annotate(name, pos, xytext=lbl_xy,
                            textcoords="offset points",
                            fontsize=9, color=color, fontweight="bold", zorder=8)

            # Pedestrian marker
            ax.plot(*pos_ped, "r*", ms=16, zorder=9)
            ax.annotate("Pedestrian", pos_ped, xytext=(6, 6),
                        textcoords="offset points", fontsize=8,
                        color="darkred", fontweight="bold", zorder=9)

            ax.set_xlim(hx[0], hx[-1])
            ax.set_ylim(hy[0], hy[-1])
            ax.set_aspect("equal")
            ax.set_xlabel("Pedestrian x (m)")
            ax.set_ylabel("Pedestrian y (m)")
            sig_str = f"σ = {sig:.2f} m" if np.isfinite(sig) else "unobservable"
            ax.set_title(
                f"Pedestrian CRB — {label.replace(chr(10), ' ')}\n"
                f"Canonical position: {sig_str}  ·  shared colour scale "
                f"{vmin:.2f}–{vmax:.2f} m",
                fontsize=9)
            ax.grid(True, alpha=0.12, zorder=0)

            # Legend
            legend_handles = [
                Line2D([0], [0], marker="s", color="steelblue", ms=10,
                       ls="", label="A1 (sees ped.)"),
                Line2D([0], [0], marker="s", color="darkorange", ms=10,
                       ls="", label="A2 (blind)"),
                Line2D([0], [0], marker="*", color="r", ms=12,
                       ls="", label="Canonical ped."),
                Line2D([0], [0], color="white", lw=2.2,
                       label=f"3σ CRB ellipse ({sig_str})"),
                Line2D([0], [0], color="mediumpurple", lw=1.5,
                       ls="--", label="V2X UWB link"),
            ]
            ax.legend(handles=legend_handles, fontsize=8, loc="lower right")

            if len(finite_vals) > 0:
                sm = plt.cm.ScalarMappable(
                    cmap="viridis_r",
                    norm=plt.Normalize(vmin=vmin, vmax=vmax))
                sm.set_array([])
                fig.colorbar(sm, ax=ax,
                             label="Pedestrian geom. CRB σ (m)", shrink=0.82)

            fig.tight_layout()
            images.append(_save_fig(fig, fname))

    cfg_default = BlindJunctionConfig()

    # Derived quantities that appear in the config table
    ped_bearing_from_A1_deg = float(np.degrees(
        np.arctan2(pos_ped[0] - pos_A1[0], pos_ped[1] - pos_A1[1])
    ))  # angle off heading (north = 0)
    ped_subtended_deg = float(np.degrees(0.5 / r_A1_ped))  # half-width 0.5 m pedestrian

    config_rows = [
        # ── geometry ──
        ["**Geometry**",    "",              ""],
        ["A1 position",     "(0, −15) m",    "South approach, 15 m from junction centre"],
        ["A1 heading",      "90° (north)",   "Approaching the junction"],
        ["A2 position",     "(−15, 0) m",    "West approach, 15 m from junction centre"],
        ["A2 heading",      "0° (east)",     "Approaching the junction"],
        ["Pedestrian",      "(1, 8) m",      "North road, 8 m past the stop line"],
        ["Agent velocity",  "0 m/s (both)",  "Static snapshot; no motion during measurement epoch"],
        ["Pedestrian velocity", "0 m/s",     "Static snapshot; no motion compensation applied"],
        ["A1 → ped range",  f"{r_A1_ped:.1f} m",  "Euclidean, free-space"],
        ["A1 ↔ A2 range",   f"{r_A1_A2:.1f} m",   "V2X UWB link distance"],
        ["Ped. off-boresight A1", f"{ped_bearing_from_A1_deg:.1f}°",
         "Angle off A1 heading; well within all sensor FoVs"],
        ["Building corner", "x ∈ [−20,−3], y ∈ [3,20]", "NW quadrant; blocks A2's line-of-sight to ped."],
        # ── sensors ──
        ["**Sensor noise (1-σ)**", "", ""],
        ["GNSS — A1",            f"{cfg_default.gnss_std_m:.1f} m (isotropic)",      "L1 C/A; open-sky urban"],
        ["GNSS — A2 (nominal)",  f"{cfg_default.a2_gnss_std_m:.1f} m (isotropic)",   "Same as A1 in baseline"],
        ["GNSS — A2 (degraded)", "5.0 m (isotropic)",                                "Urban-canyon shadow, shown in geometry plot"],
        ["IMU heading (ψ)",      f"{np.degrees(cfg_default.imu_heading_std_rad):.1f}°", "MEMS gyro, 1 s integration"],
        # lidar
        ["**Lidar**",            "",  ""],
        ["Lidar range σ",        f"{cfg_default.lidar_range_std_m*100:.0f} cm",  "905 nm solid-state ToF"],
        ["Lidar bearing σ",      f"{np.degrees(cfg_default.lidar_bearing_std_rad):.1f}°",
         "Beam angular step (one range-bearing pair modelled; cluster fit would give σ/√N)"],
        ["Lidar returns on ped.",
         f"~{max(1, int(2*ped_subtended_deg / np.degrees(cfg_default.lidar_bearing_std_rad)))} beams",
         f"Pedestrian subtends ≈ {2*ped_subtended_deg:.1f}° at {r_A1_ped:.0f} m; "
         "model conservatively uses a single beam"],
        ["Lidar FoV (assumed)",  "360° (spinning) or ≥ ±60° (solid-state)",
         "Pedestrian bearing within FoV; no FoV cutoff enforced in model"],
        # radar
        ["**Radar**",            "", ""],
        ["Radar range σ",        f"{cfg_default.radar_range_std_m*100:.0f} cm",  "77 GHz FMCW"],
        ["Radar bearing σ",      f"{np.degrees(cfg_default.radar_bearing_std_rad):.1f}°",
         "Azimuth beam width (3 dB); treated as single-target centroid accuracy"],
        ["Radar FoV (assumed)",  "±60° azimuth, ±10° elevation",
         f"Ped. is {ped_bearing_from_A1_deg:.1f}° off boresight — within FoV; "
         "cutoff not enforced in model"],
        ["Pedestrian RCS",       "≥ −10 dBsm assumed detectable",
         "Swerling fading, aspect-angle variation, and clothing absorption not modelled"],
        # camera
        ["**Camera**",           "", ""],
        ["Camera bearing σ",     f"{np.degrees(cfg_default.camera_bearing_std_rad):.1f}°",
         "Conservative urban figure; accounts for calibration error and motion blur "
         "(raw pixel res. at 90° HFoV / 1280 px ≈ 0.07°/px)"],
        ["Camera FoV (assumed)", "≥ ±45° horizontal",
         f"Ped. is {ped_bearing_from_A1_deg:.1f}° off boresight — within FoV; "
         "cutoff not enforced in model"],
        ["Camera range (depth)", f"{cfg_default.camera_range_std_m:.0f} m",
         "Monocular depth estimate; independent of bearing (no stereo baseline)"],
        ["Camera pixel model",   "Not modelled",
         "σ_bearing treated as a given; no explicit image resolution, focal length, or "
         "pedestrian pixel-width model"],
        # V2X
        ["**V2X UWB**",          "", ""],
        ["V2X UWB range σ",      f"{cfg_default.v2x_uwb_range_std_m*100:.0f} cm",
         "IEEE 802.15.4z UWB ToF (A1 ↔ A2); open-sky LOS"],
        ["V2X FoV",              "Omni-directional",  "UWB antennas assumed isotropic"],
        # ── state ──
        ["**State vector**", "", ""],
        ["Dimension",   "8-D",  "θ = [x_A1, y_A1, ψ_A1, x_A2, y_A2, ψ_A2, x_p, y_p]"],
        ["Ped. CRB",    "global frame",  "J⁻¹ block at indices (6,7); Schur complement"],
        ["Rel. CRB",    "A2 frame",      "T J⁻¹ Tᵀ, T = [[0,0,0,−1,0,0,1,0],[0,0,0,0,−1,0,0,1]]"],
    ]

    assumptions = [
        # ── motion ──
        "**Zero agent and pedestrian velocity.** The scenario is a static snapshot: "
        "all positions and headings are fixed during the measurement epoch. "
        "At 30 km/h a 100 ms epoch shifts an agent ~0.83 m — violating the static "
        "assumption and requiring motion-compensated Jacobians.",
        # ── noise model ──
        "**Gaussian white measurement noise.** All sensor errors are zero-mean, independent, "
        "and Gaussian. The FIM is the sum of independent outer-product contributions "
        "J = Σ (1/σ²) hᵀh. Non-Gaussian tails (e.g. lidar retro-reflector spikes, "
        "radar ghost targets) are not modelled.",
        "**No systematic bias.** Sensors are fully calibrated; there are no constant offsets, "
        "scale-factor errors, lever-arm misalignments, or time-varying drift.",
        # ── information sharing ──
        "**Perfect information sharing.** A1's sensor Jacobians enter the joint 8-D FIM "
        "directly — equivalent to sharing raw measurements over a lossless, zero-latency "
        "V2X link. Quantisation, packet loss, and communication delay are not modelled.",
        # ── geometry / LOS ──
        "**Line-of-sight geometry.** A1 has unobstructed sight to the pedestrian. "
        "A2 is fully blocked (building corner). Partial occlusion and diffraction are "
        "not modelled.",
        "**Sensors within FoV.** All sensors on A1 are assumed to be pointing at the "
        "pedestrian (no FoV cutoff enforced). The pedestrian is "
        f"{ped_bearing_from_A1_deg:.1f}° off A1's heading, which is within the assumed "
        "FoV of all modelled sensors (lidar ≥ ±60°, radar ±60°, camera ±45°).",
        # ── target model ──
        "**Point target for all sensors.** The pedestrian is modelled as a single "
        "geometric point at (1, 8). No extended-target gain from fitting multiple "
        "lidar returns across the body is included. A cluster fit over N returns would "
        "reduce effective bearing noise to σ_b / √N; the single-return model is conservative.",
        "**Certain detection; no clutter.** Each sensor produces exactly one true "
        "detection per epoch. Probability of detection, false-alarm rate, and data-"
        "association ambiguity are not modelled.",
        # ── lidar ──
        "**Lidar: single range-bearing pair.** σ_bearing = 0.1° is the beam angular step. "
        f"At {r_A1_ped:.0f} m the pedestrian subtends ≈ {2*ped_subtended_deg:.1f}°, "
        f"so roughly "
        f"{max(1, int(2*ped_subtended_deg / np.degrees(cfg_default.lidar_bearing_std_rad)))} "
        "beams illuminate the body. The model uses one beam, making the lidar CRB "
        "contribution pessimistic by up to √N.",
        # ── radar ──
        "**Radar: 3° bearing is beam-width limited.** The 3° azimuth accuracy reflects "
        "the 3 dB beam width of a typical 77 GHz FMCW radar, treated as the centroid "
        "accuracy for a single detection. Pedestrian RCS is assumed ≥ −10 dBsm "
        "(detectable); Swerling fading and clothing/aspect-angle variation are not modelled.",
        # ── camera ──
        "**Camera: 1° bearing is a conservative urban figure.** Raw pixel resolution at "
        "90° HFoV / 1280 px ≈ 0.07°/px; the 1° figure absorbs calibration uncertainty, "
        "motion blur, and low-light degradation. No explicit pixel-count, focal-length, "
        "or pedestrian pixel-width model is used — σ_bearing is treated as a given input.",
        "**Camera monocular depth treated as independent.** The 5 m depth estimate enters "
        "the FIM as a separate range measurement uncorrelated with the bearing. "
        "No stereo baseline, structured light, or learned depth prior is assumed.",
        # ── GNSS / IMU ──
        "**Independent GNSS errors.** Position errors at A1 and A2 are uncorrelated. "
        "This is realistic when agents are separated by > 50 m or on separate GNSS epochs. "
        "Shared satellite geometry (common-mode bias) is not modelled.",
        "**Isotropic GNSS.** GNSS modelled as 2-D isotropic Gaussian (σ_x = σ_y = σ_gnss). "
        "In practice, DOP geometry introduces anisotropy (σ_x ≠ σ_y by up to 2×).",
        "**Heading decoupled from position.** The IMU provides a prior on ψ independently "
        "of the GNSS fix. Cross-terms between heading and position in the FIM are neglected.",
        # ── world model ──
        "**Planar (2-D) world.** All positions are in the horizontal plane. "
        "Elevation, road camber, and sensor mounting height are ignored.",
        # ── CRB tightness ──
        "**CRB is achievable.** The bounds are tight (MVUE exists) under the Gaussian "
        "noise model. In practice, non-linearity of the range/bearing observation model "
        "inflates RMSE above the CRB — especially when range is short or bearing "
        "uncertainty is large relative to target distance.",
    ]

    return {
        "title": "Blind Junction: Pedestrian CRB via V2X Sensor Fusion",
        "intro": (
            "Two agents at a blind intersection. A1 (south approach, heading north) "
            "observes the pedestrian with lidar / radar / camera; "
            "A2 (west approach, heading east) is blocked by the building corner. "
            "State θ = [x_A1, y_A1, ψ_A1, x_A2, y_A2, ψ_A2, x_p, y_p] (8-D). "
            "Pedestrian CRB at A2 is the (x_p, y_p) block of J⁻¹ "
            "(Schur complement after marginalising all agent-pose uncertainties)."
        ),
        "config_rows": config_rows,
        "assumptions": assumptions,
        "tables": [{"caption": "Pedestrian localisation CRB by sensor combination",
                    "headers": tbl_headers, "rows": tbl_rows}],
        "notes": [
            "Without pedestrian sensors (first two rows), J is rank-deficient for "
            "(x_p, y_p) → CRB = ∞ regardless of V2X quality.",
            "GNSS accuracy (σ ≈ 1.5 m) is the dominant bottleneck once lidar is active: "
            "lidar range/bearing noise (3 cm / 0.1°) is negligible at 24 m.",
            "V2X UWB quality has minimal impact on ped. CRB when both agents have good GNSS; "
            "it matters mainly when A2's GNSS is degraded (urban canyon).",
            f"A1–ped range ≈ {r_A1_ped:.1f} m;  A1–A2 range ≈ {r_A1_A2:.1f} m.",
        ],
        "images": images,
    }


# ── Report generation ──────────────────────────────────────────────────────

def write_report(section: dict, path: str) -> None:
    report_dir = os.path.dirname(path)
    s = section
    lines = [
        "# CRISP-CAV — Blind Junction Pedestrian Localisation CRB",
        "",
        f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  ",
        "",
        "> **Scientific question:** What is the fundamental lower bound on pedestrian "
        "localisation accuracy from a blind agent's perspective when a seeing agent "
        "shares its sensor data via V2X?",
        "",
        "---",
        "",
        f"## {s['title']}",
        "",
    ]

    if s.get("intro"):
        lines += [s["intro"], ""]

    # ── Experiment configuration ───────────────────────────────────────
    if s.get("config_rows"):
        lines += ["## Experiment Configuration", ""]
        lines += [_md_table(["Parameter", "Value", "Notes"], s["config_rows"]), ""]

    # ── Modelling assumptions ──────────────────────────────────────────
    if s.get("assumptions"):
        lines += ["## Modelling Assumptions", ""]
        for assumption in s["assumptions"]:
            lines.append(f"1. {assumption}")
        lines.append("")

    lines += ["---", "", "## Results", ""]

    for tbl in s.get("tables", []):
        if tbl.get("caption"):
            lines += [f"**{tbl['caption']}**", ""]
        lines += [_md_table(tbl["headers"], tbl["rows"]), ""]
    for note in s.get("notes", []):
        lines.append(f"- {note}")
    if s.get("notes"):
        lines.append("")
    for img_path in s.get("images", []):
        if img_path and os.path.isfile(img_path):
            rel  = os.path.relpath(img_path, report_dir)
            name = os.path.splitext(os.path.basename(img_path))[0].replace("_", " ").title()
            lines += [f"![{name}]({rel})", ""]
    lines += ["---", "", "*End of report.*", ""]

    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print(f"\nReport saved → {path}")


# ── Entry point ────────────────────────────────────────────────────────────

if __name__ == "__main__":
    section = run_blind_junction_experiment()
    write_report(section, os.path.join(PLOT_DIR, "blind_junction_report.md"))
