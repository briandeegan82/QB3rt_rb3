# Preliminary figure plan for the Research Programme (needs real data)

Reviewers' main score limiter: no FQ1 or FQ2 preliminary data, and no figures in the Research Programme. One half-page figure with two panels would address both. Put it in §2.2/§2.3, captioned honestly ("pilot data, N = ... frames").

## Panel A — FQ1 pilot: does quality explain detection beyond geometry? (highest value)
- Data: existing G-MIND recordings (infrastructure camera) with a few hundred labelled pedestrian/cyclist instances. Any existing labels Roshan has are fine.
- Quality manipulation on the same frames, so geometry stays fixed: Gaussian defocus at 3–4 levels, added shot/read noise (open-cam or a simple EMVA noise model on linearised data), JPEG/H.264 compression at 3 levels.
- For each level: information capacity (or MTF50/SNR) from the natural-scene edges in the view, then detection recall from an off-the-shelf detector (YOLO/RT-DETR), binned by target range.
- Plot: recall against information capacity, one curve per range bin. If the curves separate by range and fall with capacity, that shows quality explains variance beyond geometry, which is the FQ1 hypothesis in miniature.
- Effort: about 2–3 days given labelled frames. Requires: G-MIND frames + labels (Roshan).

## Panel B — FQ2 pilot: capture time vs clock offset
- Data: an LED timing target (or a rolling-shutter test of a moving edge) on one RSU camera, with exposure/HDR settings logged.
- Plot: the spread of the effective capture instant across the image (ms) for 2–3 exposure/HDR modes, next to the simulated clock-offset bound (ns; already computed) and the GNSS-pose-induced error converted to time at 1.5 m/s pedestrian speed.
- Message: capture time and pose dominate by 4–5 orders of magnitude, which is why FQ2 centres on them.
- Effort: about 1 day of bench measurement. Alternatively, use the PI's existing Valeo/LED-flicker measurements if publishable.

## Fallback (no new data)
Use the existing simulation outputs (code/out/joint_uncertainty_ellipses.png, crisp_cav_anchor_sensitivity.py). Label them as simulation; they add less than real pilot data.
