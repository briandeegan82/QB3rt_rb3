import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Polygon, FancyBboxPatch, Circle, FancyArrowPatch
plt.rcParams.update({'font.size': 9, 'font.family': 'DejaVu Sans'})
C1, C2, C3, CG = '#1f77b4', '#d62728', '#2ca02c', '#555555'

# ---------- Figure 1: concept ----------
fig, ax = plt.subplots(figsize=(7.2, 4.6)); ax.set_xlim(0, 100); ax.set_ylim(0, 64); ax.axis('off')
ax.add_patch(Rectangle((0, 22), 100, 16, color='#d9d9d9'))
ax.add_patch(Rectangle((42, 0), 16, 64, color='#d9d9d9'))
for x in range(2, 100, 8):
    if not 40 < x < 58: ax.plot([x, x+4], [30, 30], color='white', lw=1.5)
for y in range(2, 64, 8):
    if not 20 < y < 38: ax.plot([50, 50], [y, y+4], color='white', lw=1.5)
ax.add_patch(Rectangle((6, 40), 33, 22, color='#8c6d4f')); ax.text(22.5, 51, 'Building\n(occludes view)', ha='center', va='center', color='white', fontsize=8)
# vehicle
ax.add_patch(FancyBboxPatch((12, 31), 10, 5, boxstyle='round,pad=0.3', color=C1)); ax.text(17, 33.5, 'CAV', ha='center', va='center', color='white', fontsize=8, weight='bold')
ax.add_patch(Polygon([[22, 33.5], [41, 40.5], [41, 26]], color=C1, alpha=0.15))
ax.plot([22, 39.5], [34.5, 40], color=C1, ls='--', lw=1)
# pedestrian
ax.add_patch(Circle((45, 46), 1.4, color=C2)); ax.text(47, 46, 'VRU (hidden\nfrom CAV)', fontsize=8, va='center', color=C2)
# RSU
ax.plot([62, 62], [40, 52], color='k', lw=2); ax.add_patch(Rectangle((60.5, 52), 3, 2.5, color='k'))
ax.text(64, 55, 'Roadside node (G-MIND)\ncamera + LiDAR + V2X', fontsize=8)
ax.add_patch(Polygon([[61, 53], [40, 52], [44, 39]], color=C3, alpha=0.18))
# V2X link
ax.add_patch(FancyArrowPatch((60, 51), (21, 37), connectionstyle='arc3,rad=0.35', arrowstyle='-|>', mutation_scale=12, color=CG, lw=1.3, ls=':'))
ax.text(50, 61.5, 'shared percept over V2X / 5G', fontsize=8, color=CG, ha='center', va='top')
# questions
qs = [(C1, 'FQ1 Value', 'Does this percept add information\nthe CAV lacks? Predicted from\nmeasured sensor quality + geometry'),
      (C2, 'FQ2 Alignment', 'Can it be placed in the CAV frame?\nPose, capture time (rolling shutter,\nHDR) and latency error bounds'),
      (C3, 'FQ3 Trust', 'Is it degraded or malicious?\nSmallest detectable fault at a\nfixed false-alarm rate')]
for k, (c, h, t) in enumerate(qs):
    x0 = 61 + 0 * k; y0 = 30 - 10.5 * k
    ax.add_patch(FancyBboxPatch((x0, y0 - 8.5), 38, 9.3, boxstyle='round,pad=0.4', fc='white', ec=c, lw=1.5))
    ax.text(x0 + 1, y0 - 0.3, h, color=c, weight='bold', fontsize=8.5, va='top')
    ax.text(x0 + 1, y0 - 2.6, t, fontsize=7.3, va='top')
ax.text(1, 18, 'Shared perception helps only\nwhen all three hold.', fontsize=8.5, style='italic', va='top')
fig.tight_layout(); fig.savefig('figures/fig1_concept.png', dpi=250); plt.close(fig)

# ---------- Figure 2: programme structure ----------
fig, ax = plt.subplots(figsize=(7.2, 3.6)); ax.set_xlim(0, 100); ax.set_ylim(0, 50); ax.axis('off')
def box(x, y, w, h, c, title, body, fc=None):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.5', fc=fc or 'white', ec=c, lw=1.5))
    ax.text(x + w/2, y + h - 1.2, title, ha='center', va='top', weight='bold', color=c, fontsize=8.5)
    ax.text(x + w/2, y + h - 4.6, body, ha='center', va='top', fontsize=7.2)
cols = [(C1, 'FQ1 / WP1 Value', 'Ullah + PhD 1; IQ: Deegan\nEMVA 1288 + in-situ SFR,\ncontrolled degradation,\nheld-out datasets\nOutput: value model V(q, g)'),
        (C2, 'FQ2 / WP2 Alignment', 'Deegan + PhD 3; George\nhybrid + misspecified CRB,\nper-row capture time,\nmeasured latency\nOutput: error budget'),
        (C3, 'FQ3 / WP3 Trust', 'Deegan + PhD 2; Manzoor\ninsider/GNSS threat model,\nconsistency detectors\nOutput: smallest\ndetectable fault')]
for k, (c, t, b) in enumerate(cols):
    box(2 + 33 * k, 29, 30, 19, c, t, b)
box(2, 13, 96, 10, CG, 'WP4 Experimental platform (George + RA 1 + PhD 4)',
    'Research vehicle, 4 RSU nodes + G-MIND, Cohda V2X, 5G, UWB, RTK GNSS/INS ground truth, cabled GNSS record-replay', fc='#f2f2f2')
box(2, 0.5, 96, 10, 'k', 'WP5 Predict, then measure, at a Galway junction (Deegan)',
    'WP1–3 rules predict where sharing helps; the field campaign tests them.\nWP6: open data, ETSI CPS, IEEE P2020', fc='#fff7e6')
for k in range(3):
    ax.annotate('', xy=(17 + 33 * k, 23.8), xytext=(17 + 33 * k, 28.3), arrowprops=dict(arrowstyle='<|-|>', color=CG))
ax.annotate('', xy=(35.3, 38), xytext=(31.7, 38), arrowprops=dict(arrowstyle='-|>', color=CG))
ax.annotate('', xy=(68.3, 38), xytext=(64.7, 38), arrowprops=dict(arrowstyle='-|>', color=CG))
ax.text(33.5, 40, 'q', ha='center', fontsize=7, color=CG); ax.text(66.5, 40, 'σ', ha='center', fontsize=7, color=CG)
fig.tight_layout(); fig.savefig('figures/fig3_programme.png', dpi=250); plt.close(fig)

# ---------- Figure 3: preliminary analysis ----------
fig, (a, b) = plt.subplots(1, 2, figsize=(7.4, 3.2))
r = np.linspace(5, 80, 200); deg = np.pi / 180
sig_t = 0.030 / np.sqrt(12)               # uncompensated rolling-shutter row time, 30 ms readout
pose_std = np.hypot(1.0, r * 0.3 * deg)   # standard GNSS/INS: 1 m, 0.3 deg heading
pose_rtk = np.hypot(0.02, r * 0.05 * deg) # RTK: 2 cm, 0.05 deg
a.semilogy(r, pose_std, color=C1, lw=2, label='pose, standard GNSS/INS')
a.semilogy(r, pose_rtk, color=C1, lw=2, ls='--', label='pose, RTK GNSS/INS')
a.axhline(15 * sig_t, color=C2, lw=2, label='capture time, vehicle 15 m/s')
a.axhline(1.5 * sig_t, color=C2, lw=2, ls='--', label='capture time, pedestrian 1.5 m/s')
a.axhline(15 * 50e-9, color=CG, lw=1.5, ls=':', label='clock offset 50 ns, 15 m/s')
a.axvspan(10, 60, color='k', alpha=0.05); a.text(35, 2.3, 'junction ranges', ha='center', fontsize=7)
a.set_xlabel('target range (m)'); a.set_ylabel('1σ position error (m)'); a.set_ylim(3e-7, 5)
a.set_title('(a) Alignment error budget (analytical)', fontsize=9); a.legend(fontsize=6.3, loc='lower right', bbox_to_anchor=(1, 0.12)); a.grid(alpha=.3, which='both')
s = np.array([5, 50, 100, 300, 1000])
b.semilogx(s, [99.9, 99.0, 90.4, 9.0, 0.8], 'o-', color=C3, label='300 ns GNSS bias')
b.semilogx(s, [100, 100, 100, 100, 12.6], 's-', color=C1, label='1 µs GNSS bias')
b.semilogx(s, [0.2, 0.1, 0.2, 0.1, 0.1], '^-', color=C2, label='1 µs, common-mode (anchor spoofed too)')
b.axhline(0.3, color=CG, ls=':', lw=1); b.text(6, 3, 'false-alarm rate 0.3%', fontsize=7, color=CG)
b.set_xlabel('5G time-anchor σ (ns)'); b.set_ylabel('detection rate (%)'); b.set_ylim(-3, 105)
b.set_title('(b) Spoof detection vs anchor (simulation)', fontsize=9); b.legend(fontsize=6.5, loc='center left'); b.grid(alpha=.3, which='both')
fig.tight_layout(); fig.savefig('figures/fig2_preliminary.png', dpi=250); plt.close(fig)
print('done')
