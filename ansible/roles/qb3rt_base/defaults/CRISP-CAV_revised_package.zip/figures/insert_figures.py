import docx
from docx.shared import Cm, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
d = docx.Document('Application_preS8_backup.docx')
P = d.paragraphs
def add_after(p, img, cap, width=16):
    pic = d.add_paragraph(); pic.alignment = WD_ALIGN_PARAGRAPH.CENTER
    pic.add_run().add_picture(img, width=Cm(width)); pic.paragraph_format.keep_with_next = True
    c = d.add_paragraph(); r = c.add_run(cap.split('.', 1)[0] + '.'); r.bold = True; r.font.size = Pt(9)
    r2 = c.add_run(cap.split('.', 1)[1]); r2.font.size = Pt(9); c.paragraph_format.space_after = Pt(8)
    p._p.addnext(pic._p); pic._p.addnext(c._p)
F = [
 (92, 'figures/fig3_programme.png', 'Figure 3. Programme structure. Each fundamental question is one work package with a named lead. WP1 passes per-target sensor quality q to WP2, and WP2 passes the alignment uncertainty σ to WP3. All three use the WP4 platform. WP5 tests their predictions at a Galway junction, and WP6 handles dissemination, open data and standards.', 15),
 (70, 'figures/fig2_preliminary.png', 'Figure 2. Preliminary analysis. (a) Analytical 1σ alignment-error terms, from the FQ2 error model, against target range. Assumptions: standard GNSS/INS at 1 m and 0.3° heading; RTK at 2 cm and 0.05°; uncompensated rolling-shutter readout of 30 ms (σ ≈ 8.7 ms); clock offset 50 ns. With standard GNSS, pose dominates. With RTK pose, capture time dominates for vehicle-speed targets, and clock offset is negligible throughout (H2). (b) Simulated GNSS-spoof detection (4 agents, false-alarm rate 0.3%) against 5G time-anchor accuracy. Detection collapses when the anchor shares the spoofed GNSS bias, which motivates FQ3. Both panels are model or simulation results, not measurements.', 16),
 (28, 'figures/fig1_concept.png', 'Figure 1. CRISP-CAV concept. A roadside node sees a vulnerable road user that is hidden from the vehicle. The shared percept helps only if it adds information the vehicle lacks (FQ1), can be placed in the vehicle frame in space and time (FQ2), and can be trusted (FQ3).', 15),
]
for i, img, cap, w in F: add_after(P[i], img, cap, w)
d.save('Application.docx'); print('saved')
