# CRISP-CAV FFP revision: change log (11 Oct 2026)

Brian's instructions for this revision:
- Apply as a standard Award, not Emerging Investigator.
- Remove SWIR.
- Fix the CRB code.
- Remove the PI salary.
- Co-applicants are full-time academics; Roshan George is a postdoc.

## Application.docx
- **Route:** the Emerging Investigator field is set to "No" (it previously said "TBC (probably)").
- **SWIR removed throughout:**
  - §2.2.3 "SWIR Non-Redundancy Hypothesis" section.
  - RO2, which is now "Empirical rate-distortion characterisation".
  - Task 3.2.2 "SWIR Information Geometry Study" and D1.2 (now the empirical R_CP draft).
  - The SWIR risk row and the SWIR camera equipment line.
  - SWIR wording in the WP1 title, the dataset, impact, commercialisation, ethics and data-management text.
- **Removed:** orphan FQ5 (transport architecture).
- **Road deaths:** 155 corrected to 184 (2023, RSA). The unsourced "20–47 lives saved" arithmetic and the EC SAFER figure were removed.
- **FQ3 science corrected:**
  - **5G timing:** "5G RSTD" is replaced by "5G network time anchor" (absolute network time). The text now explains that RSTD/TDOA is differential and cannot observe an agent's own clock offset.
  - **Spoofing:** the "negative Fisher information" wording is removed. Spoofing is now described as a bias (model misspecification) under an unchanged FIM.
  - **Spoof monitor:** described as a Hausman-type test on shared measurements, with the real detection curve: 99.9% at 300 ns, 16% at 100 ns, 0.2% false-alarm rate.
  - **Preliminary result:** RMSE/CRB = 0.99–1.05 is now quoted.
- **"First" claims:** about 8 removed or toned down. The ones left are benign, e.g. "first year".
- **Unsupported claims:**
  - "Valeo €30,000/yr cash" removed.
  - "TII letter of support secured" changed to "to be requested before submission".
  - The OBU changed from Autotalks CRATON2 ITS-G5 to Cohda MK6C, to match the RSU radios.
- **PI bio (§Applicants):** rewritten around the Valeo image-quality career, IEEE P2020, patents, and the 2023–26 V2X and infrastructure papers. Scholar figures are 1,563 citations / h-index 20, as Brian gave them. The "no other PI in Ireland holds all three" claim is removed.
- **Team table:**
  - Ihsan Ullah and Jawad Manzoor added as co-applicants (effort TBC, no salary).
  - Roshan George named as Postdoc 1.
  - RA 1 (years 3–4) and four PhDs added, matching the budget workbook.
- **Work-package leads:**
  - WP1: Ullah + PhD 1.
  - WP2: Deegan + PhD 3.
  - WP3: Manzoor + PhD 2.
  - WP4: George + RA 1 + PhD 4.
  - WP5: Deegan + George.
  - Staffing references in the training, facilities, EDI and data-management text were updated to match.
- **Budget summary table:** now matches `Budget_Proposal_Calculation_Tool_IUA-aligned.xlsm` exactly, with no PI salary.

  | Line | Amount |
  |---|---|
  | Postdoc 1 | €257,538 |
  | RA 1 | €99,998 |
  | PhD × 4 | €492,000 |
  | Equipment | €75,200 |
  | Consumables, services, open-access fees and travel | €63,200 |
  | **Direct costs** | **€987,936** |
  | Overhead (30%) | €272,261 |
  | **Total** | **€1,260,197** |

  The equipment table now lists the workbook items.
- The budget workbook itself is unchanged. It already had no PI salary, and its unused "Post doc 2" staff row is not linked to the totals.

## Code (`code/crisp_cav_exp3_crb_timing.py`)
- **RMSE pooling bug:** fixed. RMSE is now the square root of the mean squared error, not the mean of per-trial RMSEs. RMSE/CRB is 0.99–1.05 for N = 2, 4, 8 (previously about 0.8).
- **Spoof detector:** now a Hausman test on one shared measurement set, using the effective-rank pseudo-inverse. The threshold is χ²(1)-calibrated (9.03 vs the 8.81 quantile).
- **Joint pose/timing CRB:** now uses a Schur complement with a pseudo-inverse. The free-position case gives 5.00 ns where it previously gave ∞.
- **Paths and labels:** the hard-coded `/home/brian` path was replaced with `CRISP_CAV_OUT` or `./out`. "RSTD" was relabelled "5G-TA". All figures and `out/report.md` were regenerated from this version. The blind-junction result reproduces: 1.271 m with lidar + UWB.

## Paper (`code/crisp_cav_paper.tex`, 6-page PDF)
- Updated to the new numbers: abstract, contributions, Table I, the spoofing section, joint-FIM table and text, discussion and conclusion.
- "Hardware validation" was retitled "Datasheet-parameter simulation (no hardware data)".
- The "EKF" is renamed "KF" (the model is linear).

## Still needed from Brian / the team
1. Confirm that "Ishan" is Dr Ihsan Ullah, and get both co-applicants' % effort.
2. Name an Academic Collaborator in information or estimation theory, with a 2-page CV and letter.
3. The platform text still mentions items that are not in the workbook: a Spirent GSS7000 GNSS simulator, Cohda RSU/OBU radios and Jetson Orin nodes. They are either existing CAR equipment (say so in the infrastructure section) or need costing within €1M.
4. Separate uploads still to be written: Narrative CVs (×3, each with 3 senior-author articles, funding history and supervision), Impact Statement, data management plan, references, budget justification, and letters (Valeo, TII).
5. RASP project details for the bio.

## Reframe to Option A (Brian approved, 11 Oct 2026)
- New title: "When Does Shared Infrastructure Perception Help? Information Value, Alignment and Trust for Connected and Autonomous Vehicles". The CRISP-CAV acronym is kept.
- **FQ1 Information value:** can measurable sensor quality predict the detection benefit of a shared percept? This covers information capacity, SNR, MTF and weather. Predicting that benefit decides what to share and at what rate, including privacy-preserving options.
  - Lead: Ullah with PhD 1.
- **FQ2 Alignment:** bounds on the error of a fused percept from three sources of uncertainty:
  - pose;
  - capture time (exposure, rolling shutter, HDR);
  - network latency.
  - Lead: Deegan with PhD 3, plus George and Manzoor.
  - Preliminary results: the CRB work.
- **FQ3 Trust:** detectability limits for faulty or malicious contributions, using consistency tests and explainable AI.
  - Lead: Manzoor with PhD 2, plus Ullah.
  - Preliminary results: the Hausman test.
- **Rewritten:** the abstracts, keywords, synopsis, all of §2 (Scientific Case) and the research objectives RO1–RO5.
- **Also rewritten:** §3.1, WP1–WP3, WP4 fault injection, WP5, the standards text, and the WP, Gantt and milestone tables.
- Rate-distortion and Byzantine-theorem language was replaced throughout the impact, ethics and data-management text.
- Backup of the version before the reframe: `Application_preA_backup.docx`.

## Impact Statement (new upload, `Impact_Statement.docx`, about 1,000 words)
- **Sections:** scientific, societal, economic and industry, policy and standards (ETSI TS 103 324 CPS, IEEE P2020, TII guidance), training, a milestone/KPI table (M12–M48), and risks to impact.
- **Removed as unsourced:** the lives-saved arithmetic, V2X market sizes, the 13% disability figure, the 10–15% fuel saving, the Valeo cash claim and the patent-licensing route.
- **[TBC] markers:** Valeo/TII letter commitments and the ETSI submission route.

## Round-2 review fixes (fresh 7-persona review, scores 2.80–3.50)
- **Co-applicant limit (call §2.4, max one):** Dr Ihsan Ullah is the sole co-applicant. Dr Jawad Manzoor is now Academic Collaborator: he advises WP3 (threat model, detectors) and WP2 latency measurement, and co-supervises PhD 2 with the PI as primary supervisor. No funding is requested for him. Updated: team table, WP2/WP3 leads, WP table, PhD roles, PI bio, equipment line and Impact Statement.
- Draft `Collaborator_Letter_Manzoor_DRAFT.docx` added. It has placeholders for his title, % time and meeting frequency.
- **Tracked changes accepted.** The document contained hidden tracked insertions from an older draft:
  - "FQ4/FQ5 optimised communication protocol";
  - RO6/RO7;
  - an old WP1/WP2/WP3/WP5 transport/QUIC/MoQ block;
  - a "Lead: ?" section.

  All of these are now removed. The planning notes after the DMP are also removed. The pre-change copy is `Application_preR2_backup.docx`.
- **Word limits:** lay abstract cut to 98 words; legal-remit justification cut from 372 to 191 words. The remit FQ mapping is corrected, and the spectrum-planning, certified-robustness, Climate Action and accessibility overclaims are removed.
- **Other compliance fixes:**
  - Citation counts and h-indices removed from the Research Programme and PI bio, per DORA and the Narrative CV guidance.
  - S&G "Team Composition and Inclusive Recruitment" section removed (Appendix A).
  - "published preliminary results" changed to "preliminary results".
  - The M48 KPI is now "at least 10" papers.
- **Science changes:**
  - FQ1 is now posed conditionally on viewing geometry, with a testable hypothesis: quality metrics reduce the error in predicting per-target gain by at least 30% over a geometry-only model on held-out sites.
  - FQ2 now centres on pose and capture time, because the ns clock bound does not bind against the CP latency budget. Added SyncNet, FFNet and CoBEVFlow.
  - FQ3 adds the adversarial-CP literature (Tu 2021, ROBOSAC, Zhang USENIX Sec 2024, MADE) and a redundancy-paradox paragraph.
  - References [44]–[55] added; [19] strategy title corrected.
  - Risk row "FQ1 formal bounds" replaced with a generalisation risk.
- **Impact Statement:** now 11 pt with 2.5 cm margins, and the tables are 11 pt. Rendered with LibreOffice it is 3 pages.

## Budget costing and justification
- **Time commitments** (suggested; please confirm):
  - Lead Applicant: 30%
  - Co-Applicant (Ihsan Ullah): 20%
  - Academic Collaborator (Jawad Manzoor): about 5%, stated in his letter
- **Equipment** is now itemised at €111,000 (was €75,200). All prices are indicative, ex VAT, and still need quotations. Items now costed:
  - Cohda MK6C ×5
  - Quectel 5G ×2
  - Qorvo UWB ×12
  - RSU enclosures, power and PTP timing
  - Septentrio RTK GNSS/INS
  - GNSS record-and-replay unit, used cabled only (replaces the uncosted "GNSS signal simulator")
  - Basler cameras and image-quality kit
  - Logging storage

  The GPU workstation is cut from €20k to €12k and the laptops from €12k to €9k.
- **Services** are now €22,200, adding dataset annotation (€15,000) and RTK corrections (€2,000).
- **RA 1** is cut to Year 4 only (€50,617) to stay under the €1M cap.
- **New totals:** direct €991,355; overheads €257,447; total €1,248,801. These are updated in Budget.xlsm (backup in Budget_preR2_backup.xlsm) and in the Application tables.
- **New upload:** Budget_Justification.docx (3 pages when rendered).

## Science strengthening (Research Programme)
- FQ1/WP1: lab EMVA 1288 characterisation on RAW, then in-situ natural-scene SFR; metrics computed on RAW and on ISP output; roadside visibility/precipitation sensor and luminance meter for logging conditions.
- FQ1/WP1: quality separated from geometry by controlled manipulation on fixed scenes (defocus, ND, exposure caps, bit depth, ISP, compression, RAW-domain degradation), natural variation, and public datasets (DAIR-V2X, V2X-Real, TUMTraf-V2X) used as held-out sites; at least two receiver architectures.
- FQ1 hypothesis: at least 30% reduction in V-prediction error relative to a geometry-only model; at least 1,500 occluded-VRU instances across at least 4 weather/illumination bins; analysis plan pre-registered on OSF at M12.
- FQ3 threat model: insider with valid credentials, goals (deletion/false braking), adaptive, collusion as an extension, ramped and common-mode GNSS spoofing, physical-layer attacks out of scope, link to ETSI TS 103 759 misbehaviour reporting. Results are reported per compromised agent; one agent is about 17% of the testbed.
- FQ3 novelty argued against MADE/ROBOSAC/Zhang: they test whether given attacks are caught; CRISP-CAV contributes the detectability limit.
- 5G time anchor: new sensitivity analysis (code/crisp_cav_anchor_sensitivity.py, out/anchor_sensitivity.md; paper §anchor_sens) over σ = 5 ns–1 µs. The clock bound stays below 50 ns with GNSS, so it is still non-binding. Detection of a 300 ns bias falls from 99.9% to 90%/9% at 100/300 ns. A common-mode spoof (GNSS-disciplined anchor) is undetectable. Application §2.3.2/§2.4.2 text updated, plus a new risk row.
- Live injection restricted to a closed area with the path isolated from the planner. Dual-use disclosure now goes to vendors, the C-ITS CCMS, NCSC-IE and ENISA, with an ethics-committee dual-use review.
- References: [11] corrected to ETSI TR 103 460 (2020); added [56] TS 103 759, [57] V2X-Real, [58] TUMTraf-V2X.
- Budget: weather/visibility sensor and luminance meter (+€8,000) added to the image-quality line. Equipment €119,000, direct €999,355 (€645 under the cap), overhead €257,447 (unchanged), total €1,256,802. Workbook row 45 updated (backup Budget_preS5_backup.xlsm).
- Application backup: Application_preS5_backup.docx.

## FQ2 formalisation and Narrative CV
- §2.3.1: added a problem statement (receiver-frame error model with per-row capture time), the bound types (hybrid/Bayesian CRB and misspecified CRB) and hypothesis H2. §3.3.1 updated to match. Added refs [59] Van Trees & Bell 2007 and [60] Fortunati et al. 2017.
- New Narrative_CV_Deegan.docx in the RI template (3 pages), built from Brian's RI_narrative_v2.tex. No metrics and no funding amounts (those go in SESAME). Senior-author picks are Deegan 2024, Brophy 2025 and Li 2026.

## Budget: LiDAR removed (existing equipment)
- Ouster OS1-64 LiDAR (€20,000) removed. Brian confirmed it is being acquired separately, so it is now listed as existing CAR Group equipment in the Application §3 vehicle description and the budget justification.
- Equipment is now €99,000 and direct costs €979,355 (€20,645 under the €1M cap). Overheads are unchanged at €257,447, since equipment is excluded. Total project cost is €1,236,802.
- Workbook rows 39–46 shifted up one row; formulas unchanged. Backups: Budget_preS7_backup.xlsm, Application_preS7_backup.docx, Budget_Justification_preS7_backup.docx.

## Figures added to the Research Programme
- Fig. 1 (concept, §1.1): occluded VRU at a junction, annotated with FQ1–FQ3.
- Fig. 2 (preliminary, §2.3.2): (a) analytical alignment-error budget against range, with the assumptions stated in the caption; (b) simulated spoof detection against 5G anchor σ, including the common-mode case.
- Fig. 3 (programme, §2.5): FQ/WP structure with leads, WP4 platform and WP5 predict-then-measure.
- Source: figures/make_figures.py and figures/insert_figures.py. Research Programme is now about 17 pages (limit 15; user asked to ignore the limit for now). Backup: Application_preS8_backup.docx.
