# CRISP-CAV FFP — Review round 2 (fresh personas)



---

# cp_professor — A 3.5 / RP 2.5 / I 3.0 → 2.95

# CRISP-CAV — International postal review (cooperative perception / multi-sensor fusion)

**Scores (FFP Awards, half points):** Applicants **3.5** · Research Programme **2.5** · Impact **3.0** → weighted **2.95** (0.3×3.5 + 0.4×2.5 + 0.3×3.0; the call rounds this to 3.0).

## Summary judgement
The question is well chosen: *when* does a shared infrastructure percept actually help, and can sensor physics predict that? Linking sharing value to measured sensor image quality (information capacity, SNR, MTF) and adding camera capture time (exposure, rolling shutter, HDR merging) to the alignment budget are both genuinely new. The submitted document, however, is a **working draft**. It has unfinished sections, planning notes and empty mandatory uploads, and the platform is too small for several of its questions. I cannot recommend funding as written.

## Applicants (3.5)
**Verified:**
- **PI, 11 years in industry:** Valeo, including Valeo Expert on Image Quality and IEEE P2020 LED-flicker work, plus patents.
- **PI, academic record since 2022:** relevant OJVT, T-ITS and COMST outputs on infrastructure-assisted driving, V2X access, the G-MIND dataset and information capacity.
- **Named postdoc (Dr George):** two first-author OJVT 2025 papers, including measured pose-alignment errors in V2I late fusion. These are directly relevant.

**Gaps:**
- **No senior-author record in core CP venues.** No applicant has senior-author papers in CVPR, ICCV, ECCV, NeurIPS or CoRL, which is where V2X-ViT, Where2comm, CoBEVT, DAIR-V2X, V2V4Real and V2X-Seq appear.
- **No vehicular or V2X publications from either co-applicant.** Dr Manzoor's case rests on transfer from ADS-B spoofing and QUIC measurement. Dr Ullah's automotive record is thin: pavement rating and tracking.
- **No estimation-theory or Byzantine-fusion specialist.** FQ2 and FQ3 depend on this expertise.
- **No narrative CVs to assess.** Both Narrative CV templates are unfilled. Co-applicant effort is "TBC". The PI's time commitment is "TBC" in the checklist but "0.3 FTE" in the team table.
- **Metrics in the text.** h-index and citation counts in §6 will be redacted under the call's DORA/CoARA rules.

## Research Programme (2.5)
**Verified problems (from the text):**
1. **The document is incomplete.**
   - "FQ4 optimised perception" has no content.
   - "WP4 – Optimised Communication Protocol" reads "Lead: ?".
   - WP2 and WP3 appear as bare headings before "WP5 – Real-World Validation" is inserted with transport tasks (Task 5.1–5.3).
   - "WP4" is used twice (§3.5 and §3.6), and "WP5" means both Dissemination and Validation.
   - The synopsis repeats item "(iv)".
   - A stray "e following" and an orphan "mAP@0.5" remain in the text.
   - About 45 lines of planning notes ("Motivation – Roshan", "Phantom traffic jams?", "Research Questions:") follow the DMP.
2. **The numbering is inconsistent.**
   - The abstract and §2 define three FQs, while §1 lists five and RO6–RO7 map to "FQ5".
   - The team table assigns timing and pose to "FQ3" and the transport/threat work to "FQ2", the reverse of §2.
   - The legal-remit text maps estimation theory to FQ3 and distributed detection to FQ2.
   - The code labels the timing CRB "Experiment 3 (FQ3)".
3. **Leftovers from an earlier draft:** "certified robustness module", "spectrum planning tools", a "worst-case adversarial strategy derived in the formal model (§3.4.1)" that §3.4.1 does not contain, and a risk entry for "FQ1 formal bounds" although FQ1 is now empirical.
4. **The preliminary paper is not published.** The abstract says "builds on published preliminary results", but the PDF has placeholder authors ("Author One…") and states "simulation only, no hardware logs". I ran both scripts: they reproduce Tables I–V exactly.

**Expert opinion on design and novelty:**
- **FQ1.** Novel and well motivated. The experimental design, however, does not support the success criterion ("predicts V on *held-out sites*").
  - There is one instrumented junction: G-MIND plus four RSUs costed at €2k compute and €1k camera each.
  - No receiver model is named (V2X-ViT, CoBEVT, Where2comm?), and there is no pre-training or transfer plan.
  - No annotation budget or labelled-frame target is given, yet a "3–8 TB" annotated release is promised. For comparison: DAIR-V2X ≈71k frames, V2X-Seq ≈15k, V2V4Real ≈20k, TUMTraf-V2X ≈2k densely labelled frames.
  - With one site, a regression of V on (capacity, SNR, MTF, weather, occlusion) is under-determined.
  - Use DAIR-V2X, V2X-Real and TUMTraf as additional "sites", and state the frame and condition counts.
- **FQ2.** The capture-time strand is the most original part of the proposal. The applicants' own CRB shows nanosecond-level clock offsets against a 5 ms CP budget, and the paper's Discussion says that budget is "met by every observable configuration". GNSS pose (≈1.3 m) dominates, so the UWB/5G clock machinery is not binding; lead with pose and capture-time/latency instead.
  - The 5G time anchor is modelled as an absolute σ≈5 ns observation citing TR 38.857, which is a positioning study. Commercial 5G time distribution to a UE is typically hundreds of ns at best.
  - The SoTA claim ("no work combines pose, capture-time and latency") ignores latency- and pose-robust fusion: V2X-ViT's delay-aware encoding, SyncNet (ECCV'22), CoBEVFlow (NeurIPS'23), FFNet (NeurIPS'23), CoAlign. A *bound* is still new. The *problem* is not.
- **FQ3.** The statement that prior work does not address "perception-level faults in shared percepts" is incorrect. Missing work includes:
  - adversarial feature attacks: Tu et al., ICCV'21;
  - consensus defence: ROBOSAC, ICCV'23;
  - malicious-agent detection: MADE / CP-Guard, 2024–25;
  - data-fabrication attacks and detection: Zhang et al., USENIX Security'24.

  "A bounded fraction of compromised agents" also needs more agents with overlapping fields of view than one vehicle plus 5 static nodes can provide. Fractions of 1/6 or 2/6 do not support scaling claims. The FQ3 preliminary result (GNSS *timing* bias) is not percept-level.
- **Transport (RO6–RO7).** Media-over-QUIC with per-ADU reliability and priority is a reasonable systems contribution. It has no lead, no hypothesis tied to FQ1–3 and no Gantt row. It also mixes radio technologies: the DMP logs ITS-G5, the vehicle carries a Cohda MK6C, and the RSU radios are unbudgeted.
- **Platform.** The preliminary blind-junction study needs two vehicles (A1 and A2). Only one research vehicle is available. The GNSS-spoofing experiments need a simulator and a shielded environment, neither of which is budgeted.

**DMP:** substantively adequate (FAIR, GDPR, 14-day anonymisation), but it sits inside Application.docx and the 2-page upload is empty. **Sex & gender:** the content on road-user and pedestrian-detection equity is reasonable. However, about 40% of the statement covers team recruitment and EDI, which the call says must not be included. **Value for money:** direct costs are €987,936, which matches the IUA workbook and is under the €1M cap. Overheads are 30% excluding equipment and services. Six laptops and an "LLM cloud subscription" will draw questions.

## Impact (3.0)
- **Credible routes:** Valeo Tuam, TII deployment guidance, ETSI TS 103 324 (CPS) and IEEE P2020.
- **No confirmed commitments.** Letters (Valeo, TII) and the ETSI route are explicitly "[TBC]", and no cash or in-kind contribution is confirmed.
- **Inconsistencies.** The Impact KPIs say ≥10 papers, but the RP says 12+ (including "3+ in top-10 ML/AI venues", which is unrealistic for this team's record). "D5.3" is the guidance note in the Impact Statement but the dataset in the RP. The dataset is due at M46 in the text and M48 in the milestones.
- **Strategy reference.** Reference [19] uses the wrong title for Research Ireland's strategy. §4 uses the correct one.

## Actions
### FATAL
- **Empty mandatory uploads.** Fill in the Narrative CVs (PI and both co-applicants), References, DMP and Infrastructure. These templates are currently empty, and the content exists only inside Application.docx.
- **Missing host letter.** Obtain the host Research Body letter of support confirming applicant eligibility and employment status.
- **Unstated time commitments.** State % commitments for all applicants (co-applicants "TBC"). The call warns that insufficient commitment can make an application ineligible.
- **Unfinished text.** Remove draft text and planning notes. Complete or delete FQ4. Assign the WP4-transport lead. Without this the RP cannot be reviewed as a finished programme.

### MAJOR
- **One structure.** Reconcile it to a single FQ/RO/WP structure: 3 FQs (or 4 with transport properly integrated), each WP number used once. Align the team table, Gantt, milestones and code labels with it.
- **Larger evidence base.** Expand the platform and dataset plan: name the receiver CP models, plan transfer from DAIR-V2X/V2X-Real/TUMTraf, give labelled-frame and weather-hour targets, budget the annotation, and add a second site or vehicle. Otherwise, rewrite the "held-out sites" and "fraction of agents" claims.
- **Refocus FQ2.** Centre it on pose and capture-time/latency, and acknowledge that clock synchronisation is not binding. Correct the 5G time-anchor model.
- **SoTA for FQ2/FQ3.** Add the adversarial/robust CP and asynchrony literature, and restate the novelty claims against it.
- **Letters and ETSI route.** Secure the Valeo and TII letters and a concrete ETSI route before submission.
- **Preliminary results.** Publish or preprint the CRB study with real authors, or stop calling it "published".

### MINOR
- **Sex & gender statement:** remove the team-EDI content.
- **Metrics:** remove h-index and citation counts.
- **Page size:** change US Letter to A4.
- **Consistency:** fix reference [19], the D5.3 labels, M46/M48, ≥10 vs 12+ papers, and the WP2 months (Gantt H2–H5 vs text M6–36).
- **Budget queries:** justify the laptops and the LLM subscription, budget a GNSS simulator, budget the RSU V2X radios, and settle on one radio stack (ITS-G5 or C-V2X).

## Three biggest strengths
1. **Novel question.** It asks whether measured sensor physics (information capacity, SNR, MTF) can predict the marginal value of a shared percept. This is absent from the V2X-ViT/Where2comm/CoBEVT/DAIR-V2X line of work and grounded in the team's published single-camera information-capacity results.
2. **Domain-specific expertise.** Capture-time uncertainty (exposure, rolling shutter, HDR merging) is a genuinely new term in the CP alignment budget, and the PI's Valeo HDR and LED-flicker record makes it credible.
3. **Real infrastructure and data.** G-MIND, the instrumented vehicle and measured V2I pose-error data (George, OJVT 2025) are in place. The reproducible CRB code is a sound foundation for a predict-then-measure methodology and an open, image-quality-annotated CP dataset.


---

# estimation_navigation — A 3.0 / RP 2.5 / I 3.0 → 2.8

# CRISP-CAV: Postal review (statistical signal processing and navigation)

**Scores:** Applicants 3.0 | Research Programme 2.5 | Impact 3.0 | **Weighted 2.80** (0.3×3.0 + 0.4×2.5 + 0.3×3.0)

## Summary
The application asks the right question: when does a roadside percept help a receiving vehicle? It breaks the question into three parts: information (FQ1), alignment (FQ2) and trust (FQ3). I reran both scripts, and they reproduce Tables I–V. The code is internally consistent. However, the "CRB attained" result holds by construction. Several physical conclusions are misread, one table reflects a numerical bug, and the package has an eligibility defect.

## 1. Preliminary results (verified by rerun and independent checks)
**1.1 "WLS attains the CRB" is a tautology.** The model is linear and Gaussian (z = Hτ + n). WLS is then efficient by construction, so Table I's RMSE/CRB of 0.99–1.05 only checks the random-number generator. The authors admit the χ²(4) KS test (p = 0.534) "checks the simulator, not hardware". A TSP-level contribution would need to test tightness where it is actually in question: nonlinear range and bearing models, the low-SNR threshold region (Ziv–Zakai/Barankin), NLOS bias, and the misspecified CRB.

**1.2 The 1/√N scaling is an artefact of the anchor model.** Each agent's 5G time anchor is modelled as an independent observation with σ = 5 ns, cited to 3GPP TR 38.857, a positioning study, not a modem specification. Agents served by the same gNB or sync chain share common-mode error. I added a correlation ρ between anchors. At ρ = 0.5 the CRB for N = 2/4/8/16 is 4.33/3.95/3.75/3.64 ns, which floors near 3.6 ns. At ρ = 0.9 it is about 4.8 ns for every N. The headline "sub-5 ns" result is therefore an input assumption.

**1.3 The UWB noise model is wrong.** Eq. (1) gives σ = 1/(4π·B·SNR^½)·(1/c), which is dimensionally inconsistent. The code instead uses 1/(2πB√SNR). Both treat the occupied bandwidth B as the RMS bandwidth β. For a flat 500 MHz spectrum β = B/√12, so σ is understated by about 3.5× (31.8 ps vs 110 ps at 20 dB). The timing script's DWM3000 link gives 3.0 cm, but the blind-junction script uses 10 cm for the same link. Contribution 1 says "two-way ranging" while §IX says "one-way UWB ranges", and these observe different things: one-way time of arrival depends on clock offset; two-way ranging cancels it.

**1.4 Table III reflects a bug, not the prior.** The step-1 RMSE of 88.4 µs is attributed to the "uninformative prior". However, every step carries a 5 ns anchor, so one update should already reach ns accuracy. I re-implemented step 1 in information form with the same model. That gives **2.46 ns**, versus 101 µs from the code's covariance form. The cause is that cond(S) = 7×10¹⁵: the prior variance is (1 ms)² against R of (5 ns)², so `inv(S)` loses all precision. A Joseph or square-root form would fix this. The steady-state RMSE of 1.02 ns is below the 2.50 ns snapshot CRB. That is legitimate, but it must be compared with the posterior CRB (Tichavský). Also, a Kalman filter is a Bayesian MMSE estimator; the paper's description of it as "MVUE" mixes classical and Bayesian frameworks.

**1.5 The Hausman test is correct but trivial, and it targets the wrong threat.** Cov(d) = Σ_noGNSS − Σ_all with effective rank 1 is correct. The reported power, however, is exactly a z-test on mean(GNSS) − mean(5G-TA). With N = 4, z = 100/√((100² + 5²)/4) = 2.00 at 100 ns and 5.99 at 300 ns, which reproduces the 16% and 99.9% figures. The test is just a comparison of two clocks, and it assumes the 5G source is honest. The paper's argument that "tens of ns is the regime a careful spoofer would target" does not hold. At 100 km/h, 100 ns of timing error displaces an object by **2.8 µm**. The threats that actually matter for cooperative perception (CP) are metre-level GNSS *position* spoofing, slow ramps, and false or deleted objects. None of these is analysed.

**1.6 Timing is not the binding constraint.** §X states "~14 cm position error per 1 ms". The correct figure is 2.78 cm/ms; 13.9 cm corresponds to 5 ms. The paper itself shows that the 5 ms CP budget is met with about 10⁶× margin. The real open questions in FQ2 are capture time (exposure, rolling shutter, HDR merging) and latency, and neither has a preliminary result.

**1.7 The blind-junction "GNSS bottleneck" claim depends on the frame.** Table V reports the global-frame bound of 1.27 m. The receiving agent, however, acts in its own frame. The code already contains `_ped_crb_wrt_a2`, which gives **0.62 m** for the same scenario. I computed this independently, and it is not stated in the paper. The two GNSS errors are also modelled as independent, although nearby receivers share most atmospheric error. My inference is that the bottleneck is partly an artefact of the chosen frame.

**1.8 "Published" is overstated.** The Application says each question "builds on published preliminary results". The PDF is an anonymised template ("Author One, University Name"), and its "hardware validation" is simulated.

## 2. Are FQ2 and FQ3 well-posed?
**FQ2** can be made well-posed. Write the receiver-frame error as e = R_r(ψ)ᵀ[R_s(ψ)z + p_s − p_r] + v·(t_use − t_cap), with t_cap varying across the image because of rolling-shutter readout. The proposal must also state which bound it seeks: the classical CRB, the hybrid or posterior CRB (random pose), or the misspecified CRB (calibration bias). Latency is a known delay after timestamping. It therefore enters as prediction error, not Fisher information.

**FQ3** asks for the "detectability limit for a careful adversary", and this is not yet well-posed. An attacker who injects into the null space of the consistency residual is undetectable by definition. A limit exists only for a stated attacker model: the number of compromised agents, the attacker's knowledge, and whether the attack is static or a ramp. The natural formulation is a minimum detectable bias or protection level (RAIM/ARAIM) or the noncentrality of a GLRT, as a function of geometry and redundancy at a given (P_FA, P_MD). The GNSS integrity literature has solved the single-fault case, and the proposal does not cite it.

## 3. Package compliance (verified against the call and files)
- **Too many co-applicants.** Call §2.4 states that "no more than one Co-Applicant per application is permitted". The Application names two (Ullah and Manzoor).
- **The time commitment is inconsistent.** The checklist gives the lead's commitment as "TBC", while §6 says 0.3 FTE. The co-applicants' "effort TBC" also needs resolving. The call allows ineligibility for insufficient commitment.
- **Required documents are missing or blank.** There is no host Research Body letter of support (call §3.9) and no budget justification (max. 3 pages). The Narrative CVs are blank templates. References.docx and DMP.docx contain 3 words each, and Infrastructure.docx contains 26. That content exists inside Application.docx but not in the required uploads.
- **The programme document is unfinished.** "FQ4 optimised perception" has no body text. §1 defines WP4 as the platform, WP5 as validation and WP6 as dissemination. The body, however, has two "WP4" sections ("3.6 WP4 – Optimised Communication Protocol & Security", with "Lead: ?. Addresses FQ5") and two "WP5" sections. Fragments such as "three fundamental questions:e following" remain. The Legal Remit assigns "statistical estimation theory (FQ3)", whereas §2 places the bounds work in FQ2.
- **The budget is consistent but incomplete.** Direct costs are €987,936, within the €1 M cap, and 30% overhead on non-fees gives €272,261. However, the €75,200 equipment line (Ouster €20k, RTX €20k, "Comms, peripherals" €10k, edge devices, cameras, laptops) has no GNSS signal simulator, which §3.3.3 depends on. It also has no named Septentrio, Qorvo or Cohda units. I would add (my opinion) that GNSS signal transmission requires a shielded room or regulator authorisation.
- §6 quotes h-index and citation counts, contrary to the call's position on DORA.

## 4. Applicants (3.0)
The PI's decade of Valeo image-quality work is directly relevant to FQ1 and to the capture-time term of FQ2. Dr George's measured pose-alignment errors (OJVT 2025) and the junction infrastructure are real assets. However, no team member has a track record in estimation bounds, GNSS integrity, UWB or clock synchronisation. These areas carry two of the three science questions and the IEEE TSP venue targets. The errors in §1 are of the kind such a specialist would catch, and a navigation-integrity collaborator would close the gap. Because the CVs are blank, I could not assess them properly.

## 5. Impact (3.0)
The routes are credible: input to ETSI TS 103 324, extension of IEEE P2020, TII siting guidance, and an open dataset with image-quality, timing and pose metadata. The claims are appropriately restrained. However, every external commitment (Valeo, TII, ETSI) is "TBC", so I cannot score the impact higher.

## Actions
**FATAL**
1. Reduce to one co-applicant, as call §2.4 requires. Move the second person to a collaborator role.
2. Supply the host Research Body letter, budget justification, completed Narrative CVs and real References/DMP/Infrastructure uploads, and fix all time commitments.

**MAJOR**
3. Finish the programme document: write or remove FQ4/FQ5, resolve the duplicate WP4/WP5, and name every WP lead.
4. Replace the tautological CRB-attainment claim with tightness tests (nonlinear models, threshold region, misspecified CRB).
5. Justify σ_ta = 5 ns, model correlated anchors, and withdraw or condition the 1/√N claim.
6. Fix the UWB model (dimensions, RMS bandwidth, one-way vs two-way ranging, 3 cm vs 10 cm).
7. Fix the Kalman-filter numerics, correct Table III, and compare against the posterior CRB.
8. Re-pose FQ3 with an explicit attacker model and a minimum-detectable-bias or GLRT analysis focused on position spoofing and false objects. Drop the "tens-of-ns careful spoofer" argument.
9. Report the blind-junction bound in the receiver's frame (0.62 m), with correlated GNSS errors.
10. Add an estimation or GNSS-integrity collaborator.
11. Budget the GNSS simulator and V2X/GNSS/UWB units, or descope §3.3.3.
12. Obtain the Valeo and TII letters.

**MINOR**
13. Correct "14 cm per 1 ms" to 2.8 cm/ms.
14. Remove the h-index and citation counts.
15. Reconcile the FQ numbering across the Legal Remit and §2, and remove stray text fragments.
16. Change "published" to "preprint".

## Three biggest strengths
1. The question is sound and timely: predicting the receiver-side value of a roadside percept before deployment. The information/alignment/trust decomposition can be falsified.
2. The team has real infrastructure (G-MIND node, research vehicle, live junction) and measured pose-alignment data. Combined with the PI's expertise in camera capture time, this places the team unusually well to address the capture-time term of FQ2.
3. The code is open and reproducible, and every table reran exactly. The authors already state their limitations honestly (simulation only; the KS test checks the simulator), so the fixes above are tractable.


---

# imaging_scientist — A 3.5 / RP 3.0 / I 3.5 → 3.3

# Postal review: CRISP-CAV (FFP 2024, Award). Reviewer: imaging scientist (MTF, SNR, information capacity, ISO 12233, EMVA 1288, IEEE P2020)

## Summary
CRISP-CAV asks the right question: when does a roadside percept actually help a vehicle? The PI is unusually credible on the image-quality half of that question. However, FQ1 as written treats a property of one camera (information capacity, SNR, MTF) as if it were a property of a sensor pair in a particular geometry (the conditional value V(s | r)). The plan to measure it at one live junction is under-specified and under-resourced. There is also a verified eligibility problem. The idea is fundable; this version is not.

## Verified problems
1. **Co-applicant limit.** Call §2.4 says: *"no more than one Co-Applicant per application is permitted."* §6.2 names two, Dr Ullah and Dr Manzoor. As submitted, the application is ineligible.
2. **Mandatory uploads are blank.**
   - The DMP, References, Infrastructure and both Narrative-CV files are unfilled templates; the CVs still contain "Please delete this guidance".
   - The bundle has no host Research Body letter. The call makes the contract statement in that letter an ineligibility condition.
   - There is no budget justification.
   - Time commitment is "TBC" in the checklist, and co-applicant effort is "TBC" in §6.2.
3. **No FQ1 preliminary data.** The bundled paper and scripts cover only Cramér–Rao bounds (CRB) for timing and blind-junction position. They contain no image-quality analysis: the only "SNR" in the code is UWB ranging SNR. FQ1 rests entirely on Geever et al., OJVT 2026; I confirmed the paper exists (DOI 10.1109/OJVT.2026.3655075).
4. **That citation is overstated.** §2.1 says information capacity *"predicts detection performance across optical and ISP configurations."* The published abstract describes a *"preliminary study"* on a *simulated test chart* with synthetic people and cars, degraded only by *contrast and blur*. Accuracy plateaus above about 0.25 b/p. It tested no real camera, ISP, noise regime or occlusion.
5. **"Published preliminary results" is inaccurate.** The bundled paper is an anonymised manuscript ("Author One… University Name"), stated to be *"simulation only, no hardware logs."*
6. **The FQ numbering is inconsistent.**
   - The Remit, §6.2, the PhD table and §3.5.1 label alignment and timing work "FQ3" and misbehaviour "FQ2". This contradicts §2.
   - Raw planning notes are left at the end of Application.docx ("Motivation - Roshan… Phantom traffic jams?"), along with stray fragments ("…representations.mAP@0.5", "www.rsa.ie").
7. **Image-quality literature and standards are missing.**
   - None of the 40 references is ISO 12233, EMVA 1288, IEEE 2020, Koren's information capacity or NS-SFR. Geever 2026, George 2025, CoAlign and VeReMi are cited in the text but are not in the reference list.
   - §2.2.1 says the metrics are *"being standardised through IEEE P2020"*. In fact IEEE Std 2020-2024 is already published.
   - Contrast Detection Probability (CDP), the detection-oriented key performance indicator (KPI) in P2020, is never mentioned.

## Is FQ1 well-posed and measurable? (opinion)
**The premise mixes two different quantities.** Shannon information capacity is computed from MTF and noise for a linear, shift-invariant, stationary system. It is a per-pixel upper bound for one camera. V(s | r) is conditional and task-specific, and it is driven mostly by geometry: occlusion, viewpoint, range and pixels on target.
- A high-capacity camera that duplicates the vehicle's view has V ≈ 0.
- A mediocre camera that sees round the corner has a large V.

FQ1 should be restated: *for a fixed geometry, does measured quality explain the residual variance in V?* Quality should be expressed per target, as information or CDP at the object's range and contrast, not per frame.

**Uncontrolled confounds:**
- **Weather** degrades the infrastructure camera and the receiver together.
- **Range and pixels on target** dominate detection and correlate with local MTF and SNR.
- **ISP non-linearity** (local tone mapping, sharpening, noise reduction, HDR merge) makes MTF and SNR depend on the scene and signal level, so a chart value measured at one illuminance does not transfer to a pedestrian at dusk. The plan never says whether metrics are taken on RAW or processed output, or whether the ISP is frozen.
- **The fusion network:** V depends on it, so the predictor must be tested across architectures.
- **Exposure and rolling shutter** drive alignment error (FQ2), so timing must be logged per frame.

**Feasibility at a real roadside (§3.2.1).** The plan is to measure *"information capacity, SNR, MTF and dynamic range… in situ, using test charts and natural-scene methods, across day, night and weather… as per-frame metadata"*.
- **Charts:** pole-mounted cameras at junction ranges need large, evenly lit charts on the carriageway, plus traffic management, and the illuminance cannot be controlled.
- **EMVA 1288 quantities** (QE, dark noise, PRNU, DSNU, saturation) need a uniform calibrated source. They must be measured in the lab before deployment.
- **Natural-scene SFR (NS-SFR, JIST 2021)** suits a *fixed* infrastructure view well: kerbs, poles and markings give repeatable edges, and static pixels give an estimate of temporal noise. However, the method depends on scene content. Its validity in rain, fog, at night and with lens contamination has to be shown.
- **Weather validation** needs a visibility (MOR) sensor, a rain gauge, a luminance meter, and flare and glare characterisation.
- **Budget:** the Budget.xlsm Proposal sheet funds €12k of consumables ("printing, prototyping") and €4k of edge cameras. Nothing is costed for charts, light sources, photometry, a visibility sensor or LED timing targets.

**Power and generalisation.** The success criterion is *"predicts V on held-out sites… better than a quality-blind baseline."*
- With one junction and four RSUs, there are no held-out sites to test on.
- Beating a quality-blind baseline is a weak test; any added covariate will manage it.

The plan needs:
- a pre-registered effect size;
- event counts for occluded VRUs with independent ground truth, per weather and illumination bin;
- deliberate manipulation of quality on the same scenes (defocus, ND filters, exposure caps, bit depth, ISP settings, compression, and validated RAW-domain degradation), so that quality is separated from geometry and weather.

**Positive.** Including capture time in FQ2 is the strongest physical insight here. Exposure, rolling-shutter readout and HDR merging spread the capture instant over milliseconds. The team's own paper (§X) finds the ns-level clock budget is met with enormous margin, so capture time and GNSS pose are the terms that matter. Measuring this with LED targets (§3.3.2) is feasible and suits the PI. The preliminary work should be re-centred on it.

## Does the PI's record support it?
Largely yes on measurement. The PI has:
- eleven years at Valeo, and was Valeo Expert on Image Quality from 2014;
- IEEE P2020 LED-flicker contributions;
- ISP-for-machine-vision papers (J. Imaging 2019 and 2023);
- senior authorship of the information-capacity paper in OJVT, with Norman Koren as co-author.

Few applicants could lead in-situ automotive image quality better. The weaknesses are structural:
- WP1 is led by an ML co-applicant, and no researcher is dedicated to in-situ image quality: PhD 1 works on compression, and the PI is at 0.3 FTE across four WPs.
- The record of grants the PI has led is thin (RASP is described as "co-led").
- The Narrative CVs are empty.

## Scores
| Criterion | Weight | Score |
|---|---|---|
| Applicants | 30% | 3.5 |
| Research Programme | 40% | 3.0 |
| Impact | 30% | 3.5 |
| **Weighted total** | | **3.30** |

## Actions
### FATAL
- Reduce to one co-applicant (§2.4). Move the other to Academic Collaborator, with a CV and a letter.
- Provide the mandatory uploads: Narrative CVs, DMP, References, Infrastructure, budget justification, and the host-body letter containing the eligibility table and the contract statement.

### MAJOR
- **Re-pose FQ1:**
  - make it conditional on geometry;
  - use per-target predictors (CDP or target-level information, per IEEE 2020-2024);
  - plan deliberate quality manipulation and a power analysis;
  - drop the "held-out sites" claim.
- **Specify the measurement protocol and budget it:**
  - EMVA 1288 measurements in the lab before deployment;
  - ISO 12233 e-SFR at commissioning;
  - per-frame NS-SFR and temporal noise, validated against charts;
  - a RAW vs ISP-output policy;
  - MOR and illuminance logging.
- Assign a dedicated PhD or RA to in-situ image quality under the PI.
- Describe Geever et al. accurately, and add pilot evidence on real G-MIND frames.
- Fix the FQ numbering, and delete the planning notes and stray fragments.

### MINOR
- Add the image-quality literature and the in-text references missing from the list.
- Reframe P2020 involvement as input to the 2020-2024 revision.
- Remove the Remit claims ("spectrum planning tools", "certified robustness") that do not appear in the programme.
- Fix the title of reference [19].
- Drop the "→ motorway" trial step.
- Reconcile the LiDAR model: "Rev 8" in the budget vs "OS1-64" in §3.5.1 and the DMP.

## Three biggest strengths
1. The PI's rare, directly relevant automotive image-quality record (Valeo IQ Expert, P2020, ISP-for-machine-vision, the information-capacity paper) makes the link from sensor physics to perception value credible.
2. FQ2 treats camera capture time (exposure, rolling shutter, HDR) as an alignment error and plans LED-target measurements. This is physically correct and moves the work beyond ns-level clock bounds.
3. The open junction dataset with per-frame image-quality, timing and pose metadata would be a first. G-MIND plus the research vehicle give real paired viewpoints, and the Impact Statement avoids inflated lives-saved claims.


---

# security_ai — A 3.0 / RP 2.5 / I 3.0 → 2.8

# CRISP-CAV: postal review (V2X security and trustworthy AI)

**Reviewer profile:** I work on V2X security and trustworthy AI: ETSI ITS security (TS 102 941, TR 103 460, TS 103 759), misbehaviour detection (VeReMi/F2MD), adversarial ML for collaborative perception, and the EU AI Act. I read the whole bundle and checked the preliminary paper against its code (`crisp_cav_exp3_crb_timing.py`).

**Scores:** Applicants **3.0** | Research Programme **2.5** | Impact **3.0** | **Weighted total 2.80** (0.3×3.0 + 0.4×2.5 + 0.3×3.0).

## Overall view
The core idea is good and fundable in principle. It treats cooperative perception (CP) as three coupled conditions: value (FQ1), alignment (FQ2) and trust (FQ3). It then asks for a *detectability limit* "as a function of sensor quality (FQ1) and alignment uncertainty (FQ2)" (§2.4.2). I have not seen that framing in the CP-security literature. As submitted, however, the application is not eligible and not finished. The FQ3 threat model is a list of attack types rather than an adversary model. The one preliminary FQ3 result restates a textbook bound. The state-of-the-art claim for FQ3 is incorrect.

## Applicants (3.0)
- **Verified:** The PI's Valeo record on HDR, LED flicker and IQ-vs-machine-vision fits the capture-time strand of FQ2 well. No other Irish group has this.
- **Verified:** Dr Manzoor is assigned the FQ3 lead (WP3). His relevant security record is ADS-B spoofing/injection detection. The team track-record document itself notes "No V2X security publications." ADS-B is a fair analogue for message-level plausibility checks. It does not cover perception-level consistency, adversarial perturbation of shared features, or ETSI PKI/misbehaviour reporting.
- **Verified:** Dr Ullah brings LRP explainability and federated/differential-privacy learning. That is useful for attributing a fused decision to its contributors. Nobody on the team has an adversarial-ML record, i.e. adaptive attacks on detectors or certified robustness. Yet the programme promises a "certified robustness module" (§3.7, DMP).
- **Verified:** No collaborator covers C-ITS security operations, such as a CCMS/PKI operator, an ETSI TC ITS WG5 member or an OBU vendor. The ETSI route is still "[TBC: route, e.g. ETSI membership via a partner]" (Impact Statement §4).
- **Verified:** Both Narrative CV uploads are blank templates. Time commitments for both co-applicants are "TBC" (team table and checklist).

## Research Programme (2.5)

**FQ3 threat model (§2.4.2, §3.4.1).** Items (i)–(iii) are a taxonomy, not a threat model. Undefined:
- Attacker position: an insider holding valid pseudonym certificates, versus an outsider, versus a physical-layer attacker spoofing LiDAR or camera at the sensor.
- Goal: induce hard braking, or mask a vulnerable road user (VRU).
- Knowledge: "knows the detector" is stated, but nothing is said about knowledge of other agents' views.
- Adaptivity over time, and collusion.

"Controls a bounded fraction of agents" has little meaning with one vehicle and four RSUs, where one compromised node is already 20–25% of the network. ETSI's actual mitigation path is not engaged: misbehaviour reports under TS 103 759 and CCMS revocation under TS 102 941. Nor is the tension with pseudonym change, which deliberately breaks the temporal linkability that track-consistency tests depend on.

**The detectability limit as evidenced (verified).** The paper reports 16% detection at a 100 ns GNSS bias and 99.9% at 300 ns. Using the code's own parameters (σ_GNSS = 100 ns, N = 4, 5G anchor 5 ns, threshold 9.03), a closed-form non-central χ²(1) with λ ≈ N·b²/σ_GNSS² gives 15.5% and 99.85%. The Monte Carlo therefore reproduces the textbook detection probability of a mean-shift test. The "limit" is simply σ_GNSS/√N. That is a sanity check, not a scientific finding about "careful adversaries". Three points matter more:
1. **Non-adaptive attacker.** The attack is a constant bias. A real spoofer drags time or position slowly, and the Kalman tracker in §VI would absorb that.
2. **The trusted reference is not independent.** The test assumes an honest 5G time anchor. Deployed gNBs are commonly phase-synchronised from GNSS, so a regional spoof can bias both references in common mode. This assumption must be stated and tested.
3. **The redundancy paradox, which is my main scientific concern.** Cross-agent consistency needs overlapping views. CP is most valuable exactly where the receiver cannot see the object: the occluded pedestrian of the lay abstract and §1.1. In that case only one agent sees it, so there is nothing to check against. High FQ1 value implies low FQ3 detectability. The programme should make this trade-off its central object. One option is a minimax or Chernoff/KL-bounded "stealthy attack" formulation, so the limit is defined against an optimal adversary rather than a fixed perturbation. Without that, WP3's "design rules" (§3.4.3) are unlikely to generalise.

**State of the art (verified, by web search).** §2.4.3 claims existing work does not address "perception-level faults in shared percepts". That is incorrect:
- Zhang et al., *On Data Fabrication in Collaborative Vehicular Perception*, USENIX Security 2024: real-time spoofing and removal attacks, a collaborative anomaly detector (91.5% detection at 3% false positives) and real-world tests.
- Li et al., ROBOSAC, ICCV 2023: consensus-based defence, with a derived bound on sampling trials.
- Zhao et al., MADE, IROS 2024: hypothesis-test detection of malicious agents on DAIR-V2X with Benjamini–Hochberg false-positive control.
- Tu et al., ICCV 2021: adversarial attacks on multi-agent communication.

MADE is a hypothesis-test, false-positive-controlled consistency detector, i.e. close to WP3's proposed method. Novelty must be argued against these papers. Reference [11] is miscited as "ETSI TS 103 460 V2.1.1 (2023) Misbehaviour Detection Framework". The document is TR 103 460 V2.1.1 (2020-10), a pre-standardisation study.

**Coherence (verified).** The document is unfinished. "FQ4 optimised perception" has no content. FQ5 sits under "2.5 Fundamental Research Question 4". The WP1–WP3 headings under §3.1 are empty. There are two WP4s, and one of them has "Lead: ?". Planning notes ("Motivation – Roshan … Jawad: comms…") remain after the DMP. FQ3 ownership is contradictory: the team table assigns "PhD 2: V2X misbehaviour detection… (FQ2; Manzoor)" and "PhD 3 … (FQ3; Deegan)", while the WP table gives FQ3 to Manzoor. GNSS spoofing appears in both WP2 (D2.3) and WP3.

**Ethics and safety of attack experiments.** The design intent is good. Injection is in software into recorded data, "No attack is transmitted over public V2X channels" (§3.5.3), and attacks "do not affect vehicle control" (Ethics). Gaps:
- §3.5.3 also allows injection into "**live** shared percepts". This needs a separate safety case and a guarantee that the injection path cannot reach the planner on a public road.
- §3.3.3 uses "a GNSS signal simulator in a controlled environment". It must say whether this is cabled or in a shielded chamber. Radiating GNSS signals requires ComReg authorisation. No GNSS simulator appears in the budget (verified, Proposal sheet) or in the infrastructure list.
- Dual use: the worst-case attack strategy and the attack-injection layer are to be open-sourced. Pre-publication disclosure goes to Valeo, a commercial partner. It should go to affected vendors (e.g. Cohda), the EU C-ITS CCMS, NCSC-IE and ENISA. Release of attack tooling should pass a dual-use review.

**Budget (verified).** €987,936 direct, inside the €1M Award limit, with no PI or co-applicant salary. Overhead is correctly 30% of costs excluding equipment and services (€272,261).

## Impact (3.0)
Impact is honest. It claims no number of lives saved, measures standards success as "contributions submitted, not adopted", and names plausible stakeholders (TII, Valeo). However, the letters and the ETSI route are still TBC. The EU AI Act is invoked without analysis. Vehicle perception falls under Annex I Section B, via type approval. Roadside traffic-management safety components fall under Annex III(2). Art. 15 (robustness and cybersecurity, including adversarial examples) is the hook. Mapping the detectability limits onto Art. 15 and ISO/SAE 21434 would be genuine policy impact. "Interpretable via attention visualisation" is weak.

## Actions

### FATAL
1. **Two co-applicants.** Call §2.4: "no more than one Co-Applicant per application is permitted." Ullah and Manzoor are both co-applicants. Make one a collaborator (I suggest keeping Manzoor if he leads FQ3, otherwise appoint a V2X-security co-applicant).
2. **Mandatory uploads missing or blank.** Lead and co-applicant Narrative CVs, the separate DMP, References and Infrastructure uploads, the budget justification, and the host letter. Co-applicant time commitment is TBC (§2.5.1, §3.3: insufficient commitment may make the application ineligible).
3. **Research Programme unfinished.** FQ4 placeholder, "Lead: ?", duplicate WP4/WP5/§2.5 numbering, and planning notes left in the document. It is unfundable as written.

### MAJOR
1. Replace the FQ3 attack taxonomy with a formal adversary model (position, goal, knowledge, adaptivity, collusion, certificate holding). Map it to ETSI TS 102 941, TS 103 759 and TR 103 460.
2. Redefine the detectability limit against an *optimal or adaptive* adversary (slow ramp, stealth under a KL bound). Drop the honest-5G-anchor assumption, or test it. Present the GNSS result as a sanity check, since it is analytic.
3. Address the redundancy paradox explicitly: single-viewer occluded objects, which is where CP adds most value.
4. Correct the FQ3 state of the art: Zhang (USENIX Sec '24), ROBOSAC, MADE, Tu et al., VeReMi Extension/F2MD. Argue novelty against them.
5. Fix FQ3 ownership and numbering across the remit, the team table and the WPs. Merge the GNSS-spoofing work into one WP.
6. Ethics and safety: separate safety case for live injection; cabled or shielded GNSS spoofing with a ComReg position; budget the GNSS simulator; dual-use review and a coordinated disclosure route (CCMS, NCSC-IE, ENISA, vendors).
7. Strengthen V2X-security fit: a collaborator from C-ITS PKI/ETSI WG5, and adversarial-ML expertise for the "certified robustness" claim (or drop the claim).

### MINOR
- Fix reference [11] to TR 103 460 V2.1.1 (2020).
- The abstract says "published preliminary results", but the CRB paper is an anonymised, unpublished draft.
- Add a concrete EU AI Act Art. 15 / ISO 21434 mapping. Replace "attention visualisation" with faithful attribution plus evaluation of that attribution.
- Discuss pseudonym change versus linkability for track-based misbehaviour detection.
- Remove the stray "www.rsa.ie", "e following" and duplicate deliverable "(iv)" text.

## Three biggest strengths
1. A novel, falsifiable coupling of trust to sensor quality and alignment: the detectability limit is a function of FQ1/FQ2 quantities.
2. Honest, reproducible preliminary work: the χ²-calibrated Hausman test is clearly labelled "simulation only", and the code matches the reported figures.
3. Real G-MIND infrastructure plus vehicle, with a responsible-by-default attack design (software injection into recorded data, no over-the-air attacks) and solid GDPR handling.


---

# industry_panel — A 3.5 / RP 3.0 / I 3.0 → 3.15

# CRISP-CAV: FFP 2024 Award review (industry panel member)

**Reviewer perspective:** R&D director at an automotive OEM/Tier-1 who has sat on national funding panels. My main focus is Impact (30%) and whether the project can be delivered.

## Summary
The scientific question is a good one. Industry asks it at every smart-junction pilot: will this roadside sensor, at this site, with this synchronisation, actually help the vehicles that use it? Framing it as information value, alignment and trust (FQ1–FQ3) is clear and easy to test. The PI's 11 years at Valeo on image quality versus machine vision is a real asset that most cooperative-perception (CP) groups lack. However, the package is not yet ready to submit:
- It breaks the co-applicant rule.
- Several mandatory uploads are empty.
- Every impact route rests on letters that are "to be requested" or "TBC".
- The plan for staffing the platform does not match the 48-month schedule.

## Verified problems (checked against the bundle)
1. **Too many co-applicants.** The BRIEF and §6.2 list two co-applicants (Ullah, Manzoor). The call (§2.4, p.12) says *"no more than one Co-Applicant per application is permitted."* As configured, the application is ineligible.
2. **Mandatory uploads are empty or missing.**
   - `Data_Management_Plan.docx`, `Infrastructure_and_facilities.docx` and `Research_Programme_References.docx` contain only the template headings (8–33 words each).
   - Both Narrative-CV files are the unfilled templates.
   - No host Research Body letter is included, and no industry or TII letters either.
   - The Application checklist shows the lead applicant's time commitment as "TBC", and §6.2 gives co-applicant effort as "TBC". The call (p.21) warns that *"Commitment deemed insufficient may result in ineligibility."*
   - The Infrastructure text inside the Application says the PI is at "0.3 FTE", which contradicts the TBC.
3. **No impact commitments are in place.** Impact Statement §3 says: *"Valeo has been approached… TII will be asked… [TBC before submission… No cash co-funding is claimed.]"* §4 says *"[TBC: route, e.g. ETSI membership via a partner.]"* The risk table says *"TII letter of support to be requested before submission."* The 5G fallback relies on a "CONNECT Centre partner" that has no letter.
4. **Platform staffing does not fit the timeline.** WP4 (vehicle by M12, 4 RSUs and middleware by M18) is led by the one postdoc "with RA 1 and PhD 4". But RA 1 is costed only in Years 3–4 (Proposal sheet row 24: €0 in Y1–Y2). The same postdoc also has FQ2 experiments, the WP5 co-lead, DMP and anonymisation work, and dataset curation.
5. **Costed items do not cover the work.**
   - No GNSS signal simulator is budgeted, although §3.3.3 needs one.
   - The hardware listed in §3.5.1 (Cohda MK6C, Septentrio mosaic-X5, Quectel 5G, UWB, Basler, OS1-64) is costed only as €10k "Comms, peripherals" plus a €20k Ouster.
   - QCS6490/Jetson Orin targets are named in the Ethics section but not in the budget.
   - Annotating the 3–8 TB dataset has no budget line (services are a €5,200 "LLM Cloud subscription").
   - Direct costs of €987,936 leave about €12k under the €1M cap (§2.1), so none of these gaps can be fixed without cutting something else.
6. **The preliminary evidence is weaker than presented.**
   - The abstract says each FQ "builds on published preliminary results". The CRB paper in the bundle still has "Author One… University Name" and states *"simulation only, no hardware logs"*.
   - I ran both scripts. They reproduce the headline figures (RMSE/CRB 0.99–1.05, Hausman false-alarm rate 0.20%, detection 16% at 100 ns and 99.9% at 300 ns).
   - The code's own report says *"The 5 ms column is met by every observable configuration and is not a discriminating test."* In other words, the timing result is nanoseconds against a millisecond requirement.
   - For industry, the useful finding is the other one: GNSS pose error (σ≈1.27 m) dominates. The proposal should lead with that.
7. **The documents contradict each other in places.**
   - The FQ numbering is swapped in the remit statement and in §6.2 (PhD 2 is listed against FQ2, PhD 3 against FQ3).
   - Deliverable D5.3 is called the guidance note in one place and the dataset in another.
   - The publication KPI is 12+ in one place and ≥10 in another.
   - The remit text promises "spectrum planning tools, certified robustness frameworks", which no WP delivers.
   - Reference [19] has the wrong strategy title, and the misbehaviour-detection document is cited as TR 103 460 in the text but TS 103 460 in the reference list.
8. **Draft material is still in the document.** The end of Application.docx contains planning notes ("Motivation - Roshan … Encrypt before data transmission"). There are also stray strings ("…representations.mAP@0.5", "…by 2030.www.rsa.ie") and a truncated S&G paragraph ("Scene | RGB, LiDAR) measured in WP1…").
9. **The S&G statement includes recruitment and team-EDI content** ("Team Composition and Inclusive Recruitment Practice", "All three research posts", but there are six posts). Reviewers score S&G on the research content. This section uses words without earning marks.

## Opinion (industry judgement)
- **Irish benefit is asserted, not mapped.** Valeo Tuam is the only Irish company named. There is no list of target adopters (roadside-unit integrators, telecoms operators, local authorities beyond TII, SMEs) and no route through Enterprise Ireland or IDA. "Exploitable IP" is promised in the remit statement, but the Impact Statement defaults to open source. That is fine, but say it plainly and drop the IP claim.
- **The standards route is credible in content but has no named owner.** ETSI TS 103 324 (Collective Perception Service) really does leave out "when is shared data worth sending/trusting", so the gap is real. Without a named ETSI member organisation (Valeo, or a C-Roads partner), a "contribution submitted" KPI is not deliverable. The IEEE P2020 route needs checking: as far as I know, the working group's first standard has been published. The proposal should say which follow-on activity it would feed into.
- **The KPIs measure outputs, not outcomes.** Papers submitted, "≥1 workshop", "≥1 standards contribution". I would want to see:
  - The number of industry or road-authority organisations that test the requirement calculator.
  - Dataset downloads and citations.
  - A TII pilot decision informed by the guidance note.
  - Signed placement agreements for the four PhDs, which are currently "to be agreed with Valeo or another industry partner".
- **Some honesty is to the proposal's credit.** It makes no lives-saved claim, it says "success is measured by contributions submitted, not adopted", and it treats a negative FQ1 result as useful. A panel will notice and value this.
- **Scope is large for the team.** Six WPs, and all four PhDs start at M1. Recruiting four PhD students in the first quarter is optimistic, and the M12 deliverables depend on it.

## Scores
| Criterion | Weight | Score |
|---|---|---|
| Applicants | 30% | 3.5 |
| Research Programme | 40% | 3.0 |
| Impact | 30% | 3.0 |
| **Weighted total** | | **3.15** |

**Applicants (3.5).** The PI brings relevant industry depth and a growing CAR-group V2X/infrastructure record, and the named postdoc has measured V2I pose-error data. Against that: neither co-applicant has a vehicular or V2X security publication; there is no estimation or information-theory specialist; effort is TBC; and the CVs are empty, so a panel cannot verify the track record from the uploads.

**Research Programme (3.0).** The questions are coherent and the predict-then-measure design is sound. Deliverability is the problem: the platform staffing, the unbudgeted equipment and annotation, preliminary results that are simulation-only (and the timing result is non-binding), and the internal inconsistencies.

**Impact (3.0).** The problem is relevant to industry and the routes (ETSI CPM, TII, supplier validation) are plausible. But there are no letters, no co-funding, TBC placeholders, output-only KPIs and a thin Irish-benefit map.

## Actions

### FATAL
1. Reduce to **one co-applicant** (§2.4). Move the other to Academic Collaborator with a 2-page CV and a letter. Re-assign the WP leads accordingly. Academic Collaborators cannot be primary PhD supervisors, so check the PhD supervision plan.
2. **Complete every mandatory upload:**
   - Narrative CVs for the lead and co-applicant.
   - The separate DMP (2 pp), References (5 pp) and Infrastructure (1 p) uploads. Move the text out of Application.docx.
   - The budget justification (3 pp).
   - The host Research Body letter.
3. **Enter real time commitments** for the PI and co-applicant, and make them consistent with the "0.3 FTE" figure.

### MAJOR
1. **Get signed letters** from Valeo (in-kind items valued in €: expert hours, equipment, data, PhD placements) and TII (site access, guidance-note uptake). Get a letter from a 5G operator or CONNECT for the network-time anchor. Name the ETSI member who will table contributions. Remove every "[TBC]".
2. **Re-phase staffing.** Move RA 1 to Years 1–2, the platform build phase, or add technician effort. Stagger PhD starts realistically, and move D1.1 to about M15 if needed. Use Staff-sheet costing and stay ≤€1M.
3. **Budget for or source the missing items:** the GNSS simulator (or a loan letter), the V2X/GNSS/5G hardware listed in §3.5.1, and dataset annotation. Otherwise, cut scope (for example, drop raw-level fusion or the RSU count).
4. **Rewrite the KPIs as outcomes,** with numeric targets and named adopters. Add an Irish-benefit map covering firm types, EI/IDA routes and the TII decision points.
5. **Recast the preliminary results honestly.** Mark the paper as an unpublished simulation preprint and add author names. Lead with the GNSS-pose-dominance finding and the capture-time (exposure, rolling shutter, HDR) extension, where the PI's expertise is the differentiator.
6. **Resolve the FQ/PhD/WP numbering conflicts** (remit statement, §6.2) and the deliverable mismatches (D5.3, publication KPIs).

### MINOR
- Remove the leftover planning notes, stray strings and the truncated S&G paragraph. Fix the reference [19] title and the TR/TS 103 460 mismatch.
- Refocus the S&G statement on research content (demographic detection disaggregation), and remove the recruitment/EDI material.
- Set Application.docx to A4 (it is currently US Letter) and confirm the 15-page RP limit after conversion.
- Align the target venues with the work (T-ITS, T-IV, OJVT, IS&T EI). Drop T-IT, NeurIPS and ICML unless there is genuine theory.
- Clarify the status of the IEEE P2020 work and the role the PI would play.

## Three biggest strengths
1. **The question matters to industry.** "Will this roadside sensor improve perception here, before we deploy it?" is the decision OEMs, Tier-1s and road authorities actually face. The CPM standard does not answer it.
2. **The PI's background fits the problem.** Eleven years at Valeo, including as Valeo Expert on image quality versus machine vision, plus LED-flicker/HDR timing experience. This lets the proposal ground CP value and capture-time alignment in sensor physics, which other CP groups lack.
3. **Infrastructure and evidence already exist,** and the claims are modest. The G-MIND node, the research vehicle and the named postdoc's measured V2I pose errors are in place. There are no inflated lives-saved claims, and negative results and standards outcomes are treated realistically.


---

# programme_officer — A 3.5 / RP 3.5 / I 3.5 → 3.5

# CRISP-CAV: Programme Officer eligibility and compliance check (FFP 2024, standard Award)

**Reviewer:** Scientific Programme Manager, pre-panel compliance check
**Checked:** Application.docx (text and tables), Impact Statement, Budget.xlsm Proposal sheet, the upload templates, the preliminary paper and code, and the call document (§2.1, §2.5, §3.8–3.11, Appendix A).

## 1. Summary verdict
The budget is compliant and the science is coherent, but the package is **not submittable as it stands**. Four mandatory uploads are blank or missing, and the host letter with the eligibility table is absent. SESAME would reject the package, or the office would return it as ineligible before review. Every FATAL item can be fixed administratively.

## 2. Verified compliance checks (passed)
| Check | Call rule | Finding |
|---|---|---|
| Route / duration | Award, 48 or 60 months (§2.1) | 48 months. Year 5 is €0 throughout. **Pass** |
| Direct costs | €600k–€1M | Proposal!G15 = **€987,936.11**, with only €12k of headroom. **Pass** |
| Applicant salary | Ineligible (§2.5, §3.9.1) | Labour lines are PD1 €257,538, RA1 €99,998 and PhD×4 €492,000. No applicant salary. **Pass** |
| Overhead basis | Excludes equipment | 30% × €907,536 (excluding equipment and services) = €272,261. Total €1,260,197. **Pass** (Research Office to confirm the rate) |
| Form vs workbook | Consistency | The Budget Summary table in Application.docx reproduces the xlsm line for line. **Pass** |
| Title / keywords / abstract | ≤30 / ≤15 / ≤200 words | 17 / 14 / 173. **Pass** |
| S&G length | ≤1000 words | 974. **Pass** on length (see content issue below) |
| Research Programme length | ≤15 pp | About 4,500 words, 11 pt, 2.54 cm margins (roughly 10–11 pp). **Pass** |
| Applicant eligibility | Permanent, PhD ≥3 years | The brief states all are permanent. PI PhD 2011, Ullah 2017. Manzoor's PhD year is not stated. Unverifiable without the RB letter |

## 3. FATAL (application would be ineligible or rejected at submission)
1. **The Narrative CVs are blank.** `2024-FFP_Applicant_Co-Applicant-Narrative-CV.docx` is the unfilled template, with its guidance text still present. A 5-page CV is mandatory for the Lead Applicant and for each co-applicant (Deegan, Ullah, Manzoor).
2. **The separate uploads are empty.** `Data_Management_Plan.docx` contains only "Max 2 pages". `Research_Programme_References.docx` contains only "Max 5 pages". `Infrastructure_and_facilities.docx` contains only its headings. The content exists only inside Application.docx, and SESAME requires each as a separate PDF upload (§3.8, §3.10).
3. **The host Research Body letter and eligibility table are missing.** §3.11 requires a signed letter on headed paper with the eligibility table for each applicant. The call states "Applications will be made ineligible if this is not provided."
4. **The budget justification upload (3 pp) is missing** (§3.9.8).
5. **Time commitment is undeclared.** The checklist shows the PI's percentage time as "TBC", and the team table gives "effort TBC" for both co-applicants. The PI appears at 0.3 FTE only in the Infrastructure text. §2.5 lets the office rule an application ineligible "where commitment levels are deemed to be insufficient" or unclear. Declare all three, matching the RB letter.

## 4. MAJOR (compliance or consistency failures likely to cost ≥0.5 point, or to trigger redaction)
1. **The Impact Statement breaks the formatting rules.** The body is Calibri 10.5 pt, the KPI table 9.5 pt, and all margins are 2.0 cm. The call requires at least 11 pt and at least 2.5 cm margins. Once corrected, the 1,049 words plus the table are likely to exceed 3 pages.
2. **Two word limits are exceeded.** The lay abstract has 106 words against a limit of 100. The legal-remit justification has 372 words against 250.
3. **The S&G statement includes team-composition content.** Appendix A says this section "should not include information on gender equality, diversity and inclusion in the research team". The section "Team Composition and Inclusive Recruitment Practice" (about 230 words) must be removed.
4. **The Research Programme quotes metrics.** The Research Programme quotes Scholar/Pure citation counts and h-indices for all three applicants, in the team table and in the PI bio. This conflicts with DORA and the Narrative CV guidance, and is likely to be redacted.
5. **Key hardware is uncosted or inconsistent with the budget.** §3.5.1 lists an Ouster OS1-64, Basler cameras, a Quectel 5G module, a Qorvo UWB module, a Cohda MK6C OBU and a Septentrio mosaic-X5. §3.3.3 relies on a GNSS signal simulator, and §3.3.2 on RTK ground truth and LED timing targets. The Ethics section names Qualcomm QCS6490 and Jetson Orin. The budget lists an "Ouster Rev 8 Lidar", "Comms, peripherals (Jawad)" €10k and 4 edge devices/cameras for €12k, while D4.2 promises "4 RSU nodes deployed". Either list the existing kit in the Infrastructure upload or cost it.
6. **There are no letters for organisations the proposal depends on.** Valeo, TII, the CONNECT Centre and Mondello Park are relied on in the risk table ("TII letter of support to be requested before submission") and in the Impact Statement. None is a listed collaborator, and the Impact Statement still contains placeholders: "[TBC before submission: the specific commitments in each letter...]" and "[TBC: route, e.g. ETSI membership via a partner.]". Unsolicited letters will be redacted (§3.11). Either list these organisations as collaborators with letters, or remove them from the mitigations.
7. **The preliminary results are overstated.** The scientific abstract says each question "builds on published preliminary results from the team". The cited paper has placeholder authors ("Author One… University Name") and states "simulation only, no hardware logs". The code still labels Experiment 6 "Hardware validation". Describe it accurately as unpublished simulation (§3.8 permits "a summary of results where the data has yet to be published").
8. **FQ numbering and roles are inconsistent.**
   - The remit text assigns estimation theory to FQ3 and distributed detection to FQ2. The Research Programme has the reverse.
   - The team table labels PhD 2's misbehaviour work as FQ2 and PhD 3's capture-time work as FQ3.
   - §3.5.1 tags the 5G and UWB hardware as FQ3.
   - The PI is listed as "WP4 + WP5 lead", but §3.5 names George as WP4 lead.
   - Ullah is "Co-lead WP1" in the team table but "Lead" in §3.2.
   - D5.3 is the dataset in the Research Programme but a "guidance note" in the Impact Statement.
   - The risk table still refers to "FQ1 formal bounds", although FQ1 is now empirical.
9. **The reference list does not match the citations.** Works cited in the text are missing from the 40-item list: Geever 2026, George 2025, Ahmed 2025, Lu 2023 (CoAlign), Vempaty 2013, V2V4Real, V2X-Seq, Wilson 2019, Zhao 2021 and Freed 2018. Reference [19] has the wrong strategy title, which contradicts §4.
10. **Potential funding overlap for the named postdoc.** The working track-record document lists Dr Roshan George as a "Research Ireland RD&I Fellow with Valeo", and his PhD thesis is dated 2026. He is costed at 1.0 FTE for 4 years. Confirm there is no concurrent Research Ireland funding, and declare any related pending or held award (§3.5).
11. **Draft residue in the submitted text.** Application.docx ends with raw planning notes ("Motivation - Roshan… Perception (Ishan)… Encrypt before data transmission"). It also contains stray strings such as "…representations.mAP@0.5" in §3.2.2 and "Galway." in §3.5.1.

## 5. MINOR
- The documents use US Letter page size. Convert to A4 before making the PDFs.
- "Comms subscription sim" (€1,200) is a recurring cost and belongs in consumables, not equipment. Laptops ×6 (€12k) and the "LLM Cloud subscription" need explicit justification under the GBP.
- The Ethics section's graduated test plan ("→ rural roads → motorway") does not match a junction-based study.

## 6. Scores (provisional: the CVs could not be assessed)
| Criterion | Weight | Score | Rationale |
|---|---|---|---|
| Applicants | 30% | **3.5** | The PI has a distinctive 11-year industry record in image quality, HDR and LED flicker, and a credible group base (G-MIND, research vehicle). The co-applicants have no vehicular or V2X publications. There are no Narrative CVs to score against the four DORA categories |
| Research Programme | 40% | **3.5** | Three falsifiable questions, a predict-then-measure design, a Gantt chart, milestones and a DMP that meets the six Science Europe headings. Undermined by the FQ and role inconsistencies, the uncosted hardware and the overstated preliminary data |
| Impact | 30% | **3.5** | A concrete milestone/KPI table, honest claims ("does not claim a number of lives saved"), correct Irish road-death figure (184 in 2023) and credible ETSI/IEEE P2020 routes. Weakened by TBC letters, no co-funding and the formatting breach |
| **Weighted total** | | **3.50** | 0.3×3.5 + 0.4×3.5 + 0.3×3.5 |

## 7. Three biggest strengths
1. **The budget is compliant and internally consistent.** €987,936 direct, no applicant salary, overhead calculated excluding equipment, 48 months, and identical figures in the form and the IUA workbook.
2. **The scientific structure is clear and testable.** FQ1–FQ3 map onto RO1–RO5 and WP1–WP5, with explicit success criteria (e.g. "predicts V on held-out sites… better than a quality-blind baseline") and real infrastructure for the measurements.
3. **The PI's industry and standards background fits the problem.** The Valeo image-quality expertise and IEEE P2020 work tie directly to the capture-time and image-quality predictors, and give a realistic route to impact through industry and standards.

*Separation of evidence:* Sections 2–5 are verified against the files, except where marked "confirm". The scores and the strength assessments are the reviewer's opinion.


---

# rapporteur — A 3.5 / RP 3.0 / I 3.5 → 3.3

# CRISP-CAV: Rapporteur report (FFP 2024, Award)

*Non-specialist EE rapporteur. I read all files in the bundle, the relevant call sections, and the paper, and I re-ran both scripts.*

## 1. Central idea, for non-experts
Roadside sensors can see what a car cannot. CRISP-CAV asks a simple question: before installing one, can we predict whether it will actually help the car? It breaks this into three parts:
- **FQ1, value:** can measured camera quality predict how much the shared data helps?
- **FQ2, alignment:** can the shared data be placed correctly in space and time?
- **FQ3, trust:** can faulty or malicious inputs be detected?

The idea is clear (§1.1, §2.5) and the lay abstract works. The "predict-then-measure" method (§3.1) makes the programme falsifiable rather than a benchmark exercise. That is its best feature.

## 2. Verified problems

**Compliance**
- **Two co-applicants are named (Ullah and Manzoor; checklist, §6.2, BRIEF).** Call §2.4 says "no more than one Co-Applicant per application is permitted", so the application is ineligible as structured.
- **Mandatory uploads are missing or empty.** The DMP, Infrastructure, References and both Narrative-CV files are blank templates; no applicant is named. The bundle has no host Research Body letter with the §3.11 eligibility table, and the call says that omission makes an application ineligible. There is no budget justification, and no Valeo or TII letters.
- **Impact Statement formatting breaks the rules.** It uses Calibri 10.5 pt, 9.5 pt tables and 2.0 cm margins; call §3 requires a minimum of 11 pt and 2.5 cm margins.
- **Word limits are exceeded.** The Legal-remit statement is 372 words against a limit of 250, and the call says it "will be used to determine the eligibility". The lay abstract is 106 words against 100. The scientific abstract (173), keywords (14) and S&G statement (974) are within limits.
- **Draft material is still in the document.**
  - Planning notes after the DMP ("Motivation - Roshan … Media over QUIC … Research Questions:").
  - Two `[TBC before submission]` markers in the Impact Statement.
  - Lead Applicant time commitment is "TBC" in the checklist but "0.3 FTE" in §6.2; co-applicant effort is "TBC". Call §3.3 says insufficient commitment can make an application ineligible.
- **The S&G statement includes "Team Composition and Inclusive Recruitment".** Call §3.7 and the reviewer guidance exclude team EDI from this statement. It also cites Wilson 2019 and Zhao 2021, which are not in the reference list, and contains a broken paragraph ("Scene | RGB, LiDAR) measured in WP1…").

**Internal coherence: FQ numbering was not carried through a renumbering**
- **Remit:** "estimation theory (FQ3), distributed detection… (FQ2)". This is the reverse of §2.
- **§6.2:**
  - The PI is listed on "FQ3 capture-time and pose uncertainty", which is FQ2 work.
  - PhD 2 (misbehaviour detection) is tagged FQ2; PhD 3 (CRB) is tagged FQ3. These are swapped.
  - George is listed on "FQ3 pose-alignment".
- **§3.5.1:** 5G and UWB are labelled "FQ3".
- **WP leads:**
  - WP4 is led by George in §3.5 but by the PI in §6.2.
  - WP1 is led by Ullah in §3.2 but he is "Co-lead" in §6.2.
- **Risk table:** it still refers to "FQ1 formal bounds" and "UWB-only CRB". It omits the real risks: the value model not generalising, annotation effort, and ethics timing.
- **Milestones:** the M28 row lists D1.3 (due M30), and the M36 row lists D2.2 (M30) and D4.4 (M32). The Impact Statement calls D5.3 a "guidance note", but D5.3 is the dataset.

**Preliminary results: real but over-described**
- **The code reproduces the paper.** I re-ran it and got RMSE/CRB of 0.99–1.05 for N = 2/4/8, a KS test p = 0.53, and a lidar blind-junction σ_geom of 1.271 m.
- **But it is not "published" as the abstract claims.** The paper uses placeholder authors ("Author One… University Name") and says "simulation only, no hardware logs".
- **It does not test the novel part of FQ2.** The paper's own §X says the 5 ms CP timing budget "is met by every observable configuration". The nanosecond-level clock bound therefore has no bearing on perception. The FQ2 novelty is capture time (exposure, rolling shutter, HDR), and that is not modelled yet.
- **The Hausman result cannot support the claim made for it.** It shows 16% detection at 100 ns and 99.9% at 300 ns. At 30 m/s, 300 ns is about 9 µm of motion. That cannot support "careful attacks hide inside alignment uncertainty" at the level of perception.
- **The 5G anchor is modelled as an absolute 5 ns clock observation**, which is optimistic.
- **FQ1 has no numerical pilot in the bundle.** It relies on an OJVT 2026 paper that I could not inspect.

**Budget against the work**
- **The headline figures are sound.** Direct costs are €987,936 in both the xlsm and the text, within the €600k–€1M band. No PI salary is requested. Overheads are 30% excluding equipment and services (€272,261).
- **Equipment (€75,200) misses items the work plan uses.**
  - Septentrio GNSS/IMU, Cohda MK6C OBU and Basler cameras (§3.5.1).
  - A GNSS signal simulator (§3.3.3).
  - LED timing targets, and RSU radios and installation.
- **Annotating 3–8 TB (DMP) has no budget.** Services total €5,200, all of it an "LLM Cloud subscription".

**Overclaiming**
- **Remit:** "spectrum planning tools, certified robustness frameworks", Climate Action and accessible mobility. None of these appears in any WP.
- **WP6:** "IEEE Trans. Information Theory, NeurIPS, ICML… 3+ top-10 ML venues". This does not match the Impact Statement's "≥10 papers" or its venue list.

## 3. Opinion
- **Applicants.** The PI's 11 years at Valeo on image quality, HDR and LED flicker, plus his IEEE P2020 work, are rare. Manzoor's ADS-B security work is a fair analogue for FQ3. Ullah fits WP1, but his automotive record is thin. Nobody on the team has a track record in estimation or information theory, despite the "bounds" language and the IEEE Trans. Information Theory targets. A named collaborator would help. Empty CVs prevent fair scoring.
- **Research programme.** Timely and feasible on existing G-MIND/vehicle assets. Two concerns:
  - FQ1's success criterion is "better than a quality-blind baseline on held-out sites". One junction plus four RSUs gives very few held-out sites, and no effect size is stated.
  - WP5 validates at a single junction, so the claim that results "hold across sensors, sites and networks" is untested.
- **Impact.** It is honest ("does not claim a number of lives saved") and well aimed: TII siting guidance, ETSI TS 103 324 and P2020. But every route is unconfirmed: the letters and the ETSI route are TBC and there is no co-funding. The KPIs are measurable.

## 4. Scores
| Criterion | Weight | Score |
|---|---|---|
| Applicants | 30% | 3.5 |
| Research Programme | 40% | 3.0 |
| Impact | 30% | 3.5 |
| **Weighted total** | | **3.30** |

These scores assume the eligibility defects are fixed. As submitted, the application would not reach review.

## 5. Actions
**FATAL**
1. Reduce the application to one co-applicant (§2.4) and make the other a collaborator, with a letter. Then re-allocate the WP and PhD leads.
2. Complete the Narrative CVs (5 pages, no metrics).
3. Get the University of Galway host-body letter with the §3.11 eligibility table covering the applicants.
4. Supply the DMP, References, Infrastructure and Impact as separate PDFs, plus the 3-page budget justification.
5. Cut the remit statement to 250 words or fewer and fix its FQ mapping.
6. Enter real time commitments for all applicants.

**MAJOR**
1. Reconcile the FQ, PhD and WP-lead labels across the remit, §3, §3.5.1, §6.2 and the risk table. Fix the milestone and D5.3 mismatches.
2. Describe the preliminary results as unpublished and simulation-only. Add a first capture-time bound (rolling shutter/HDR) and an FQ1 pilot from G-MIND.
3. Cost the GNSS/IMU, OBU, cameras, GNSS simulator, RSU radios/installation and annotation, or state which existing CAR Group equipment covers them.
4. Give FQ1 a measurable hypothesis: effect size, number of sites, held-out protocol. Rewrite the risks for the current FQs.
5. Get Valeo and TII letters with specific in-kind commitments, and name the ETSI route.
6. Drop the out-of-scope claims and align the publication KPIs.
7. Rewrite the S&G statement: remove team EDI and cover sex and gender as research variables, e.g. VRU detection by stature and age.

**MINOR**
1. Delete planning notes, TBC brackets and template headings.
2. Remove the citation/h-index metrics in §6.1–6.2 (DORA).
3. Use one strategy name and one SDG list, and fix ref [19].
4. Trim the lay abstract to 100 words or fewer.
6. Use A4 page size for the main form; set the Impact Statement to 11 pt and 2.5 cm margins.

## 6. Three biggest strengths
1. A clear, falsifiable question ("will this roadside sensor help, here?") with a predict-then-measure design.
2. A distinctive PI record in automotive image quality and capture timing (Valeo, P2020), backed by real infrastructure (G-MIND node, research vehicle) and a named postdoc who has measured V2I pose errors.
3. A compliant and consistent budget (€987,936, no PI salary), and an honest, concrete Impact Statement with KPIs and open data and code.

## 7. Panel summary
1. A well-posed, timely question that non-experts can follow: when does roadside sensing actually help a vehicle? It is split into value, alignment and trust.
2. The PI's industrial record in image quality and timing is a real differentiator; the team lacks an estimation or information-theory specialist.
3. The preliminary work is simulation-only and unpublished. Its nanosecond-level timing result does not address the millisecond-level capture-time problem that is the real novelty.
4. FQ labels, WP leads, milestones, equipment and claims contradict each other across sections, several mandatory uploads and letters are missing, and the application names two co-applicants where the call allows one.
5. Ranking: mid-table (about 3.3). Fundable only after a thorough consistency and compliance pass; not fundable as submitted.
